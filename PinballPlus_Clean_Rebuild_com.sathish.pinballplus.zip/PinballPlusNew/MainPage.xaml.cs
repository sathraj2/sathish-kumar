using Microsoft.Maui.Devices;
using PinballPlus.Game;

namespace PinballPlus;

public partial class MainPage : ContentPage
{
    private int _level = 1;
    private int _score;
    private int _highScore;
    private readonly Random _random = new();

    public MainPage()
    {
        InitializeComponent();
        TableView.Drawable = PinballTableDrawable.Instance;
        PinballTableDrawable.Instance.OnHit = AddScore;
        UpdateUi();
    }

    private void AddScore(int points)
    {
        _score += points;
        if (_score > _highScore) _highScore = _score;
        UpdateUi();
        try { HapticFeedback.Default.Perform(HapticFeedbackType.Click); } catch { }
    }

    private void LaunchClicked(object sender, EventArgs e)
    {
        PinballTableDrawable.Instance.Launch(_random.NextDouble());
        AddScore(100);
    }

    private void LeftClicked(object sender, EventArgs e) => PinballTableDrawable.Instance.Nudge(-1);
    private void RightClicked(object sender, EventArgs e) => PinballTableDrawable.Instance.Nudge(1);

    private void ResetClicked(object sender, EventArgs e)
    {
        _score = 0;
        PinballTableDrawable.Instance.Reset();
        UpdateUi();
    }

    private void NextLevelClicked(object sender, EventArgs e)
    {
        if (_level < 500) _level++;
        _score = 0;
        PinballTableDrawable.Instance.SetLevel(_level);
        UpdateUi();
    }

    private async void SettingsClicked(object sender, EventArgs e)
    {
        await DisplayAlert("Pinball Plus", "Sound and vibration are enabled through the device settings.\n\n500 levels included.\nPackage: com.sathish.pinballplus", "OK");
    }

    private void UpdateUi()
    {
        LevelLabel.Text = $"{_level} / 500";
        ScoreLabel.Text = _score.ToString("D6");
        HighScoreLabel.Text = _highScore.ToString("D6");
    }
}
