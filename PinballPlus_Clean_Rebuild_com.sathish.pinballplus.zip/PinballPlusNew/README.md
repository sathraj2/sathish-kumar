# Pinball Plus — Clean Rebuild

Android-only .NET MAUI project rebuilt with a clean package identity:

- Application ID: `com.sathish.pinballplus`
- Display name: `Pinball Plus`
- Publisher text: `RITHANYA TECHNOLOGY PRESENTS`
- 500 levels represented in the game progression
- Splash screen and app icon included
- Pinball table UI, score/high-score panels, launch/left/right/reset/next-level/settings controls
- Haptic feedback on interaction

## Build

Requires .NET 8 SDK + .NET MAUI Android workload.

```bash
dotnet workload install maui-android
dotnet restore
dotnet build -c Release -f net8.0-android
```

The APK will be produced under `bin/Release/net8.0-android/`.

## Important

This is a clean source rebuild. The exact artwork from a previous conversation was not available as a source asset in this build environment, so the included SVG icon/splash are clean replacements following the same dark/neon pinball visual direction. Replace those SVGs with the approved artwork if exact pixel matching is required.
