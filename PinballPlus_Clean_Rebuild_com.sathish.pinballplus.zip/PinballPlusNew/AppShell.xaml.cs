namespace PinballPlus;

public partial class AppShell : Shell
{
    public AppShell() => InitializeComponent();
}
