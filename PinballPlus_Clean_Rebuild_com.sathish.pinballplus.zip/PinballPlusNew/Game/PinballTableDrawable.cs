using Microsoft.Maui.Graphics;

namespace PinballPlus.Game;

public sealed class PinballTableDrawable : IDrawable
{
    public static PinballTableDrawable Instance { get; } = new();
    public Action<int>? OnHit { get; set; }
    private float _ballX = .5f, _ballY = .88f;
    private float _targetX = .5f;
    private int _level = 1;
    private DateTime _lastFrame = DateTime.UtcNow;

    public void SetLevel(int level) { _level = Math.Clamp(level, 1, 500); Reset(); }
    public void Reset() { _ballX = .5f; _ballY = .88f; _targetX = .5f; }
    public void Launch(double side) { _ballX = .5f + (float)((side - .5) * .18); _ballY = .72f; OnHit?.Invoke(250); }
    public void Nudge(int direction) { _targetX = Math.Clamp(_targetX + direction * .08f, .18f, .82f); OnHit?.Invoke(25); }

    public void Draw(ICanvas canvas, RectF dirtyRect)
    {
        canvas.FillColor = Color.FromArgb("#0D1122");
        canvas.FillRectangle(dirtyRect);
        var w = dirtyRect.Width; var h = dirtyRect.Height;
        canvas.StrokeSize = 3;
        canvas.StrokeColor = Color.FromArgb("#36D7FF");
        canvas.DrawRoundedRectangle(8, 8, w - 16, h - 16, 22);

        canvas.StrokeColor = Color.FromArgb("#FFCC33");
        canvas.StrokeSize = 4;
        var left = w * .13f; var right = w * .87f;
        canvas.DrawLine(left, h * .12f, w * .18f, h * .82f);
        canvas.DrawLine(right, h * .12f, w * .82f, h * .82f);

        // Bumpers
        for (var i = 0; i < 6; i++)
        {
            var x = w * (0.28f + (i % 3) * .22f);
            var y = h * (0.22f + (i / 3) * .18f);
            canvas.FillColor = i % 2 == 0 ? Color.FromArgb("#FF3D81") : Color.FromArgb("#36D7FF");
            canvas.FillCircle(x, y, Math.Min(w, h) * .045f);
            canvas.StrokeColor = Color.FromArgb("#FFFFFF");
            canvas.StrokeSize = 2;
            canvas.DrawCircle(x, y, Math.Min(w, h) * .052f);
        }

        // Level-dependent gates
        var gateCount = 2 + ((_level - 1) % 4);
        canvas.StrokeColor = Color.FromArgb("#A8B0C5");
        canvas.StrokeSize = 2;
        for (var i = 0; i < gateCount; i++)
        {
            var y = h * (.43f + i * .055f);
            canvas.DrawLine(w * .28f, y, w * .72f, y);
        }

        // Ball
        var now = DateTime.UtcNow;
        var dt = (float)Math.Min(.05, (now - _lastFrame).TotalSeconds);
        _lastFrame = now;
        _ballX += (_targetX - _ballX) * Math.Min(1, dt * 8);
        canvas.FillColor = Colors.White;
        canvas.FillCircle(w * _ballX, h * _ballY, Math.Min(w, h) * .035f);
        canvas.StrokeColor = Color.FromArgb("#FFCC33");
        canvas.StrokeSize = 2;
        canvas.DrawCircle(w * _ballX, h * _ballY, Math.Min(w, h) * .045f);

        // Flippers
        canvas.StrokeColor = Color.FromArgb("#FF3D81");
        canvas.StrokeSize = Math.Max(8, Math.Min(w, h) * .035f);
        canvas.DrawLine(w * .27f, h * .89f, w * .44f, h * .84f);
        canvas.DrawLine(w * .73f, h * .89f, w * .56f, h * .84f);

        // Decorative center logo
        canvas.FontColor = Color.FromArgb("#FFFFFF");
        canvas.FontSize = Math.Max(14, w * .055f);
        canvas.Font = Microsoft.Maui.Graphics.Font.DefaultBold;
        canvas.DrawString("PINBALL+", w * .5f, h * .56f, HorizontalAlignment.Center);
    }
}
