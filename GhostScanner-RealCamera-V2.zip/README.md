# GhostScanner Real Camera V2
Android CameraX + ML Kit pose-detection prototype.
Features: live camera, 33-point pose/skeleton overlay, matrix scan effect, night mode, SLS-style overlay, magnetic-field sensor, and MP4 recording.
This detects visual human poses and device sensor readings; it does not scientifically detect ghosts.
Build with Android SDK 35, Build Tools 35.0.0, JDK 17, Gradle 8.13.
