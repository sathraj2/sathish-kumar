package com.sathish.ghostscanner;

import android.Manifest;
import android.content.*; import android.content.pm.PackageManager;
import android.graphics.*; import android.hardware.*; import android.os.*; import android.provider.MediaStore;
import android.view.*; import android.widget.*;
import androidx.activity.ComponentActivity; import androidx.annotation.NonNull; import androidx.camera.core.*;
import androidx.camera.lifecycle.ProcessCameraProvider; import androidx.camera.view.PreviewView; import androidx.camera.video.*;
import androidx.core.app.ActivityCompat; import androidx.core.content.ContextCompat;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.common.InputImage; import com.google.mlkit.vision.pose.*; import com.google.mlkit.vision.pose.defaults.PoseDetectorOptions;
import java.text.SimpleDateFormat; import java.util.*; import java.util.concurrent.*;

public class MainActivity extends ComponentActivity implements SensorEventListener {
 static final int REQ=7; PreviewView preview; Overlay overlay; TextView status,magText; Button record; VideoCapture<Recorder> video; Recording recording; ExecutorService exec; PoseDetector detector; SensorManager sm; Sensor magnet;
 boolean matrix=true,sls=true,night=true,lidar=true; float mag=0;
 @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setFlags(1024,1024);
  FrameLayout root=new FrameLayout(this); preview=new PreviewView(this); preview.setScaleType(PreviewView.ScaleType.FILL_CENTER); root.addView(preview,new FrameLayout.LayoutParams(-1,-1));
  overlay=new Overlay(this); root.addView(overlay,new FrameLayout.LayoutParams(-1,-1));
  LinearLayout top=new LinearLayout(this); top.setPadding(16,8,16,0); TextView title=txt("SPECTRAL SCANNER",12); top.addView(title,new LinearLayout.LayoutParams(0,55,1)); status=txt("READY",12); top.addView(status); root.addView(top);
  LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER);
  Button bm=btn("MATRIX"), bl=btn("LIDAR"), bs=btn("SLS"), br=btn("RECORD"), bn=btn("NIGHT"); record=br;
  bar.addView(bm,new LinearLayout.LayoutParams(0,65,1));bar.addView(bl,new LinearLayout.LayoutParams(0,65,1));bar.addView(bs,new LinearLayout.LayoutParams(0,65,1));bar.addView(br,new LinearLayout.LayoutParams(0,65,1));bar.addView(bn,new LinearLayout.LayoutParams(0,65,1));
  FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(-1,70,Gravity.BOTTOM); root.addView(bar,bp);
  magText=txt("MAG -- µT",11); FrameLayout.LayoutParams mp=new FrameLayout.LayoutParams(-2,45,Gravity.BOTTOM|Gravity.LEFT);mp.leftMargin=12;mp.bottomMargin=75;root.addView(magText,mp);
  setContentView(root);
  bm.setOnClickListener(v->{matrix=!matrix;overlay.invalidate();});bl.setOnClickListener(v->{lidar=!lidar;overlay.invalidate();});bs.setOnClickListener(v->{sls=!sls;overlay.invalidate();});bn.setOnClickListener(v->{night=!night;overlay.invalidate();});br.setOnClickListener(v->toggleRecord());
  exec=Executors.newSingleThreadExecutor(); detector=PoseDetection.getClient(new PoseDetectorOptions.Builder().setDetectorMode(PoseDetectorOptions.STREAM_MODE).build());
  sm=(SensorManager)getSystemService(SENSOR_SERVICE); magnet=sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD); if(magnet!=null)sm.registerListener(this,magnet,SensorManager.SENSOR_DELAY_UI);
  if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CAMERA,Manifest.permission.RECORD_AUDIO},REQ); else start();
 }
 TextView txt(String s,int z){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(z);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
 Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(9);b.setAllCaps(false);b.setBackgroundColor(Color.argb(140,0,15,20));return b;}
 @Override public void onRequestPermissionsResult(int r,@NonNull String[] p,@NonNull int[] g){super.onRequestPermissionsResult(r,p,g);if(r==REQ&&g.length>0&&g[0]==0)start();}
 void start(){ListenableFuture<ProcessCameraProvider> f=ProcessCameraProvider.getInstance(this);f.addListener(()->{try{
  ProcessCameraProvider pc=f.get(); Preview pr=new Preview.Builder().build();pr.setSurfaceProvider(preview.getSurfaceProvider());
  ImageCapture cap=new ImageCapture.Builder().build();
  video=VideoCapture.withOutput(new Recorder.Builder().setQualitySelector(QualitySelector.from(Quality.HD,FallbackStrategy.higherQualityOrLowerThan(Quality.HD))).build());
  ImageAnalysis an=new ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).setTargetResolution(new Size(480,640)).build();
  an.setAnalyzer(exec,img->{android.media.Image m=img.getImage();if(m==null){img.close();return;}InputImage in=InputImage.fromMediaImage(m,img.getImageInfo().getRotationDegrees());
   detector.process(in).addOnSuccessListener(p->runOnUiThread(()->overlay.setPose(p))).addOnFailureListener(e->runOnUiThread(()->overlay.setPose(null))).addOnCompleteListener(x->img.close());});
  pc.unbindAll();pc.bindToLifecycle(this,CameraSelector.DEFAULT_BACK_CAMERA,pr,cap,video,an);
 }catch(Exception e){runOnUiThread(()->status.setText("CAMERA ERROR"));}},ContextCompat.getMainExecutor(this));}
 void toggleRecord(){if(recording!=null){recording.stop();return;} if(video==null)return;
  String n="Spectral_"+new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date())+".mp4";ContentValues cv=new ContentValues();cv.put(MediaStore.Video.Media.DISPLAY_NAME,n);cv.put(MediaStore.Video.Media.MIME_TYPE,"video/mp4");cv.put(MediaStore.Video.Media.RELATIVE_PATH,"Movies/SpectralScanner");
  MediaStoreOutputOptions out=new MediaStoreOutputOptions.Builder(getContentResolver(),MediaStore.Video.Media.EXTERNAL_CONTENT_URI).setContentValues(cv).build();
  PendingRecording p=video.getOutput().prepareRecording(this,out);if(ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)==0)p.withAudioEnabled();
  recording=p.start(ContextCompat.getMainExecutor(this),e->{if(e instanceof VideoRecordEvent.Start){record.setText("STOP");status.setText("RECORDING");}if(e instanceof VideoRecordEvent.Finalize){record.setText("RECORD");status.setText("READY");recording=null;}});
 }
 @Override public void onSensorChanged(SensorEvent e){if(e.sensor.getType()==Sensor.TYPE_MAGNETIC_FIELD){mag=(float)Math.sqrt(e.values[0]*e.values[0]+e.values[1]*e.values[1]+e.values[2]*e.values[2]);magText.setText(String.format(Locale.US,"MAG %.1f µT",mag));overlay.invalidate();}}
 @Override public void onAccuracyChanged(Sensor s,int a){} @Override protected void onDestroy(){super.onDestroy();if(sm!=null)sm.unregisterListener(this);if(exec!=null)exec.shutdown();if(detector!=null)detector.close();}

 class Overlay extends View{
  Paint p=new Paint(1);Pose pose; int[][] bones={{11,12},{11,13},{13,15},{12,14},{14,16},{11,23},{12,24},{23,24},{23,25},{25,27},{24,26},{26,28}};
  Overlay(Context c){super(c);p.setTypeface(Typeface.MONOSPACE);}
  void setPose(Pose x){pose=x;status.setText(x!=null&&x.getAllPoseLandmarks().size()>4?"FIGURE DETECTED":"READY");invalidate();}
  PointF q(int type){if(pose==null)return null;PoseLandmark l=pose.getPoseLandmark(type);if(l==null)return null;PointF a=l.getPosition();float s=Math.max(getWidth()/480f,getHeight()/640f);return new PointF((getWidth()-480*s)/2+a.x*s,(getHeight()-640*s)/2+a.y*s);}
  protected void onDraw(Canvas c){super.onDraw(c);if(night){p.setColor(Color.argb(55,0,0,25));c.drawRect(0,0,getWidth(),getHeight(),p);}
   if(matrix){p.setColor(Color.argb(65,50,255,180));p.setStrokeWidth(1);for(int x=0;x<getWidth();x+=7)c.drawLine(x,0,x,getHeight(),p);}
   if(lidar){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);p.setColor(Color.argb(80,0,255,220));float cx=getWidth()/2f,cy=getHeight()/2f;for(int i=1;i<7;i++)c.drawCircle(cx,cy,Math.min(getWidth(),getHeight())*i/14f,p);p.setStyle(Paint.Style.FILL);}
   if(pose!=null&&sls){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(Color.CYAN);for(int[] b:bones){PointF a=q(b[0]),d=q(b[1]);if(a!=null&&d!=null)c.drawLine(a.x,a.y,d.x,d.y,p);}p.setStyle(Paint.Style.FILL);for(PoseLandmark l:pose.getAllPoseLandmarks()){PointF a=q(l.getLandmarkType());if(a!=null)c.drawCircle(a.x,a.y,5,p);}}
   p.setColor(Color.WHITE);p.setTextSize(11);c.drawText("SLS "+(sls?"ON":"OFF"),12,35,p);c.drawText(String.format(Locale.US,"MAG %.1f µT",mag),12,52,p);
  }
 }
}
