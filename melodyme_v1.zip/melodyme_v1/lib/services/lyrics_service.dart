import '../models/lyric_line.dart';

class LyricsService {
  // V1 demo timing. Production will load licensed, synchronized lyrics.
  static const demoLyrics = <LyricLine>[
    LyricLine(start: Duration(seconds: 0), end: Duration(seconds: 4), text: 'Your first lyric line'),
    LyricLine(start: Duration(seconds: 4), end: Duration(seconds: 8), text: 'Your second lyric line'),
    LyricLine(start: Duration(seconds: 8), end: Duration(seconds: 12), text: 'Your third lyric line'),
  ];
}
