import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';

class RecordingService {
  final AudioRecorder _recorder = AudioRecorder();

  Future<bool> requestPermission() => _recorder.hasPermission();

  Future<String?> start() async {
    if (!await _recorder.hasPermission()) return null;
    final dir = await getApplicationDocumentsDirectory();
    final path = '${dir.path}/melodyme_${DateTime.now().millisecondsSinceEpoch}.m4a';
    await _recorder.start(
      const RecordConfig(
        encoder: AudioEncoder.aacLc,
        sampleRate: 44100,
        numChannels: 1,
      ),
      path: path,
    );
    return path;
  }

  Future<String?> stop() => _recorder.stop();

  Future<void> dispose() => _recorder.dispose();
}
