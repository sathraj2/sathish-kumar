import 'package:flutter/material.dart';
import 'karaoke_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF120812),
      appBar: AppBar(title: const Text('MelodyMe'), backgroundColor: Colors.transparent),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Sing it. Feel it. Share it.', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
          const SizedBox(height: 30),
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(color: const Color(0xFF281329), borderRadius: BorderRadius.circular(24)),
            child: Column(children: [
              const Icon(Icons.mic, color: Colors.pinkAccent, size: 60),
              const SizedBox(height: 12),
              const Text('Test Karaoke Song', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
              const SizedBox(height: 18),
              SizedBox(width: double.infinity, child: FilledButton.icon(
                icon: const Icon(Icons.mic), label: const Text('Start Singing'),
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const KaraokeScreen())),
              )),
            ]),
          ),
        ]),
      ),
    );
  }
}
