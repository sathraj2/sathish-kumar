import 'dart:async';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import '../services/lyrics_service.dart';
import '../services/recording_service.dart';
import '../widgets/music_bubbles.dart';

class KaraokeScreen extends StatefulWidget {
  const KaraokeScreen({super.key});
  @override
  State<KaraokeScreen> createState() => _KaraokeScreenState();
}

class _KaraokeScreenState extends State<KaraokeScreen> {
  final _player = AudioPlayer();
  final _recorder = RecordingService();
  Timer? _timer;
  Duration _position = Duration.zero;
  bool _recording = false;
  String? _savedPath;

  @override
  void initState() {
    super.initState();
    _player.positionStream.listen((p) { if (mounted) setState(() => _position = p); });
  }

  int get activeIndex {
    final lyrics = LyricsService.demoLyrics;
    for (var i = 0; i < lyrics.length; i++) {
      if (_position >= lyrics[i].start && _position < lyrics[i].end) return i;
    }
    return -1;
  }

  Future<void> _toggleRecording() async {
    if (_recording) {
      _savedPath = await _recorder.stop();
      await _player.pause();
      if (mounted) setState(() => _recording = false);
      return;
    }
    final path = await _recorder.start();
    if (path == null) return;
    setState(() => _recording = true);
    // Demo build: audio track is intentionally optional until a licensed asset is added.
  }

  @override
  void dispose() { _timer?.cancel(); _player.dispose(); _recorder.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final lyrics = LyricsService.demoLyrics;
    return Scaffold(
      backgroundColor: const Color(0xFF100710),
      appBar: AppBar(title: const Text('Karaoke'), backgroundColor: Colors.transparent),
      body: Stack(children: [
        const Positioned.fill(child: MusicBubbles()),
        Column(children: [
          const SizedBox(height: 18),
          const Icon(Icons.mic, color: Colors.pinkAccent, size: 64),
          const Text('Test Karaoke Song', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const Spacer(),
          ...lyrics.map((line) => Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
            child: Text(line.text, textAlign: TextAlign.center, style: TextStyle(
              fontSize: activeIndex == lyrics.indexOf(line) ? 25 : 19,
              fontWeight: activeIndex == lyrics.indexOf(line) ? FontWeight.bold : FontWeight.normal,
              color: activeIndex == lyrics.indexOf(line) ? Colors.pinkAccent : Colors.white70,
            )),
          )),
          const Spacer(),
          if (_savedPath != null) Padding(padding: const EdgeInsets.all(12), child: Text('Saved recording: $_savedPath', maxLines: 2, overflow: TextOverflow.ellipsis)),
          Padding(padding: const EdgeInsets.all(24), child: FloatingActionButton.large(
            backgroundColor: _recording ? Colors.redAccent : Colors.pinkAccent,
            onPressed: _toggleRecording,
            child: Icon(_recording ? Icons.stop : Icons.mic, size: 36),
          )),
        ]),
      ]),
    );
  }
}
