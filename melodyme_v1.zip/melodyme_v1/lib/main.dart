import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() => runApp(const MelodyMeApp());

class MelodyMeApp extends StatelessWidget {
  const MelodyMeApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'MelodyMe',
      theme: ThemeData.dark(useMaterial3: true).copyWith(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.pink, brightness: Brightness.dark),
        scaffoldBackgroundColor: const Color(0xFF100710),
      ),
      home: const SplashScreen(),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override State<SplashScreen> createState() => _SplashScreenState();
}
class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late final AnimationController c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1300))..forward();
  @override void initState() { super.initState(); Future.delayed(const Duration(milliseconds: 1600), () { if (mounted) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomeScreen())); }); }
  @override void dispose() { c.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => Scaffold(body: Center(child: ScaleTransition(scale: CurvedAnimation(parent: c, curve: Curves.easeOutBack), child: Column(mainAxisSize: MainAxisSize.min, children: const [Icon(Icons.mic, color: Colors.pinkAccent, size: 100), SizedBox(height: 18), Text('MelodyMe', style: TextStyle(fontSize: 38, fontWeight: FontWeight.bold, color: Colors.pinkAccent)), SizedBox(height: 8), Text('Sing it. Feel it. Share it.')])));
}
