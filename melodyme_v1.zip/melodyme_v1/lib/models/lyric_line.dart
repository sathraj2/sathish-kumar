class LyricLine {
  final Duration start;
  final Duration end;
  final String text;

  const LyricLine({required this.start, required this.end, required this.text});
}
