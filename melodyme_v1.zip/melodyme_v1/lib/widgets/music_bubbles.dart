import 'package:flutter/material.dart';

class MusicBubbles extends StatefulWidget {
  const MusicBubbles({super.key});
  @override
  State<MusicBubbles> createState() => _MusicBubblesState();
}

class _MusicBubblesState extends State<MusicBubbles> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 3),
  )..repeat();

  @override
  void dispose() { _controller.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (_, __) => Stack(
        children: List.generate(7, (i) {
          final t = (_controller.value + i / 7) % 1.0;
          return Positioned(
            left: 25.0 + i * 45.0,
            bottom: 20 + t * 130,
            child: Opacity(
              opacity: 1 - t,
              child: Icon(i.isEven ? Icons.music_note : Icons.circle, color: Colors.pinkAccent, size: 14 + (i % 3) * 5),
            ),
          );
        }),
      ),
    );
  }
}
