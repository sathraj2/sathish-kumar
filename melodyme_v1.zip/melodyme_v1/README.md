# MelodyMe V1 — Karaoke Prototype

## Goal
Prove the first MelodyMe flow on a real Android device:

Song → Lyrics → Microphone → Record → Playback/Save.

## Current scaffold
- Pink MelodyMe branding and animated splash.
- Home screen with Start Singing.
- Karaoke screen with synchronized demo lyric timing.
- Animated music bubbles.
- Microphone recording to app-private storage using `record`.
- Placeholder for licensed karaoke audio.

## Important validation status
Flutter SDK is not available in the build environment used to prepare this scaffold, so an APK build has **not** been claimed or marked as verified.

Before calling V1 complete:
1. Install Flutter and Android SDK locally.
2. Add a licensed karaoke/instrumental asset under `assets/audio/`.
3. Replace demo lyrics with licensed synchronized lyrics.
4. Add Android microphone permission.
5. Run `flutter pub get` and `flutter analyze`.
6. Build and test on a physical Android device.
7. Verify recording, playback, storage, permissions, interruption handling and audio quality.

## Next implementation step
Wire the licensed audio asset into `just_audio`, synchronize the lyric engine to the player position, then implement mixed music+voice playback/export.
