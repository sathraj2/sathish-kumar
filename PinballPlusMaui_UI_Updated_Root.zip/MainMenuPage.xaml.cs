namespace PinballPlusMaui;

public partial class MainMenuPage : ContentPage
{
    public MainMenuPage() => InitializeComponent();

    async void PlayClicked(object sender, EventArgs e) => await Navigation.PushAsync(new MainPage(1));
    async void LevelsClicked(object sender, EventArgs e) => await Navigation.PushAsync(new LevelSelectPage());
    async void AchievementsClicked(object sender, EventArgs e) => await DisplayAlert("Achievements", "Complete levels and collect stars to unlock achievements.", "OK");
    async void LeaderboardClicked(object sender, EventArgs e) => await DisplayAlert("Leaderboard", "Leaderboard is ready for future online integration.", "OK");
    async void SettingsClicked(object sender, EventArgs e) => await DisplayAlert("Settings", "Sound and vibration settings will be available here.", "OK");
    async void ExitClicked(object sender, EventArgs e) => await DisplayAlert("Pinball Plus", "Thanks for playing!", "OK");
}
