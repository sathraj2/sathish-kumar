namespace PinballPlusMaui;

public partial class SplashPage : ContentPage
{
    public SplashPage() => InitializeComponent();

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        Progress.Progress = 0.05;
        await Progress.ProgressTo(1, 1600, Easing.CubicInOut);
        await Task.Delay(350);
        if (Navigation.NavigationStack.Count > 0)
            await Navigation.PushAsync(new MainMenuPage());
        Navigation.RemovePage(this);
    }
}
