using Microsoft.Maui.Graphics;

namespace PinballPlusMaui;

public sealed class PinballDrawable : IDrawable
{
    readonly PinballGame _game;
    readonly bool _overlayOnly;
    public PinballDrawable(PinballGame game, bool overlayOnly = false) { _game = game; _overlayOnly = overlayOnly; }

    public void Draw(ICanvas c, RectF r)
    {
        if (!_overlayOnly) c.FillColor = Color.FromArgb("#0C111B");
        float w = r.Width, h = r.Height;
        float sx = MathF.Min(w, h * 0.58f);
        float ox = (w - sx) / 2f;
        float bx = ox + sx * _game.BallX;
        float by = h * _game.BallY;
        float br = MathF.Max(6, sx * .026f);
        c.FillColor = Color.FromArgb("#FFFFFF");
        c.FillCircle(bx, by, br);
        c.StrokeColor = Color.FromArgb("#7DD3FC"); c.StrokeSize = 2; c.DrawCircle(bx, by, br + 2);

        c.StrokeColor = _game.LeftFlipper ? Color.FromArgb("#FFF7A8") : Color.FromArgb("#FFFFFF"); c.StrokeSize = 14;
        c.DrawLine(ox + sx*.28f, h*.88f, ox + sx*.48f, h*.84f);
        c.StrokeColor = _game.RightFlipper ? Color.FromArgb("#FFF7A8") : Color.FromArgb("#FFFFFF");
        c.DrawLine(ox + sx*.72f, h*.88f, ox + sx*.52f, h*.84f);
    }
}
