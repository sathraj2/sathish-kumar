# Pinball Plus — MAUI

Pinball Plus is a clean-room .NET MAUI recreation using the supplied neon Pinball Plus UI design as the visual reference.

## UI
- Rithanya Technology animated-style splash screen
- Pinball Plus neon main menu
- 500-level progression concept
- Level selection
- Neon gameplay table with touch flippers
- Score/level header and pause control

## Build Android APK
```bash
dotnet workload install maui-android
dotnet publish PinballPlusMaui.csproj -f net10.0-android -c Debug -p:AndroidPackageFormat=apk -p:AndroidLinkMode=None -p:AndroidSdkDirectory=/workspaces/android-sdk -p:JavaSdkDirectory=$JAVA_HOME
```
