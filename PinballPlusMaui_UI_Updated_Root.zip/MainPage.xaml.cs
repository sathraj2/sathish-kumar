namespace PinballPlusMaui;

public partial class MainPage : ContentPage
{
    readonly PinballGame _game;
    readonly int _level;
    IDispatcherTimer? _timer;

    public MainPage(int level = 1)
    {
        InitializeComponent();
        _level = Math.Clamp(level, 1, 500);
        LevelLabel.Text = $"LEVEL {_level}";
        _game = new PinballGame();
        GameOverlay.Drawable = new PinballDrawable(_game, true);
        _game.StateChanged += (_, _) => GameOverlay.Invalidate();

        _timer = Dispatcher.CreateTimer();
        _timer.Interval = TimeSpan.FromMilliseconds(16);
        _timer.Tick += (_, _) => { _game.Update(0.016f, GameOverlay.Width, GameOverlay.Height); GameOverlay.Invalidate(); };
        _timer.Start();
    }

    async void BackClicked(object sender, EventArgs e) => await Navigation.PopAsync();
    async void PauseClicked(object sender, EventArgs e) { _timer?.Stop(); await DisplayAlert("Paused", "Tap OK to continue.", "OK"); _timer?.Start(); }
    void LeftClicked(object sender, EventArgs e) => _game.LeftFlipper = true;
    void RightClicked(object sender, EventArgs e) => _game.RightFlipper = true;
    void LaunchClicked(object sender, EventArgs e) => _game.Launch();

    void OnTouchStart(object? sender, TouchEventArgs e)
    {
        foreach (var p in e.Touches)
        {
            if (p.X < GameOverlay.Width / 2) _game.LeftFlipper = true;
            else _game.RightFlipper = true;
        }
        _game.Launch();
    }

    void OnTouchEnd(object? sender, TouchEventArgs e)
    {
        _game.LeftFlipper = false;
        _game.RightFlipper = false;
    }

    protected override void OnDisappearing() { _timer?.Stop(); base.OnDisappearing(); }
}
