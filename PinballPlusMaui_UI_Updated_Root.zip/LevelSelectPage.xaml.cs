namespace PinballPlusMaui;

public partial class LevelSelectPage : ContentPage
{
    public LevelSelectPage() => InitializeComponent();

    async void Level1Clicked(object s, EventArgs e) => await OpenLevel(1);
    async void Level2Clicked(object s, EventArgs e) => await OpenLevel(2);
    async void Level3Clicked(object s, EventArgs e) => await OpenLevel(3);
    async void Level4Clicked(object s, EventArgs e) => await OpenLevel(4);
    async void Level5Clicked(object s, EventArgs e) => await OpenLevel(5);
    async void Level6Clicked(object s, EventArgs e) => await OpenLevel(6);
    async void Level7Clicked(object s, EventArgs e) => await OpenLevel(7);
    async void Level8Clicked(object s, EventArgs e) => await OpenLevel(8);
    async void Level9Clicked(object s, EventArgs e) => await OpenLevel(9);
    async void Level10Clicked(object s, EventArgs e) => await OpenLevel(10);
    async void Level11Clicked(object s, EventArgs e) => await OpenLevel(11);
    async void Level12Clicked(object s, EventArgs e) => await OpenLevel(12);
    async void Level13Clicked(object s, EventArgs e) => await OpenLevel(13);
    async void Level14Clicked(object s, EventArgs e) => await OpenLevel(14);
    async void Level15Clicked(object s, EventArgs e) => await OpenLevel(15);
    async void Level16Clicked(object s, EventArgs e) => await OpenLevel(16);

    async Task OpenLevel(int level) => await Navigation.PushAsync(new MainPage(level));
}
