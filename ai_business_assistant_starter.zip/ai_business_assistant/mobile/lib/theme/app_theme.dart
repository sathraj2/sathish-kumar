import 'package:flutter/material.dart';

class AppTheme {
  static const primary = Color(0xFF5B45F5);
  static const primaryDark = Color(0xFF3421B8);
  static const background = Color(0xFFF7F8FC);
  static const text = Color(0xFF17182A);
  static const muted = Color(0xFF74788D);
  static const success = Color(0xFF17A673);
  static const danger = Color(0xFFE5484D);

  static ThemeData light() => ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: background,
        colorScheme: ColorScheme.fromSeed(seedColor: primary),
        fontFamily: 'Roboto',
        appBarTheme: const AppBarTheme(
          backgroundColor: background,
          foregroundColor: text,
          elevation: 0,
          centerTitle: false,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFFE7E8F0)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: primary, width: 1.5),
          ),
        ),
      );
}
