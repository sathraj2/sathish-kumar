import 'package:flutter/material.dart';
import 'theme/app_theme.dart';

void main() => runApp(const BusinessAssistantApp());

class BusinessAssistantApp extends StatelessWidget {
  const BusinessAssistantApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'AI Business Assistant',
      theme: AppTheme.light(),
      home: const MainShell(),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;
  final pages = const [DashboardPage(), CustomersPage(), InvoicePage(), ReportsPage(), MorePage()];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: pages[index]),
      floatingActionButton: FloatingActionButton(
        backgroundColor: AppTheme.primary,
        foregroundColor: Colors.white,
        onPressed: () => showModalBottomSheet(
          context: context,
          showDragHandle: true,
          builder: (_) => const AiAssistantSheet(),
        ),
        child: const Icon(Icons.auto_awesome_rounded),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.people_outline), selectedIcon: Icon(Icons.people), label: 'Customers'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'Invoice'),
          NavigationDestination(icon: Icon(Icons.bar_chart_outlined), selectedIcon: Icon(Icons.bar_chart), label: 'Reports'),
          NavigationDestination(icon: Icon(Icons.more_horiz), selectedIcon: Icon(Icons.more_horiz), label: 'More'),
        ],
      ),
    );
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});
  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.fromLTRB(20, 16, 20, 100), children: [
      Row(children: [
        const CircleAvatar(radius: 23, child: Icon(Icons.storefront_rounded)),
        const SizedBox(width: 12),
        const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Good morning, Rajesh 👋', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 17)), Text('ABC Electricals', style: TextStyle(color: AppTheme.muted))])),
        IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none_rounded)),
      ]),
      const SizedBox(height: 22),
      const Text('Business overview', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
      const SizedBox(height: 12),
      const Row(children: [Expanded(child: MetricCard(title: "Today's Sales", value: '₹24,500', change: '+12%', positive: true)), SizedBox(width: 12), Expanded(child: MetricCard(title: 'This Month', value: '₹4,82,000', change: '+18%', positive: true))]),
      const SizedBox(height: 12),
      const Row(children: [Expanded(child: MetricCard(title: 'Receivables', value: '₹84,500', change: '12 pending', positive: false)), SizedBox(width: 12), Expanded(child: MetricCard(title: 'Expenses', value: '₹2,10,000', change: 'This month', positive: false))]),
      const SizedBox(height: 24),
      const Text('Quick actions', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
      const SizedBox(height: 12),
      Wrap(spacing: 10, runSpacing: 10, children: [
        ActionTile(icon: Icons.receipt_long, label: 'Invoice'), ActionTile(icon: Icons.person_add_alt_1, label: 'Customer'),
        ActionTile(icon: Icons.inventory_2_outlined, label: 'Product'), ActionTile(icon: Icons.account_balance_wallet_outlined, label: 'Expense'),
        ActionTile(icon: Icons.payments_outlined, label: 'Payment'), ActionTile(icon: Icons.auto_awesome, label: 'AI Assistant'),
      ]),
      const SizedBox(height: 24),
      Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(gradient: const LinearGradient(colors: [AppTheme.primaryDark, AppTheme.primary]), borderRadius: BorderRadius.circular(22)), child: const Row(children: [Icon(Icons.auto_awesome, color: Colors.white, size: 32), SizedBox(width: 14), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Ask your AI assistant', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 17)), SizedBox(height: 4), Text('“Who owes me money?” or “How were sales this month?”', style: TextStyle(color: Colors.white70))]))])),
    ]);
  }
}

class MetricCard extends StatelessWidget { final String title, value, change; final bool positive; const MetricCard({super.key, required this.title, required this.value, required this.change, required this.positive}); @override Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFEAEAF2))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(color: AppTheme.muted)), const SizedBox(height: 8), Text(value, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w800)), const SizedBox(height: 5), Text(change, style: TextStyle(color: positive ? AppTheme.success : AppTheme.danger, fontWeight: FontWeight.w600))])); }
class ActionTile extends StatelessWidget { final IconData icon; final String label; const ActionTile({super.key, required this.icon, required this.label}); @override Widget build(BuildContext context) => SizedBox(width: 105, child: Container(padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 8), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFFEAEAF2))), child: Column(children: [Icon(icon, color: AppTheme.primary), const SizedBox(height: 7), Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600))])); }

class CustomersPage extends StatelessWidget { const CustomersPage({super.key}); @override Widget build(BuildContext context) => AppListPage(title: 'Customers', addLabel: 'Add', items: const [['Rajesh Kumar','₹8,500 due'],['Priya Sharma','₹12,000 due'],['Kumar Enterprises','₹0 paid'],['Sunil Verma','₹5,200 due'],['Anita Traders','₹18,000 due'],['Global Solutions','₹0 paid']]); }
class AppListPage extends StatelessWidget { final String title, addLabel; final List<List<String>> items; const AppListPage({super.key, required this.title, required this.addLabel, required this.items}); @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.fromLTRB(20, 16, 20, 40), children: [Row(children: [Expanded(child: Text(title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800))), FilledButton.icon(onPressed: () {}, icon: const Icon(Icons.add), label: Text(addLabel))]), const SizedBox(height: 14), const TextField(decoration: InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search...')), const SizedBox(height: 14), ...items.map((x) => Card(margin: const EdgeInsets.only(bottom: 10), elevation: 0, child: ListTile(leading: CircleAvatar(child: Text(x[0][0])), title: Text(x[0], style: const TextStyle(fontWeight: FontWeight.w700)), subtitle: Text(x[1], style: TextStyle(color: x[1].contains('due') ? AppTheme.danger : AppTheme.success)), trailing: const Icon(Icons.chevron_right))))]); }
class InvoicePage extends StatelessWidget { const InvoicePage({super.key}); @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.fromLTRB(20, 16, 20, 40), children: [Row(children: [const Expanded(child: Text('Invoices', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800))), FilledButton.icon(onPressed: () {}, icon: const Icon(Icons.add), label: const Text('Create'))]), const SizedBox(height: 18), const MetricCard(title: 'Outstanding', value: '₹84,500', change: '12 invoices pending', positive: false), const SizedBox(height: 18), ...['INV-0012  •  Rajesh Kumar  •  ₹10,000','INV-0011  •  Priya Sharma  •  ₹8,500','INV-0010  •  Kumar Enterprises  •  ₹24,000'].map((e) => Card(elevation: 0, child: ListTile(title: Text(e, style: const TextStyle(fontWeight: FontWeight.w700)), subtitle: const Text('Paid / Pending'), trailing: const Icon(Icons.chevron_right))))]); }
class ReportsPage extends StatelessWidget { const ReportsPage({super.key}); @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.fromLTRB(20, 16, 20, 40), children: [const Text('Reports', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)), const SizedBox(height: 16), const Row(children: [Expanded(child: MetricCard(title: 'Sales', value: '₹4,82,000', change: '+18%', positive: true)), SizedBox(width: 12), Expanded(child: MetricCard(title: 'Profit', value: '₹2,72,000', change: '+20%', positive: true))]), const SizedBox(height: 20), Container(height: 260, padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Sales overview', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)), SizedBox(height: 20), Expanded(child: Center(child: Text('Chart component will be added in the next UI milestone.')))]))]); }
class MorePage extends StatelessWidget { const MorePage({super.key}); @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.fromLTRB(20, 16, 20, 40), children: [const Text('More', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)), const SizedBox(height: 16), ...['Business Profile','Products','Expenses','Payments','AI Assistant','Employees','Notifications','Currency & Tax','Backup & Restore','Subscription','Security','Help & Support'].map((e) => Card(elevation: 0, child: ListTile(title: Text(e), trailing: const Icon(Icons.chevron_right))))]); }
class AiAssistantSheet extends StatelessWidget { const AiAssistantSheet({super.key}); @override Widget build(BuildContext context) => Padding(padding: const EdgeInsets.fromLTRB(20, 8, 20, 30), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [const Row(children: [CircleAvatar(backgroundColor: Color(0xFFEAE7FF), child: Icon(Icons.auto_awesome, color: AppTheme.primary)), SizedBox(width: 12), Text('AI Business Assistant', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800))]), const SizedBox(height: 18), const Text('Try asking:', style: TextStyle(color: AppTheme.muted)), const SizedBox(height: 10), ...['How much did I sell this month?','Who owes me money?','Create an invoice for Rajesh','What was my top-selling product?'].map((e) => Padding(padding: const EdgeInsets.only(bottom: 8), child: OutlinedButton(onPressed: () {}, child: Align(alignment: Alignment.centerLeft, child: Text(e))))), const SizedBox(height: 4), const TextField(decoration: InputDecoration(hintText: 'Type your question...', suffixIcon: Icon(Icons.send, color: AppTheme.primary))) ])); }
