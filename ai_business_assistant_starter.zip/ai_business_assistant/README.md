# AI Business Assistant

Initial production-oriented starter for the Flutter mobile app and ASP.NET Core API.

## Mobile

`mobile/` contains the first runnable UI milestone based on the approved end-to-end design. It currently uses only Flutter Material/Cupertino packages so the UI can be run without additional runtime services.

Run from `mobile/`:

```bash
flutter pub get
flutter run
```

## API

`backend/Api/` contains the ASP.NET Core 8 API skeleton.

Run from `backend/Api/`:

```bash
dotnet restore
dotnet run
```

Health endpoint: `/health`

## Next milestones

1. Refine all screens against the approved design.
2. Add navigation and form validation.
3. Add PostgreSQL + EF Core.
4. Add JWT authentication.
5. Add customers/products/invoices/payments/expenses APIs.
6. Add AI service behind the API.
7. Add Google Play Billing.
8. Add CI/CD and cloud deployment.
