@echo off
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle -p "%~dp0" %*
  exit /b %ERRORLEVEL%
)
echo Gradle is not installed. Use a cloud Android builder or GitHub Actions.
exit /b 1
