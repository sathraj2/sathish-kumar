package com.sathish.ghostscanner;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.view.*;
import android.content.*;
import java.util.*;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setFlags(1024,1024); setContentView(new ScannerView(this)); }
}

class ScannerView extends View {
  Paint p=new Paint(3); Paint stroke=new Paint(3); float phase=0; boolean matrix=true,lidar=true,sls=true,night=true,record=false; Random rnd=new Random(7);
  ScannerView(Context c){super(c); p.setTypeface(Typeface.MONOSPACE); stroke.setStyle(Paint.Style.STROKE); setFocusable(true);}
  protected void onDraw(Canvas c){ int w=getWidth(),h=getHeight();
    c.drawColor(Color.rgb(2,5,9));
    // scan chamber
    p.setStyle(Paint.Style.FILL);
    LinearGradient g=new LinearGradient(w*.12f,0,w*.88f,0,new int[]{Color.rgb(12,50,45),Color.rgb(3,9,50),Color.rgb(12,50,45)},null,Shader.TileMode.CLAMP); p.setShader(g); c.drawRect(w*.10f,80,w*.90f,h-115,p); p.setShader(null);
    // flowing scan lines
    stroke.setStrokeWidth(1);
    for(int y=100;y<h-125;y+=6){ float wob=(float)Math.sin((y+phase)*.025)*8; stroke.setColor(Color.argb(85,20,150,180)); c.drawLine(w*.16f+wob,y,w*.84f-wob,y,stroke); }
    for(int x=(int)(w*.11f);x<w*.9f;x+=5){ float a=80+(int)(50*Math.sin(x*.05+phase*.03)); stroke.setColor(Color.argb(a,30,180,150)); c.drawLine(x,90,x+(float)Math.sin(x*.03+phase*.02)*8,h-120,stroke); }
    // blue core
    p.setShader(new RadialGradient(w/2,h*.52f,w*.45f,new int[]{Color.argb(230,0,0,150),Color.argb(120,0,10,80),Color.TRANSPARENT},null,Shader.TileMode.CLAMP)); c.drawRect(w*.18f,100,w*.82f,h-130,p); p.setShader(null);
    drawFigure(c,w/2f,h*.62f,Math.min(w,h)*.25f);
    drawTop(c,w); drawBottom(c,w,h);
    phase+=1.7f; postInvalidateDelayed(33);
  }
  void drawFigure(Canvas c,float cx,float cy,float s){
    stroke.setColor(Color.argb(170,80,230,220)); stroke.setStrokeWidth(1.1f);
    Path outline=new Path();
    outline.moveTo(cx-s*.10f,cy-s*1.05f); outline.lineTo(cx+s*.10f,cy-s*1.05f); outline.lineTo(cx+s*.14f,cy-s*.86f); outline.lineTo(cx+s*.38f,cy-s*.72f); outline.lineTo(cx+s*.45f,cy-s*.20f); outline.lineTo(cx+s*.27f,cy+s*.02f); outline.lineTo(cx+s*.22f,cy+s*.80f); outline.lineTo(cx+s*.07f,cy+s*1.05f); outline.lineTo(cx-s*.08f,cy+s*1.05f); outline.lineTo(cx-s*.23f,cy+s*.80f); outline.lineTo(cx-s*.28f,cy+s*.02f); outline.lineTo(cx-s*.45f,cy-s*.20f); outline.lineTo(cx-s*.38f,cy-s*.72f); outline.lineTo(cx-s*.14f,cy-s*.86f); outline.close(); c.drawPath(outline,stroke);
    // grid mesh
    for(float yy=-1.0f;yy<=1.0f;yy+=.08f){ float width=s*(.10f+.38f*(1-Math.abs(yy-.05f))); c.drawLine(cx-width,cy+yy*s,cx+width,cy+yy*s,stroke); }
    for(float xx=-.42f;xx<=.42f;xx+=.08f){ c.drawLine(cx+xx*s,cy-s*.75f,cx+xx*s*.55f,cy+s*.95f,stroke); }
    p.setStyle(Paint.Style.FILL); p.setColor(Color.argb(40,0,255,230)); c.drawCircle(cx,cy-s*.55f,s*.12f,p);
  }
  void drawTop(Canvas c,int w){
    p.setColor(Color.WHITE);p.setTextSize(15);p.setTypeface(Typeface.MONOSPACE);
    c.drawText("SPECTRAL SCANNER",20,32,p); c.drawText(record?"● REC":"READY",w-105,32,p);
    stroke.setColor(Color.argb(170,255,255,255)); stroke.setStrokeWidth(2); c.drawRect(20,50,58,78,stroke); c.drawLine(28,59,50,59,stroke); c.drawLine(28,69,50,69,stroke);
    c.drawCircle(w-38,64,18,stroke); c.drawCircle(w-38,64,8,stroke);
  }
  void drawBottom(Canvas c,int w,int h){
    p.setColor(Color.argb(220,3,8,10));c.drawRect(0,h-112,w,h,p); p.setColor(Color.rgb(60,210,165));p.setTextSize(12);
    String[] a={"MATRIX","LIDAR","SLS","RECORD","NIGHT"}; boolean[] b={matrix,lidar,sls,record,night}; float cell=w/5f;
    for(int i=0;i<5;i++){float x=i*cell; p.setColor(b[i]?Color.rgb(80,220,170):Color.GRAY); c.drawText(a[i],x+12,h-77,p); p.setTextSize(10);p.setColor(Color.LTGRAY);c.drawText(b[i]?"enabled":"disabled",x+12,h-57,p);p.setTextSize(12); if(i<4){stroke.setColor(Color.argb(80,255,255,255));c.drawLine(x+cell,h-112,x+cell,h,stroke);}}
    p.setColor(Color.WHITE);p.setTextSize(11);c.drawText("TAP A MODE TO TOGGLE • TAP RECORD TO CAPTURE",w/2-150,h-18,p);
  }
  public boolean onTouchEvent(android.view.MotionEvent e){ if(e.getAction()!=MotionEvent.ACTION_UP)return true; float y=e.getY(),x=e.getX(); int h=getHeight(),w=getWidth(); if(y>h-125){int i=(int)(x/(w/5f)); if(i==0)matrix=!matrix; if(i==1)lidar=!lidar; if(i==2)sls=!sls; if(i==3)record=!record; if(i==4)night=!night; invalidate();} return true; }
}
