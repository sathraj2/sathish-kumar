# Spectral Scanner — Online APK Build

This project is prepared for cloud Android builders. No Android Studio is required.

## Option A: Cloud Android Builder
1. Upload this ZIP to an online Android project builder.
2. Select **Build APK** (not AAB).
3. If the builder offers a Gradle version, use **8.11.1** and JDK **17**.
4. If it asks for a module, select `app`.

## Option B: GitHub Actions (free for public repositories)
1. Create a GitHub repository.
2. Upload/extract this project so `settings.gradle` and `app/` are at the repository root.
3. Go to **Actions** → **Build APK** → **Run workflow**.
4. Download the `spectral-scanner-debug-apk` artifact.

The app is a UI prototype inspired by the supplied reference image. It does not claim to detect real ghosts or paranormal entities.
