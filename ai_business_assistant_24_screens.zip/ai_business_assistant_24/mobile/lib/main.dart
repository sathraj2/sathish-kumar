import 'package:flutter/material.dart';
import 'theme/app_theme.dart';
import 'screens/all_screens.dart';

void main() => runApp(const BusinessApp());

class BusinessApp extends StatelessWidget {
  const BusinessApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'AI Business Assistant',
    theme: AppTheme.light(),
    home: const SplashScreen(),
  );
}
