# AI Business Assistant - 24 Screen Flutter UI

Clean Flutter-only UI milestone for the AI Business Assistant. No external packages are required beyond Flutter and cupertino_icons.

## Run
cd mobile
flutter pub get
flutter analyze
flutter run

## Screens
1 Splash
2 Onboarding 1
3 Onboarding 2
4 Choose Business Type
5 Register
6 OTP Verification
7 Login
8 Business Setup
9 Dashboard
10 Customers
11 Add Customer
12 Customer Details
13 Products
14 Add Product
15 Create Invoice
16 Invoice Preview
17 Expenses
18 Add Expense
19 Payments / Receivables
20 Reports
21 AI Assistant
22 Subscription Plan
23 Settings
24 Profile & More
