using Microsoft.Maui.Graphics;

namespace PinballPlusMaui;

public partial class MainPage : ContentPage
{
    readonly PinballGame _game;
    IDispatcherTimer? _timer;

    public MainPage(int level = 1)
    {
        _level = Math.Clamp(level, 1, 500);
        InitializeComponent();
        LevelLabel.Text = $"LEVEL {_level} / 500";
        _game = new PinballGame();
        GameView.Drawable = new PinballDrawable(_game);
        _game.StateChanged += (_, _) =>
        {
            ScoreLabel.Text = _game.Score.ToString("D6");
            LivesLabel.Text = _game.Lives.ToString();
            GameView.Invalidate();
        };

        _timer = Dispatcher.CreateTimer();
        _timer.Interval = TimeSpan.FromMilliseconds(16);
        _timer.Tick += (_, _) =>
        {
            _game.Update(0.016f, GameView.Width, GameView.Height);
            GameView.Invalidate();
        };
        _timer.Start();
    }

    void LeftClicked(object sender, EventArgs e) => _game.LeftFlipper = true;
    void RightClicked(object sender, EventArgs e) => _game.RightFlipper = true;
    void LaunchClicked(object sender, EventArgs e) => _game.Launch();

    async void LevelsClicked(object sender, EventArgs e)
    {
        await Navigation.PushAsync(new LevelSelectPage(_level, level => Application.Current!.MainPage = new NavigationPage(new MainPage(level))));
    }

    void OnTouchStart(object? sender, TouchEventArgs e)
    {
        foreach (var p in e.Touches)
        {
            if (p.X < GameView.Width / 2) _game.LeftFlipper = true;
            else _game.RightFlipper = true;
        }
    }

    void OnTouchDrag(object? sender, TouchEventArgs e) { }

    void OnTouchEnd(object? sender, TouchEventArgs e)
    {
        _game.LeftFlipper = false;
        _game.RightFlipper = false;
    }

    protected override void OnDisappearing()
    {
        _timer?.Stop();
        base.OnDisappearing();
    }
}
