namespace PinballPlusMaui;

public partial class SplashPage : ContentPage
{
    public SplashPage()
    {
        InitializeComponent();
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await PlaySplashAsync();
    }

    async Task PlaySplashAsync()
    {
        await SplashImage.FadeTo(1, 450, Easing.CubicOut);
        await SplashImage.ScaleTo(1.04, 850, Easing.CubicInOut);
        for (int i = 1; i <= 10; i++)
        {
            LoadingBar.Progress = i / 10.0;
            await Task.Delay(90);
        }

        SplashImage.Source = "pinball500.png";
        await SplashImage.ScaleTo(1.0, 1);
        await Task.Delay(850);
        await SplashImage.FadeTo(0, 250, Easing.CubicIn);

        Application.Current!.MainPage = new NavigationPage(new MainMenuPage())
        {
            BarBackgroundColor = Color.FromArgb("#050816"),
            BarTextColor = Colors.White
        };
    }
}
