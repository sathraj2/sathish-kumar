namespace PinballPlusMaui;

public partial class App : Application
{
    public App()
    {
        InitializeComponent();
        MainPage = new NavigationPage(new SplashPage())
        {
            BarBackgroundColor = Color.FromArgb("#050816"),
            BarTextColor = Colors.White
        };
    }
}
