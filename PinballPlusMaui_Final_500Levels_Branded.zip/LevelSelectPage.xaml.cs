namespace PinballPlusMaui;

public partial class LevelSelectPage : ContentPage
{
    const int TotalLevels = 500;
    const int PageSize = 20;
    int _page = 0;
    readonly Action<int> _onSelected;

    public LevelSelectPage(int currentLevel, Action<int> onSelected)
    {
        InitializeComponent();
        _onSelected = onSelected;
        _page = Math.Clamp((currentLevel - 1) / PageSize, 0, 24);
        BuildPage();
    }

    void BuildPage()
    {
        LevelGrid.RowDefinitions.Clear();
        LevelGrid.ColumnDefinitions.Clear();
        for (int r = 0; r < 5; r++) LevelGrid.RowDefinitions.Add(new RowDefinition(GridLength.Star));
        for (int c = 0; c < 4; c++) LevelGrid.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Star));
        LevelGrid.Children.Clear();

        int first = _page * PageSize + 1;
        int last = Math.Min(first + PageSize - 1, TotalLevels);
        for (int i = 0; i < PageSize && first + i <= TotalLevels; i++)
        {
            int level = first + i;
            int row = i / 4, col = i % 4;
            var button = new Button
            {
                Text = level.ToString(),
                FontSize = 18,
                FontAttributes = FontAttributes.Bold,
                TextColor = Colors.White,
                BackgroundColor = level == 1 ? Color.FromArgb("#16A34A") : Color.FromArgb("#0C65A8"),
                CornerRadius = 12,
                Margin = 2
            };
            button.Clicked += (_, _) => SelectLevel(level);
            Grid.SetRow(button, row);
            Grid.SetColumn(button, col);
            LevelGrid.Children.Add(button);
        }
        PageLabel.Text = $"{_page + 1} / {TotalLevels / PageSize}";
        RangeLabel.Text = $"{first} - {last}";
    }

    async void SelectLevel(int level)
    {
        _onSelected(level);
        await Navigation.PopAsync();
    }

    void PreviousClicked(object sender, EventArgs e)
    {
        if (_page > 0) { _page--; BuildPage(); }
    }

    void NextClicked(object sender, EventArgs e)
    {
        if (_page < (TotalLevels / PageSize) - 1) { _page++; BuildPage(); }
    }

    async void BackClicked(object sender, EventArgs e) => await Navigation.PopAsync();
}
