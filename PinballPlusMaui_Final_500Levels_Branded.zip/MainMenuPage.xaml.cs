namespace PinballPlusMaui;

public partial class MainMenuPage : ContentPage
{
    public MainMenuPage() => InitializeComponent();

    async void PlayClicked(object sender, EventArgs e)
        => await Navigation.PushAsync(new MainPage(1));

    async void LevelsClicked(object sender, EventArgs e)
        => await Navigation.PushAsync(new LevelSelectPage(1, level => Navigation.PushAsync(new MainPage(level))));

    async void SettingsClicked(object sender, EventArgs e)
        => await DisplayAlert("Pinball Plus", "Sound, vibration and gameplay settings will be available here.", "OK");
}
