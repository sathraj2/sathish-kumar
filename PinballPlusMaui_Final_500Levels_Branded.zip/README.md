# Pinball Plus

.NET MAUI Android pinball game, clean-room recreation.

- .NET 10 / MAUI Android
- Animated startup branding: Rithanya Technology Presents
- Pinball Plus branding and 500 levels
- Level selector: 500 levels across 25 pages
- Touch flippers, launch, score and lives

Build:

```bash
dotnet workload install maui-android
dotnet restore
dotnet publish PinballPlusMaui.csproj -f net10.0-android -c Release -p:AndroidPackageFormat=apk -p:AndroidSdkDirectory=/workspaces/android-sdk
```
