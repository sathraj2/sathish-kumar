namespace MedCompare.Domain.Enums;

public enum AuthProvider { Google, Otp, Guest }
public enum UserRole { User, Admin, PharmacyPartner }
public enum SearchType { Name, Brand, Composition, Manufacturer, Barcode, Ai }
public enum OnlinePlatform { Tata1mg, Apollo, PharmEasy, Netmeds }
public enum SavingsBadge { Low, Medium, High }
public enum NotificationType { PriceDrop, BackInStock, Reminder, NewAlternative }
public enum AvailabilityStatus { InStock, OutOfStock, OnlineOnly, NearbyOnly }
