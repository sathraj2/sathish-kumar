namespace MedCompare.Domain.Entities;

public class Pharmacy
{
    public int PharmacyId { get; set; }
    public string Name { get; set; } = default!;
    public string? Address { get; set; }
    public decimal Latitude { get; set; }
    public decimal Longitude { get; set; }
    public string? PhoneNumber { get; set; }
    public bool IsVerifiedPartner { get; set; }
    public bool IsActive { get; set; } = true;

    public ICollection<PharmacyStock> Stock { get; set; } = new List<PharmacyStock>();
}

public class PharmacyStock
{
    public long PharmacyStockId { get; set; }
    public int PharmacyId { get; set; }
    public long MedicineId { get; set; }
    public decimal? Price { get; set; }
    public bool InStock { get; set; } = true;
    public DateTime UpdatedAtUtc { get; set; }
}
