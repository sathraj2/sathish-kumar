namespace MedCompare.Domain.Entities;

public class SearchHistory
{
    public long SearchHistoryId { get; set; }
    public Guid? UserId { get; set; }
    public string SearchTerm { get; set; } = default!;
    public string SearchType { get; set; } = "Name";
    public DateTime SearchedAtUtc { get; set; }
}

public class Favorite
{
    public long FavoriteId { get; set; }
    public Guid UserId { get; set; }
    public long MedicineId { get; set; }
    public Medicine Medicine { get; set; } = default!;
    public DateTime CreatedAtUtc { get; set; }
}

public class MedicineReminder
{
    public long ReminderId { get; set; }
    public Guid UserId { get; set; }
    public Guid? FamilyMemberId { get; set; }
    public long MedicineId { get; set; }
    public string TimesOfDayCsv { get; set; } = default!;
    public DateOnly StartDate { get; set; }
    public DateOnly? EndDate { get; set; }
    public bool IsActive { get; set; } = true;
}

public class Notification
{
    public long NotificationId { get; set; }
    public Guid UserId { get; set; }
    public string Type { get; set; } = default!;
    public string Title { get; set; } = default!;
    public string Body { get; set; } = default!;
    public long? RelatedMedicineId { get; set; }
    public bool IsRead { get; set; }
    public DateTime CreatedAtUtc { get; set; }
}
