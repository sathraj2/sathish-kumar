namespace MedCompare.Domain.Entities;

public class Composition
{
    public int CompositionId { get; set; }
    public string Name { get; set; } = default!;
    public string NormalizedName { get; set; } = default!;
    public string? Category { get; set; }
    public string? Uses { get; set; }
    public string? SideEffects { get; set; }
    public string? Warnings { get; set; }
    public string? PregnancyLactationWarning { get; set; }

    public ICollection<Medicine> Medicines { get; set; } = new List<Medicine>();
}
