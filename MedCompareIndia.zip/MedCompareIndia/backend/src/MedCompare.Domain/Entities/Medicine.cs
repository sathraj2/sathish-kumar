namespace MedCompare.Domain.Entities;

public class Medicine : BaseAuditableEntity
{
    public long MedicineId { get; set; }
    public string BrandName { get; set; } = default!;
    public string? GenericName { get; set; }
    public int CompositionId { get; set; }
    public Composition Composition { get; set; } = default!;
    public string? Strength { get; set; }
    public string? DosageForm { get; set; }
    public int ManufacturerId { get; set; }
    public Manufacturer Manufacturer { get; set; } = default!;
    public string? PackSize { get; set; }
    public decimal MRP { get; set; }
    public decimal SellingPrice { get; set; }
    public bool PrescriptionRequired { get; set; }
    public string? Category { get; set; }
    public string? ImageUrl { get; set; }
    public string? StorageInstructions { get; set; }
    public bool IsActive { get; set; } = true;

    public ICollection<OnlinePrice> OnlinePrices { get; set; } = new List<OnlinePrice>();
    public ICollection<MedicinePriceHistory> PriceHistory { get; set; } = new List<MedicinePriceHistory>();
}

public class MedicinePriceHistory
{
    public long MedicinePriceId { get; set; }
    public long MedicineId { get; set; }
    public decimal MRP { get; set; }
    public decimal SellingPrice { get; set; }
    public DateTime EffectiveFromUtc { get; set; }
    public string Source { get; set; } = "Admin";
}

public class OnlinePrice
{
    public long OnlinePriceId { get; set; }
    public long MedicineId { get; set; }
    public string Platform { get; set; } = default!;
    public decimal Price { get; set; }
    public string? DeepLinkUrl { get; set; }
    public bool InStock { get; set; } = true;
    public DateTime LastSyncedUtc { get; set; }
}
