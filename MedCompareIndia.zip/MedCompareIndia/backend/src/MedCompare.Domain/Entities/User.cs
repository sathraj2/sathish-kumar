using MedCompare.Domain.Enums;

namespace MedCompare.Domain.Entities;

public class User : BaseAuditableEntity
{
    public Guid UserId { get; set; }
    public string? FullName { get; set; }
    public string? Email { get; set; }
    public string? MobileNumber { get; set; }
    public AuthProvider AuthProvider { get; set; }
    public string? ExternalAuthId { get; set; }
    public UserRole Role { get; set; } = UserRole.User;
    public string PreferredLanguage { get; set; } = "en";
    public bool IsDarkModeEnabled { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime? LastLoginAtUtc { get; set; }

    public ICollection<Favorite> Favorites { get; set; } = new List<Favorite>();
    public ICollection<SearchHistory> SearchHistory { get; set; } = new List<SearchHistory>();
    public ICollection<MedicineReminder> Reminders { get; set; } = new List<MedicineReminder>();
    public ICollection<FamilyMember> FamilyMembers { get; set; } = new List<FamilyMember>();
}

public class FamilyMember
{
    public Guid FamilyMemberId { get; set; }
    public Guid UserId { get; set; }
    public string Name { get; set; } = default!;
    public string? Relationship { get; set; }
    public DateOnly? DateOfBirth { get; set; }
}
