namespace MedCompare.Domain.Entities;

public class Manufacturer
{
    public int ManufacturerId { get; set; }
    public string Name { get; set; } = default!;
    public decimal? Rating { get; set; }
    public string? Website { get; set; }
    public string? LogoUrl { get; set; }
    public bool IsActive { get; set; } = true;

    public ICollection<Medicine> Medicines { get; set; } = new List<Medicine>();
}
