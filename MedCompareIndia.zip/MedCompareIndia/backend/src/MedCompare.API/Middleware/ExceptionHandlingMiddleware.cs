using System.Net;
using System.Text.Json;
using MedCompare.Application.Common;

namespace MedCompare.API.Middleware;

/// <summary>Global error handler: never leaks stack traces to the mobile client, always logs, always returns the ApiResponse envelope.</summary>
public class ExceptionHandlingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<ExceptionHandlingMiddleware> _logger;

    public ExceptionHandlingMiddleware(RequestDelegate next, ILogger<ExceptionHandlingMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unhandled exception for {Path}", context.Request.Path);

            context.Response.ContentType = "application/json";
            context.Response.StatusCode = ex switch
            {
                UnauthorizedAccessException => (int)HttpStatusCode.Unauthorized,
                ArgumentException or KeyNotFoundException => (int)HttpStatusCode.BadRequest,
                _ => (int)HttpStatusCode.InternalServerError
            };

            var response = ApiResponse<object>.Fail(
                context.Response.StatusCode == 500
                    ? "An unexpected error occurred. Please try again."
                    : ex.Message);

            await context.Response.WriteAsync(JsonSerializer.Serialize(response));
        }
    }
}
