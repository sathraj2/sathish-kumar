using System.Security.Claims;
using MedCompare.Application.Common;
using MedCompare.Application.DTOs;
using MedCompare.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace MedCompare.API.Controllers;

[ApiController]
[Route("api/user")]
[Authorize]
public class UserController : ControllerBase
{
    private readonly IFavoriteRepository _favorites;
    private readonly ISearchHistoryRepository _history;

    public UserController(IFavoriteRepository favorites, ISearchHistoryRepository history)
    {
        _favorites = favorites; _history = history;
    }

    private Guid CurrentUserId() =>
        Guid.Parse(User.FindFirst("sub")?.Value ?? User.FindFirst(ClaimTypes.NameIdentifier)!.Value);

    [HttpGet("favorites")]
    public async Task<ActionResult<ApiResponse<List<FavoriteDto>>>> GetFavorites(CancellationToken ct)
        => Ok(ApiResponse<List<FavoriteDto>>.Ok(await _favorites.GetForUserAsync(CurrentUserId(), ct)));

    [HttpPost("favorites/{medicineId:long}")]
    public async Task<ActionResult<ApiResponse<object>>> AddFavorite(long medicineId, CancellationToken ct)
    {
        await _favorites.AddAsync(CurrentUserId(), medicineId, ct);
        return Ok(ApiResponse<object>.Ok(new { }, "Added to favorites"));
    }

    [HttpDelete("favorites/{medicineId:long}")]
    public async Task<ActionResult<ApiResponse<object>>> RemoveFavorite(long medicineId, CancellationToken ct)
    {
        await _favorites.RemoveAsync(CurrentUserId(), medicineId, ct);
        return Ok(ApiResponse<object>.Ok(new { }, "Removed from favorites"));
    }

    [HttpGet("history")]
    public async Task<ActionResult<ApiResponse<List<SearchHistoryDto>>>> GetHistory([FromQuery] int take = 20, CancellationToken ct = default)
        => Ok(ApiResponse<List<SearchHistoryDto>>.Ok(await _history.GetForUserAsync(CurrentUserId(), take, ct)));
}
