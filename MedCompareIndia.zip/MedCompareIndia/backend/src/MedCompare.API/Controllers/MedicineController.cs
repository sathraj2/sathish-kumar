using MedCompare.Application.Common;
using MedCompare.Application.DTOs;
using MedCompare.Application.Interfaces;
using MedCompare.Application.Services;
using Microsoft.AspNetCore.Mvc;

namespace MedCompare.API.Controllers;

[ApiController]
[Route("api/medicine")]
public class MedicineController : ControllerBase
{
    private readonly IMedicineRepository _medicines;
    private readonly ISearchHistoryRepository _history;
    private readonly ILogger<MedicineController> _logger;

    public MedicineController(IMedicineRepository medicines, ISearchHistoryRepository history, ILogger<MedicineController> logger)
    {
        _medicines = medicines; _history = history; _logger = logger;
    }

    private Guid? CurrentUserIdOrNull() =>
        Guid.TryParse(User.FindFirst("sub")?.Value ?? User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value, out var id)
            ? id : null;

    /// <summary>GET /api/medicine/search?query=paracetamol&amp;searchType=Name&amp;pageNumber=1&amp;pageSize=20</summary>
    [HttpGet("search")]
    public async Task<ActionResult<ApiResponse<PagedResult<MedicineSummaryDto>>>> Search(
        [FromQuery] string query, [FromQuery] string? searchType, [FromQuery] int pageNumber = 1, [FromQuery] int pageSize = 20,
        CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(query))
            return BadRequest(ApiResponse<PagedResult<MedicineSummaryDto>>.Fail("Search query is required"));

        pageSize = Math.Clamp(pageSize, 1, 50); // guard against abuse / huge payloads

        var result = await _medicines.SearchAsync(query, searchType, pageNumber, pageSize, ct);

        // fire-and-forget style logging kept awaited for correctness in this sample; queue via background job at scale
        await _history.LogAsync(CurrentUserIdOrNull(), query, searchType ?? "Name", ct);

        return Ok(ApiResponse<PagedResult<MedicineSummaryDto>>.Ok(result));
    }

    /// <summary>GET /api/medicine/details/{id}</summary>
    [HttpGet("details/{id:long}")]
    public async Task<ActionResult<ApiResponse<MedicineDetailsDto>>> Details(long id, CancellationToken ct)
    {
        var details = await _medicines.GetDetailsAsync(id, ct);
        if (details is null) return NotFound(ApiResponse<MedicineDetailsDto>.Fail("Medicine not found"));
        return Ok(ApiResponse<MedicineDetailsDto>.Ok(details));
    }

    /// <summary>GET /api/medicine/compare/{compositionId}?strength=650mg&amp;sortBy=LowestPrice</summary>
    [HttpGet("compare/{compositionId:int}")]
    public async Task<ActionResult<ApiResponse<CompareBrandsResultDto>>> Compare(
        int compositionId, [FromQuery] string? strength, [FromQuery] string sortBy = "LowestPrice", CancellationToken ct = default)
    {
        var brands = await _medicines.GetBrandsByCompositionAsync(compositionId, strength, sortBy, ct);
        if (brands.Count == 0)
            return NotFound(ApiResponse<CompareBrandsResultDto>.Fail("No brands found for this composition"));

        var result = new CompareBrandsResultDto
        {
            CompositionName = brands[0].BrandName, // caller should also fetch composition name via details endpoint; simplified here
            Strength = strength,
            Brands = brands,
            Disclaimer = SmartSavingsCalculator.MedicalDisclaimer
        };
        return Ok(ApiResponse<CompareBrandsResultDto>.Ok(result));
    }
}
