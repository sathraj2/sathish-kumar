using MedCompare.Application.Common;
using MedCompare.Application.DTOs;
using MedCompare.Application.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace MedCompare.API.Controllers;

[ApiController]
[Route("api/pharmacy")]
public class PharmacyController : ControllerBase
{
    private readonly IPharmacyRepository _pharmacies;
    public PharmacyController(IPharmacyRepository pharmacies) => _pharmacies = pharmacies;

    /// <summary>GET /api/pharmacy/nearby?latitude=13.08&amp;longitude=80.27&amp;radiusKm=5&amp;medicineId=1</summary>
    [HttpGet("nearby")]
    public async Task<ActionResult<ApiResponse<List<NearbyPharmacyDto>>>> Nearby(
        [FromQuery] double latitude, [FromQuery] double longitude,
        [FromQuery] double radiusKm = 5, [FromQuery] long? medicineId = null, CancellationToken ct = default)
    {
        var result = await _pharmacies.GetNearbyAsync(latitude, longitude, radiusKm, medicineId, ct);
        return Ok(ApiResponse<List<NearbyPharmacyDto>>.Ok(result));
    }
}
