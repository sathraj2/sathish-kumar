using MedCompare.Application.Common;
using MedCompare.Application.DTOs;
using MedCompare.Application.Interfaces;
using MedCompare.Domain.Entities;
using MedCompare.Domain.Enums;
using Microsoft.AspNetCore.Mvc;

namespace MedCompare.API.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController : ControllerBase
{
    private readonly IOtpService _otp;
    private readonly IGoogleAuthService _google;
    private readonly IUserRepository _users;
    private readonly IJwtTokenService _jwt;
    private readonly ILogger<AuthController> _logger;

    public AuthController(IOtpService otp, IGoogleAuthService google, IUserRepository users,
        IJwtTokenService jwt, ILogger<AuthController> logger)
    {
        _otp = otp; _google = google; _users = users; _jwt = jwt; _logger = logger;
    }

    [HttpPost("otp/request")]
    public async Task<ActionResult<ApiResponse<object>>> RequestOtp(OtpRequestDto dto, CancellationToken ct)
    {
        var sent = await _otp.SendOtpAsync(dto.MobileNumber, ct);
        return Ok(ApiResponse<object>.Ok(new { sent }, "OTP sent"));
    }

    [HttpPost("otp/verify")]
    public async Task<ActionResult<ApiResponse<AuthResultDto>>> VerifyOtp(OtpVerifyDto dto, CancellationToken ct)
    {
        var valid = await _otp.VerifyOtpAsync(dto.MobileNumber, dto.Otp, ct);
        if (!valid) return Unauthorized(ApiResponse<AuthResultDto>.Fail("Invalid or expired OTP"));

        var user = await _users.GetByMobileAsync(dto.MobileNumber, ct)
                   ?? await _users.CreateAsync(new User
                   {
                       UserId = Guid.NewGuid(),
                       MobileNumber = dto.MobileNumber,
                       AuthProvider = AuthProvider.Otp,
                       Role = UserRole.User,
                       LastLoginAtUtc = DateTime.UtcNow
                   }, ct);

        var tokens = _jwt.GenerateTokens(user.UserId, user.Role.ToString());
        return Ok(ApiResponse<AuthResultDto>.Ok(tokens, "Login successful"));
    }

    [HttpPost("google")]
    public async Task<ActionResult<ApiResponse<AuthResultDto>>> GoogleLogin(GoogleLoginDto dto, CancellationToken ct)
    {
        var googleUser = await _google.ValidateIdTokenAsync(dto.IdToken, ct);
        if (googleUser is null) return Unauthorized(ApiResponse<AuthResultDto>.Fail("Invalid Google token"));

        var user = await _users.GetByExternalAuthIdAsync(googleUser.Value.ExternalId, ct)
                   ?? await _users.CreateAsync(new User
                   {
                       UserId = Guid.NewGuid(),
                       Email = googleUser.Value.Email,
                       FullName = googleUser.Value.Name,
                       ExternalAuthId = googleUser.Value.ExternalId,
                       AuthProvider = AuthProvider.Google,
                       Role = UserRole.User,
                       LastLoginAtUtc = DateTime.UtcNow
                   }, ct);

        var tokens = _jwt.GenerateTokens(user.UserId, user.Role.ToString());
        return Ok(ApiResponse<AuthResultDto>.Ok(tokens, "Login successful"));
    }

    [HttpPost("guest")]
    public ActionResult<ApiResponse<AuthResultDto>> GuestLogin()
    {
        var tokens = _jwt.GenerateTokens(Guid.NewGuid(), UserRole.User.ToString(), isGuest: true);
        return Ok(ApiResponse<AuthResultDto>.Ok(tokens, "Guest session started"));
    }
}
