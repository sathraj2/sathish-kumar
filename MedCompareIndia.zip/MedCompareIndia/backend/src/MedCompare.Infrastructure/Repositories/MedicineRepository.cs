using MedCompare.Application.Common;
using MedCompare.Application.DTOs;
using MedCompare.Application.Interfaces;
using MedCompare.Application.Services;
using MedCompare.Domain.Entities;
using MedCompare.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace MedCompare.Infrastructure.Repositories;

public class MedicineRepository : IMedicineRepository
{
    private readonly MedCompareDbContext _db;
    public MedicineRepository(MedCompareDbContext db) => _db = db;

    public async Task<PagedResult<MedicineSummaryDto>> SearchAsync(
        string query, string? searchType, int pageNumber, int pageSize, CancellationToken ct = default)
    {
        var q = _db.Medicines.AsNoTracking().Where(m => m.IsActive);

        q = searchType?.ToLowerInvariant() switch
        {
            "brand"        => q.Where(m => EF.Functions.Like(m.BrandName, $"%{query}%")),
            "composition"  => q.Where(m => EF.Functions.Like(m.Composition.Name, $"%{query}%")),
            "manufacturer" => q.Where(m => EF.Functions.Like(m.Manufacturer.Name, $"%{query}%")),
            _ => q.Where(m =>
                    EF.Functions.Like(m.BrandName, $"%{query}%") ||
                    EF.Functions.Like(m.GenericName ?? "", $"%{query}%") ||
                    EF.Functions.Like(m.Composition.Name, $"%{query}%") ||
                    EF.Functions.Like(m.Manufacturer.Name, $"%{query}%"))
        };

        var total = await q.CountAsync(ct);

        var items = await q
            .OrderBy(m => m.BrandName == query ? 0 : 1).ThenBy(m => m.BrandName)
            .Skip((pageNumber - 1) * pageSize).Take(pageSize)
            .Select(m => new MedicineSummaryDto
            {
                MedicineId = m.MedicineId,
                BrandName = m.BrandName,
                GenericName = m.GenericName,
                Strength = m.Strength,
                PackSize = m.PackSize,
                MRP = m.MRP,
                SellingPrice = m.SellingPrice,
                PrescriptionRequired = m.PrescriptionRequired,
                ImageUrl = m.ImageUrl,
                ManufacturerName = m.Manufacturer.Name,
                CompositionName = m.Composition.Name,
                CompositionId = m.CompositionId
            })
            .ToListAsync(ct);

        return new PagedResult<MedicineSummaryDto>
        {
            Items = items, PageNumber = pageNumber, PageSize = pageSize, TotalCount = total
        };
    }

    public async Task<MedicineDetailsDto?> GetDetailsAsync(long medicineId, CancellationToken ct = default)
    {
        var m = await _db.Medicines.AsNoTracking()
            .Include(x => x.Composition)
            .Include(x => x.Manufacturer)
            .Include(x => x.OnlinePrices)
            .FirstOrDefaultAsync(x => x.MedicineId == medicineId && x.IsActive, ct);

        if (m is null) return null;

        return new MedicineDetailsDto
        {
            MedicineId = m.MedicineId,
            BrandName = m.BrandName,
            GenericName = m.GenericName,
            Strength = m.Strength,
            PackSize = m.PackSize,
            MRP = m.MRP,
            SellingPrice = m.SellingPrice,
            PrescriptionRequired = m.PrescriptionRequired,
            ImageUrl = m.ImageUrl,
            ManufacturerName = m.Manufacturer.Name,
            ManufacturerRating = m.Manufacturer.Rating,
            CompositionName = m.Composition.Name,
            CompositionId = m.CompositionId,
            Category = m.Category,
            DosageForm = m.DosageForm,
            StorageInstructions = m.StorageInstructions,
            Uses = m.Composition.Uses,
            SideEffects = m.Composition.SideEffects,
            Warnings = m.Composition.Warnings,
            PregnancyLactationWarning = m.Composition.PregnancyLactationWarning,
            OnlinePrices = m.OnlinePrices.Select(p => new OnlinePriceDto
            {
                Platform = p.Platform, Price = p.Price, InStock = p.InStock, DeepLinkUrl = p.DeepLinkUrl
            }).ToList()
        };
    }

    public async Task<List<BrandComparisonDto>> GetBrandsByCompositionAsync(
        int compositionId, string? strength, string sortBy, CancellationToken ct = default)
    {
        var q = _db.Medicines.AsNoTracking()
            .Include(m => m.Manufacturer)
            .Where(m => m.CompositionId == compositionId && m.IsActive);

        if (!string.IsNullOrWhiteSpace(strength))
            q = q.Where(m => m.Strength == strength);

        var brands = await q.Select(m => new BrandComparisonDto
        {
            MedicineId = m.MedicineId,
            BrandName = m.BrandName,
            ManufacturerName = m.Manufacturer.Name,
            ManufacturerRating = m.Manufacturer.Rating,
            Strength = m.Strength,
            PackSize = m.PackSize,
            MRP = m.MRP,
            SellingPrice = m.SellingPrice,
            PrescriptionRequired = m.PrescriptionRequired,
            ImageUrl = m.ImageUrl,
            Availability = "InStock"
        }).ToListAsync(ct);

        // Smart Savings Score is computed in application code so it's covered by unit tests
        // and identical whether the data came from SQL or a future Elasticsearch index.
        SmartSavingsCalculator.Apply(brands);

        brands = sortBy switch
        {
            "HighestPrice"  => brands.OrderByDescending(b => b.SellingPrice).ToList(),
            "Manufacturer"  => brands.OrderBy(b => b.ManufacturerName).ToList(),
            "Rating"        => brands.OrderByDescending(b => b.ManufacturerRating).ToList(),
            _               => brands.OrderBy(b => b.SellingPrice).ToList() // LowestPrice default
        };

        return brands;
    }

    public Task<Medicine?> GetByIdAsync(long medicineId, CancellationToken ct = default) =>
        _db.Medicines.FirstOrDefaultAsync(m => m.MedicineId == medicineId, ct);
}
