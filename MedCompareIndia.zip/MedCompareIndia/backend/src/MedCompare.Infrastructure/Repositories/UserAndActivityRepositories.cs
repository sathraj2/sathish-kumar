using MedCompare.Application.DTOs;
using MedCompare.Application.Interfaces;
using MedCompare.Domain.Entities;
using MedCompare.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace MedCompare.Infrastructure.Repositories;

public class UserRepository : IUserRepository
{
    private readonly MedCompareDbContext _db;
    public UserRepository(MedCompareDbContext db) => _db = db;

    public Task<User?> GetByMobileAsync(string mobileNumber, CancellationToken ct = default) =>
        _db.Users.FirstOrDefaultAsync(u => u.MobileNumber == mobileNumber, ct);

    public Task<User?> GetByExternalAuthIdAsync(string externalAuthId, CancellationToken ct = default) =>
        _db.Users.FirstOrDefaultAsync(u => u.ExternalAuthId == externalAuthId, ct);

    public async Task<User> CreateAsync(User user, CancellationToken ct = default)
    {
        _db.Users.Add(user);
        await _db.SaveChangesAsync(ct);
        return user;
    }

    public Task<User?> GetByIdAsync(Guid userId, CancellationToken ct = default) =>
        _db.Users.FirstOrDefaultAsync(u => u.UserId == userId, ct);
}

public class FavoriteRepository : IFavoriteRepository
{
    private readonly MedCompareDbContext _db;
    public FavoriteRepository(MedCompareDbContext db) => _db = db;

    public async Task<List<FavoriteDto>> GetForUserAsync(Guid userId, CancellationToken ct = default)
    {
        return await _db.Favorites.AsNoTracking()
            .Include(f => f.Medicine).ThenInclude(m => m.Manufacturer)
            .Include(f => f.Medicine).ThenInclude(m => m.Composition)
            .Where(f => f.UserId == userId)
            .OrderByDescending(f => f.CreatedAtUtc)
            .Select(f => new FavoriteDto
            {
                FavoriteId = f.FavoriteId,
                CreatedAtUtc = f.CreatedAtUtc,
                Medicine = new MedicineSummaryDto
                {
                    MedicineId = f.Medicine.MedicineId,
                    BrandName = f.Medicine.BrandName,
                    GenericName = f.Medicine.GenericName,
                    Strength = f.Medicine.Strength,
                    PackSize = f.Medicine.PackSize,
                    MRP = f.Medicine.MRP,
                    SellingPrice = f.Medicine.SellingPrice,
                    PrescriptionRequired = f.Medicine.PrescriptionRequired,
                    ImageUrl = f.Medicine.ImageUrl,
                    ManufacturerName = f.Medicine.Manufacturer.Name,
                    CompositionName = f.Medicine.Composition.Name,
                    CompositionId = f.Medicine.CompositionId
                }
            }).ToListAsync(ct);
    }

    public async Task AddAsync(Guid userId, long medicineId, CancellationToken ct = default)
    {
        var exists = await _db.Favorites.AnyAsync(f => f.UserId == userId && f.MedicineId == medicineId, ct);
        if (exists) return;
        _db.Favorites.Add(new Favorite { UserId = userId, MedicineId = medicineId, CreatedAtUtc = DateTime.UtcNow });
        await _db.SaveChangesAsync(ct);
    }

    public async Task RemoveAsync(Guid userId, long medicineId, CancellationToken ct = default)
    {
        var fav = await _db.Favorites.FirstOrDefaultAsync(f => f.UserId == userId && f.MedicineId == medicineId, ct);
        if (fav is null) return;
        _db.Favorites.Remove(fav);
        await _db.SaveChangesAsync(ct);
    }
}

public class SearchHistoryRepository : ISearchHistoryRepository
{
    private readonly MedCompareDbContext _db;
    public SearchHistoryRepository(MedCompareDbContext db) => _db = db;

    public async Task<List<SearchHistoryDto>> GetForUserAsync(Guid? userId, int take, CancellationToken ct = default)
    {
        return await _db.SearchHistory.AsNoTracking()
            .Where(h => h.UserId == userId)
            .OrderByDescending(h => h.SearchedAtUtc)
            .Take(take)
            .Select(h => new SearchHistoryDto { SearchTerm = h.SearchTerm, SearchType = h.SearchType, SearchedAtUtc = h.SearchedAtUtc })
            .ToListAsync(ct);
    }

    public async Task LogAsync(Guid? userId, string term, string searchType, CancellationToken ct = default)
    {
        _db.SearchHistory.Add(new SearchHistory
        {
            UserId = userId, SearchTerm = term, SearchType = searchType, SearchedAtUtc = DateTime.UtcNow
        });
        await _db.SaveChangesAsync(ct);
    }
}
