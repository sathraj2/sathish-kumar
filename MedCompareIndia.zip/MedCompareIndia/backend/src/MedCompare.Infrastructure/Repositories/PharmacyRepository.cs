using MedCompare.Application.DTOs;
using MedCompare.Application.Interfaces;
using MedCompare.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace MedCompare.Infrastructure.Repositories;

public class PharmacyRepository : IPharmacyRepository
{
    private readonly MedCompareDbContext _db;
    public PharmacyRepository(MedCompareDbContext db) => _db = db;

    // Haversine distance computed in-memory here for portability; for scale, replace with
    // the geo.sp_NearbyPharmacies stored procedure or a SQL Server `geography` column query.
    public async Task<List<NearbyPharmacyDto>> GetNearbyAsync(
        double latitude, double longitude, double radiusKm, long? medicineId, CancellationToken ct = default)
    {
        var pharmacies = await _db.Pharmacies.AsNoTracking().Where(p => p.IsActive).ToListAsync(ct);

        var stock = medicineId.HasValue
            ? await _db.PharmacyStock.AsNoTracking().Where(s => s.MedicineId == medicineId.Value).ToListAsync(ct)
            : new List<Domain.Entities.PharmacyStock>();

        var result = pharmacies.Select(p =>
        {
            var distance = Haversine(latitude, longitude, (double)p.Latitude, (double)p.Longitude);
            var s = stock.FirstOrDefault(x => x.PharmacyId == p.PharmacyId);
            return new NearbyPharmacyDto
            {
                PharmacyId = p.PharmacyId,
                Name = p.Name,
                Address = p.Address,
                Latitude = (double)p.Latitude,
                Longitude = (double)p.Longitude,
                PhoneNumber = p.PhoneNumber,
                IsVerifiedPartner = p.IsVerifiedPartner,
                DistanceKm = Math.Round(distance, 2),
                MedicinePrice = s?.Price,
                InStock = s?.InStock
            };
        })
        .Where(p => p.DistanceKm <= radiusKm)
        .OrderBy(p => p.DistanceKm)
        .ToList();

        return result;
    }

    private static double Haversine(double lat1, double lon1, double lat2, double lon2)
    {
        const double R = 6371; // km
        double dLat = ToRad(lat2 - lat1), dLon = ToRad(lon2 - lon1);
        double a = Math.Sin(dLat / 2) * Math.Sin(dLat / 2) +
                   Math.Cos(ToRad(lat1)) * Math.Cos(ToRad(lat2)) * Math.Sin(dLon / 2) * Math.Sin(dLon / 2);
        return R * 2 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a));
    }
    private static double ToRad(double deg) => deg * Math.PI / 180;
}
