using MedCompare.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace MedCompare.Infrastructure.Persistence;

public class MedCompareDbContext : DbContext
{
    public MedCompareDbContext(DbContextOptions<MedCompareDbContext> options) : base(options) { }

    public DbSet<User> Users => Set<User>();
    public DbSet<FamilyMember> FamilyMembers => Set<FamilyMember>();
    public DbSet<Manufacturer> Manufacturers => Set<Manufacturer>();
    public DbSet<Composition> Compositions => Set<Composition>();
    public DbSet<Medicine> Medicines => Set<Medicine>();
    public DbSet<MedicinePriceHistory> MedicinePriceHistory => Set<MedicinePriceHistory>();
    public DbSet<OnlinePrice> OnlinePrices => Set<OnlinePrice>();
    public DbSet<Pharmacy> Pharmacies => Set<Pharmacy>();
    public DbSet<PharmacyStock> PharmacyStock => Set<PharmacyStock>();
    public DbSet<SearchHistory> SearchHistory => Set<SearchHistory>();
    public DbSet<Favorite> Favorites => Set<Favorite>();
    public DbSet<MedicineReminder> MedicineReminders => Set<MedicineReminder>();
    public DbSet<Notification> Notifications => Set<Notification>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<User>(e =>
        {
            e.ToTable("Users", "usr");
            e.HasKey(x => x.UserId);
            e.Property(x => x.Email).HasMaxLength(256);
            e.Property(x => x.MobileNumber).HasMaxLength(15);
            e.HasIndex(x => x.Email).IsUnique();
            e.HasIndex(x => x.MobileNumber).IsUnique();
            e.Property(x => x.AuthProvider).HasConversion<string>().HasMaxLength(20);
            e.Property(x => x.Role).HasConversion<string>().HasMaxLength(20);
        });

        b.Entity<Manufacturer>(e =>
        {
            e.ToTable("Manufacturers", "med");
            e.HasKey(x => x.ManufacturerId);
            e.Property(x => x.Name).HasMaxLength(200).IsRequired();
        });

        b.Entity<Composition>(e =>
        {
            e.ToTable("Compositions", "med");
            e.HasKey(x => x.CompositionId);
            e.HasIndex(x => x.NormalizedName).IsUnique();
        });

        b.Entity<Medicine>(e =>
        {
            e.ToTable("Medicines", "med");
            e.HasKey(x => x.MedicineId);
            e.Property(x => x.MRP).HasColumnType("decimal(10,2)");
            e.Property(x => x.SellingPrice).HasColumnType("decimal(10,2)");
            e.HasOne(x => x.Composition).WithMany(c => c.Medicines).HasForeignKey(x => x.CompositionId);
            e.HasOne(x => x.Manufacturer).WithMany(m => m.Medicines).HasForeignKey(x => x.ManufacturerId);
            e.HasIndex(x => x.BrandName);
            e.HasIndex(x => new { x.CompositionId, x.Strength, x.SellingPrice });
        });

        b.Entity<OnlinePrice>(e =>
        {
            e.ToTable("OnlinePrices", "med");
            e.HasKey(x => x.OnlinePriceId);
            e.Property(x => x.Price).HasColumnType("decimal(10,2)");
        });

        b.Entity<Pharmacy>(e =>
        {
            e.ToTable("Pharmacies", "geo");
            e.HasKey(x => x.PharmacyId);
            e.Property(x => x.Latitude).HasColumnType("decimal(9,6)");
            e.Property(x => x.Longitude).HasColumnType("decimal(9,6)");
        });

        b.Entity<PharmacyStock>(e =>
        {
            e.ToTable("PharmacyStock", "geo");
            e.HasKey(x => x.PharmacyStockId);
            e.HasIndex(x => new { x.PharmacyId, x.MedicineId }).IsUnique();
        });

        b.Entity<Favorite>(e =>
        {
            e.ToTable("Favorites", "usr");
            e.HasKey(x => x.FavoriteId);
            e.HasIndex(x => new { x.UserId, x.MedicineId }).IsUnique();
            e.HasOne(x => x.Medicine).WithMany().HasForeignKey(x => x.MedicineId);
        });

        b.Entity<SearchHistory>(e =>
        {
            e.ToTable("SearchHistory", "usr");
            e.HasKey(x => x.SearchHistoryId);
        });

        b.Entity<MedicineReminder>(e =>
        {
            e.ToTable("MedicineReminders", "usr");
            e.HasKey(x => x.ReminderId);
        });

        b.Entity<Notification>(e =>
        {
            e.ToTable("Notifications", "usr");
            e.HasKey(x => x.NotificationId);
        });

        b.Entity<FamilyMember>(e =>
        {
            e.ToTable("FamilyMembers", "usr");
            e.HasKey(x => x.FamilyMemberId);
        });

        b.Entity<MedicinePriceHistory>(e =>
        {
            e.ToTable("MedicinePrices", "med");
            e.HasKey(x => x.MedicinePriceId);
            e.Property(x => x.MRP).HasColumnType("decimal(10,2)");
            e.Property(x => x.SellingPrice).HasColumnType("decimal(10,2)");
        });
    }
}
