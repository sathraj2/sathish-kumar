using System.Text.Json;
using MedCompare.Application.Common;
using MedCompare.Application.DTOs;
using MedCompare.Application.Interfaces;
using StackExchange.Redis;

namespace MedCompare.Infrastructure.Caching;

/// <summary>
/// Decorator that adds a Redis cache-aside layer in front of the real repository.
/// Register with: services.Decorate&lt;IMedicineRepository, CachedMedicineRepository&gt();
/// (Scrutor package) or wire manually in Program.cs. Keeps hot "compare brands" and
/// "search" results fast under heavy read load without touching business logic.
/// </summary>
public class CachedMedicineRepository : IMedicineRepository
{
    private readonly IMedicineRepository _inner;
    private readonly IConnectionMultiplexer _redis;
    private static readonly TimeSpan DefaultTtl = TimeSpan.FromMinutes(10);

    public CachedMedicineRepository(IMedicineRepository inner, IConnectionMultiplexer redis)
    {
        _inner = inner;
        _redis = redis;
    }

    public async Task<PagedResult<MedicineSummaryDto>> SearchAsync(
        string query, string? searchType, int pageNumber, int pageSize, CancellationToken ct = default)
    {
        var key = $"search:{searchType}:{query.ToLowerInvariant()}:{pageNumber}:{pageSize}";
        return await GetOrSetAsync(key, () => _inner.SearchAsync(query, searchType, pageNumber, pageSize, ct));
    }

    public async Task<MedicineDetailsDto?> GetDetailsAsync(long medicineId, CancellationToken ct = default)
    {
        var key = $"medicine:details:{medicineId}";
        return await GetOrSetAsync(key, () => _inner.GetDetailsAsync(medicineId, ct));
    }

    public async Task<List<BrandComparisonDto>> GetBrandsByCompositionAsync(
        int compositionId, string? strength, string sortBy, CancellationToken ct = default)
    {
        var key = $"compare:{compositionId}:{strength}:{sortBy}";
        return await GetOrSetAsync(key, () => _inner.GetBrandsByCompositionAsync(compositionId, strength, sortBy, ct))
               ?? new List<BrandComparisonDto>();
    }

    public Task<Domain.Entities.Medicine?> GetByIdAsync(long medicineId, CancellationToken ct = default) =>
        _inner.GetByIdAsync(medicineId, ct); // not cached — used for writes/validation paths

    private async Task<T?> GetOrSetAsync<T>(string key, Func<Task<T>> factory)
    {
        var db = _redis.GetDatabase();
        var cached = await db.StringGetAsync(key);
        if (cached.HasValue)
            return JsonSerializer.Deserialize<T>(cached!);

        var value = await factory();
        await db.StringSetAsync(key, JsonSerializer.Serialize(value), DefaultTtl);
        return value;
    }
}
