using MedCompare.Application.DTOs;
using MedCompare.Application.Interfaces;
using Microsoft.Extensions.Logging;

namespace MedCompare.Infrastructure.ExternalServices;

/// <summary>
/// Console/log-based OTP sender for local dev. Swap for MSG91 / Twilio / AWS SNS in production.
/// </summary>
public class DevOtpService : IOtpService
{
    private readonly ILogger<DevOtpService> _logger;
    // In production back this with Redis (key = mobile, value = otp, TTL = 5 min) instead of memory.
    private static readonly Dictionary<string, string> _otps = new();

    public DevOtpService(ILogger<DevOtpService> logger) => _logger = logger;

    public Task<bool> SendOtpAsync(string mobileNumber, CancellationToken ct = default)
    {
        var otp = Random.Shared.Next(100000, 999999).ToString();
        _otps[mobileNumber] = otp;
        _logger.LogInformation("DEV OTP for {Mobile}: {Otp} (wire an SMS provider for production)", mobileNumber, otp);
        return Task.FromResult(true);
    }

    public Task<bool> VerifyOtpAsync(string mobileNumber, string otp, CancellationToken ct = default)
    {
        var ok = _otps.TryGetValue(mobileNumber, out var stored) && stored == otp;
        if (ok) _otps.Remove(mobileNumber);
        return Task.FromResult(ok);
    }
}

/// <summary>TODO: validate real Google ID tokens via Google.Apis.Auth.GoogleJsonWebSignature.</summary>
public class GoogleAuthService : IGoogleAuthService
{
    public Task<(string ExternalId, string? Email, string? Name)?> ValidateIdTokenAsync(string idToken, CancellationToken ct = default)
        => throw new NotImplementedException("Wire Google.Apis.Auth.GoogleJsonWebSignature.ValidateAsync(idToken) here.");
}

public class NullOnlinePriceProvider : IOnlinePriceProvider
{
    public Task<List<OnlinePriceDto>> GetPricesAsync(long medicineId, CancellationToken ct = default)
        => Task.FromResult(new List<OnlinePriceDto>()); // real data currently comes from med.OnlinePrices table (synced by a background job)
}

public class NullAiAssistantService : IAiAssistantService
{
    public Task<string> AskAsync(string question, string languageCode, CancellationToken ct = default)
        => throw new NotImplementedException("Call the Anthropic Messages API here with a medical-safety system prompt and the app's disclaimer.");
}

public class NullOcrService : IOcrService
{
    public Task<List<string>> ExtractMedicineNamesFromImageAsync(byte[] imageBytes, CancellationToken ct = default)
        => throw new NotImplementedException("Wire Azure AI Vision Read API or on-device ML Kit text recognition here.");
}

public class LoggingNotificationService : INotificationService
{
    private readonly ILogger<LoggingNotificationService> _logger;
    public LoggingNotificationService(ILogger<LoggingNotificationService> logger) => _logger = logger;

    public Task SendAsync(Guid userId, string type, string title, string body, long? relatedMedicineId = null, CancellationToken ct = default)
    {
        _logger.LogInformation("Notification[{Type}] to {UserId}: {Title} - {Body}", type, userId, title, body);
        // TODO: persist to usr.Notifications and push via FCM/APNs.
        return Task.CompletedTask;
    }
}
