using FluentAssertions;
using MedCompare.Application.Services;
using Xunit;

namespace MedCompare.Tests.Services;

public class AiSearchQueryParserTests
{
    [Fact]
    public void Parse_DetectsCategoryAndMaxPrice()
    {
        var result = AiSearchQueryParser.Parse("BP medicine below ₹100");
        result.CategoryHint.Should().Be("Blood Pressure");
        result.MaxPrice.Should().Be(100);
    }

    [Fact]
    public void Parse_DetectsCheapestIntent()
    {
        var result = AiSearchQueryParser.Parse("cheapest medicine for cholesterol");
        result.WantsCheapest.Should().BeTrue();
        result.CategoryHint.Should().Be("Cholesterol");
    }

    [Fact]
    public void Parse_DetectsAlternativeIntentWithBrandHint()
    {
        var result = AiSearchQueryParser.Parse("Show alternatives to Dolo 650");
        result.WantsAlternatives.Should().BeTrue();
        result.BrandHint.Should().Be("Dolo 650");
    }
}
