using System.Linq;
using FluentAssertions;
using MedCompare.Application.DTOs;
using MedCompare.Application.Services;
using MedCompare.Domain.Enums;
using Xunit;

namespace MedCompare.Tests.Services;

public class SmartSavingsCalculatorTests
{
    private static BrandComparisonDto Brand(string name, decimal price) => new()
    {
        BrandName = name, SellingPrice = price, MRP = price, ManufacturerName = "Mfr"
    };

    [Fact]
    public void Apply_FlagsCheapestBrand()
    {
        var brands = new List<BrandComparisonDto> { Brand("Dolo 650", 30.50m), Brand("Crocin", 36m), Brand("P-650", 16m) };

        SmartSavingsCalculator.Apply(brands);

        brands.Single(b => b.BrandName == "P-650").IsCheapestEquivalent.Should().BeTrue();
        brands.Count(b => b.IsCheapestEquivalent).Should().Be(1);
    }

    [Fact]
    public void Apply_ComputesPriceDifferenceAndPercentAgainstMostExpensive()
    {
        var brands = new List<BrandComparisonDto> { Brand("A", 100m), Brand("B", 40m) };

        SmartSavingsCalculator.Apply(brands);

        var cheap = brands.Single(b => b.BrandName == "B");
        cheap.PriceDifference.Should().Be(60m);
        cheap.SavingsPercent.Should().Be(60m);
        cheap.SavingsBadge.Should().Be(SavingsBadge.High.ToString());
    }

    [Theory]
    [InlineData(5, "Low")]
    [InlineData(20, "Medium")]
    [InlineData(45, "High")]
    public void BadgeFor_ReturnsExpectedTier(decimal percent, string expected)
        => SmartSavingsCalculator.BadgeFor(percent).ToString().Should().Be(expected);

    [Fact]
    public void Apply_SingleBrand_NoSavingsAndIsCheapest()
    {
        var brands = new List<BrandComparisonDto> { Brand("Solo", 50m) };
        SmartSavingsCalculator.Apply(brands);
        brands[0].SavingsPercent.Should().Be(0);
        brands[0].IsCheapestEquivalent.Should().BeTrue();
    }
}
