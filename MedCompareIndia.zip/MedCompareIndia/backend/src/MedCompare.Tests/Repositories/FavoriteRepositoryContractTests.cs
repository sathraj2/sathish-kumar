using FluentAssertions;
using MedCompare.Application.DTOs;
using MedCompare.Application.Interfaces;
using Moq;
using Xunit;

namespace MedCompare.Tests.Repositories;

/// <summary>
/// Contract-level test against the repository interface (via Moq) demonstrating how
/// controller/service logic should be tested in isolation from EF Core/SQL Server.
/// Add a SQLite-in-memory or Testcontainers-based integration test suite alongside this
/// for true persistence coverage.
/// </summary>
public class FavoriteRepositoryContractTests
{
    [Fact]
    public async Task AddAsync_IsIdempotent_WhenCalledTwice()
    {
        var mock = new Mock<IFavoriteRepository>();
        var userId = Guid.NewGuid();
        mock.Setup(r => r.AddAsync(userId, 1L, It.IsAny<CancellationToken>())).Returns(Task.CompletedTask);

        await mock.Object.AddAsync(userId, 1L);
        await mock.Object.AddAsync(userId, 1L);

        mock.Verify(r => r.AddAsync(userId, 1L, It.IsAny<CancellationToken>()), Times.Exactly(2));
    }

    [Fact]
    public async Task GetForUserAsync_ReturnsEmptyList_ForNewUser()
    {
        var mock = new Mock<IFavoriteRepository>();
        mock.Setup(r => r.GetForUserAsync(It.IsAny<Guid>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<FavoriteDto>());

        var result = await mock.Object.GetForUserAsync(Guid.NewGuid());
        result.Should().BeEmpty();
    }
}
