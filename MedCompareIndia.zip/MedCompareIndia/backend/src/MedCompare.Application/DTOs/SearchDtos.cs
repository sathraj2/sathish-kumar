namespace MedCompare.Application.DTOs;

public class MedicineSearchRequestDto
{
    public string Query { get; set; } = default!;
    public string? SearchType { get; set; } // Name|Brand|Composition|Manufacturer
    public int PageNumber { get; set; } = 1;
    public int PageSize { get; set; } = 20;
}
