namespace MedCompare.Application.DTOs;

public class MedicineSummaryDto
{
    public long MedicineId { get; set; }
    public string BrandName { get; set; } = default!;
    public string? GenericName { get; set; }
    public string? Strength { get; set; }
    public string? PackSize { get; set; }
    public decimal MRP { get; set; }
    public decimal SellingPrice { get; set; }
    public bool PrescriptionRequired { get; set; }
    public string? ImageUrl { get; set; }
    public string ManufacturerName { get; set; } = default!;
    public string CompositionName { get; set; } = default!;
    public int CompositionId { get; set; }
}

public class MedicineDetailsDto : MedicineSummaryDto
{
    public string? Category { get; set; }
    public string? DosageForm { get; set; }
    public string? StorageInstructions { get; set; }
    public string? Uses { get; set; }
    public string? SideEffects { get; set; }
    public string? Warnings { get; set; }
    public string? PregnancyLactationWarning { get; set; }
    public decimal? ManufacturerRating { get; set; }
    public List<OnlinePriceDto> OnlinePrices { get; set; } = new();
}

public class OnlinePriceDto
{
    public string Platform { get; set; } = default!;
    public decimal Price { get; set; }
    public bool InStock { get; set; }
    public string? DeepLinkUrl { get; set; }
}

/// <summary>One row in the Compare Brands screen, already carrying the Smart Savings Score fields.</summary>
public class BrandComparisonDto
{
    public long MedicineId { get; set; }
    public string BrandName { get; set; } = default!;
    public string ManufacturerName { get; set; } = default!;
    public decimal? ManufacturerRating { get; set; }
    public string? Strength { get; set; }
    public string? PackSize { get; set; }
    public decimal MRP { get; set; }
    public decimal SellingPrice { get; set; }
    public bool PrescriptionRequired { get; set; }
    public string? ImageUrl { get; set; }
    public string Availability { get; set; } = "InStock"; // InStock|OutOfStock|OnlineOnly|NearbyOnly

    /// <summary>Rupees cheaper than the most expensive equivalent brand.</summary>
    public decimal PriceDifference { get; set; }
    /// <summary>Percent cheaper than the most expensive equivalent brand.</summary>
    public decimal SavingsPercent { get; set; }
    public string SavingsBadge { get; set; } = "Low"; // Low|Medium|High
    public bool IsCheapestEquivalent { get; set; }
}

public class CompareBrandsResultDto
{
    public string CompositionName { get; set; } = default!;
    public string? Strength { get; set; }
    public List<BrandComparisonDto> Brands { get; set; } = new();
    public string Disclaimer { get; set; } =
        "Do not change prescribed medicines without consulting your doctor or pharmacist.";
}
