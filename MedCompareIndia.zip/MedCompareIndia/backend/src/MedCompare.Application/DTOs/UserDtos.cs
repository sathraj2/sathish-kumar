namespace MedCompare.Application.DTOs;

public class OtpRequestDto
{
    public string MobileNumber { get; set; } = default!;
}

public class OtpVerifyDto
{
    public string MobileNumber { get; set; } = default!;
    public string Otp { get; set; } = default!;
}

public class GoogleLoginDto
{
    public string IdToken { get; set; } = default!;
}

public class AuthResultDto
{
    public string AccessToken { get; set; } = default!;
    public string RefreshToken { get; set; } = default!;
    public DateTime ExpiresAtUtc { get; set; }
    public Guid UserId { get; set; }
    public bool IsGuest { get; set; }
}

public class FavoriteDto
{
    public long FavoriteId { get; set; }
    public MedicineSummaryDto Medicine { get; set; } = default!;
    public DateTime CreatedAtUtc { get; set; }
}

public class SearchHistoryDto
{
    public string SearchTerm { get; set; } = default!;
    public string SearchType { get; set; } = default!;
    public DateTime SearchedAtUtc { get; set; }
}
