namespace MedCompare.Application.DTOs;

public class NearbyPharmacyDto
{
    public int PharmacyId { get; set; }
    public string Name { get; set; } = default!;
    public string? Address { get; set; }
    public double Latitude { get; set; }
    public double Longitude { get; set; }
    public string? PhoneNumber { get; set; }
    public bool IsVerifiedPartner { get; set; }
    public double DistanceKm { get; set; }
    public decimal? MedicinePrice { get; set; }
    public bool? InStock { get; set; }
}
