using MedCompare.Application.DTOs;

namespace MedCompare.Application.Interfaces;

public interface IJwtTokenService
{
    AuthResultDto GenerateTokens(Guid userId, string role, bool isGuest = false);
}

public interface IOtpService
{
    Task<bool> SendOtpAsync(string mobileNumber, CancellationToken ct = default);
    Task<bool> VerifyOtpAsync(string mobileNumber, string otp, CancellationToken ct = default);
}

public interface IGoogleAuthService
{
    Task<(string ExternalId, string? Email, string? Name)?> ValidateIdTokenAsync(string idToken, CancellationToken ct = default);
}

/// <summary>TODO: implement against 1mg/Apollo/PharmEasy/Netmeds partner APIs or licensed data feeds.</summary>
public interface IOnlinePriceProvider
{
    Task<List<OnlinePriceDto>> GetPricesAsync(long medicineId, CancellationToken ct = default);
}

/// <summary>TODO: wire to Anthropic Claude API for natural-language medicine Q&A ("compare X and Y", "side effects of Z").</summary>
public interface IAiAssistantService
{
    Task<string> AskAsync(string question, string languageCode, CancellationToken ct = default);
}

/// <summary>TODO: integrate ML Kit (on-device, MAUI) or Azure AI Vision for barcode/OCR scanning.</summary>
public interface IOcrService
{
    Task<List<string>> ExtractMedicineNamesFromImageAsync(byte[] imageBytes, CancellationToken ct = default);
}

/// <summary>TODO: wire to platform push (FCM/APNs) for reminders, price-drop and back-in-stock alerts.</summary>
public interface INotificationService
{
    Task SendAsync(Guid userId, string type, string title, string body, long? relatedMedicineId = null, CancellationToken ct = default);
}
