using MedCompare.Application.Common;
using MedCompare.Application.DTOs;
using MedCompare.Domain.Entities;

namespace MedCompare.Application.Interfaces;

public interface IMedicineRepository
{
    Task<PagedResult<MedicineSummaryDto>> SearchAsync(string query, string? searchType, int pageNumber, int pageSize, CancellationToken ct = default);
    Task<MedicineDetailsDto?> GetDetailsAsync(long medicineId, CancellationToken ct = default);
    Task<List<BrandComparisonDto>> GetBrandsByCompositionAsync(int compositionId, string? strength, string sortBy, CancellationToken ct = default);
    Task<Medicine?> GetByIdAsync(long medicineId, CancellationToken ct = default);
}

public interface IPharmacyRepository
{
    Task<List<NearbyPharmacyDto>> GetNearbyAsync(double latitude, double longitude, double radiusKm, long? medicineId, CancellationToken ct = default);
}

public interface IUserRepository
{
    Task<User?> GetByMobileAsync(string mobileNumber, CancellationToken ct = default);
    Task<User?> GetByExternalAuthIdAsync(string externalAuthId, CancellationToken ct = default);
    Task<User> CreateAsync(User user, CancellationToken ct = default);
    Task<User?> GetByIdAsync(Guid userId, CancellationToken ct = default);
}

public interface IFavoriteRepository
{
    Task<List<FavoriteDto>> GetForUserAsync(Guid userId, CancellationToken ct = default);
    Task AddAsync(Guid userId, long medicineId, CancellationToken ct = default);
    Task RemoveAsync(Guid userId, long medicineId, CancellationToken ct = default);
}

public interface ISearchHistoryRepository
{
    Task<List<SearchHistoryDto>> GetForUserAsync(Guid? userId, int take, CancellationToken ct = default);
    Task LogAsync(Guid? userId, string term, string searchType, CancellationToken ct = default);
}
