namespace MedCompare.Application.Services;

/// <summary>
/// Lightweight rule-based parser used as a fallback / pre-filter before calling
/// the full AI assistant, for natural-language queries like:
///   "BP medicine below ₹100", "cheapest medicine for cholesterol",
///   "show alternatives to Dolo 650", "medicine for diabetes".
/// TODO: replace/augment with an LLM-backed intent classifier (Claude API) for
/// open-ended phrasing; this keeps the app functional and fast even offline
/// or when the AI service is unavailable.
/// </summary>
public class ParsedAiQuery
{
    public string? CategoryHint { get; set; }      // e.g. "Blood Pressure", "Diabetes"
    public string? BrandHint { get; set; }          // e.g. "Dolo 650"
    public decimal? MaxPrice { get; set; }
    public bool WantsCheapest { get; set; }
    public bool WantsAlternatives { get; set; }
}

public static class AiSearchQueryParser
{
    private static readonly Dictionary<string, string> CategoryKeywords = new(StringComparer.OrdinalIgnoreCase)
    {
        ["bp"] = "Blood Pressure",
        ["blood pressure"] = "Blood Pressure",
        ["cholesterol"] = "Cholesterol",
        ["diabetes"] = "Diabetes",
        ["sugar"] = "Diabetes",
        ["fever"] = "Fever/Pain",
        ["pain"] = "Fever/Pain",
    };

    public static ParsedAiQuery Parse(string query)
    {
        var result = new ParsedAiQuery();
        var lower = query.ToLowerInvariant();

        foreach (var kv in CategoryKeywords)
            if (lower.Contains(kv.Key)) { result.CategoryHint = kv.Value; break; }

        if (lower.Contains("cheapest") || lower.Contains("lowest price"))
            result.WantsCheapest = true;

        if (lower.Contains("alternative") || lower.Contains("instead of") || lower.Contains("compare"))
            result.WantsAlternatives = true;

        var priceMatch = System.Text.RegularExpressions.Regex.Match(lower, @"(?:below|under|less than)\s*(?:₹|rs\.?)?\s*(\d+)");
        if (priceMatch.Success && decimal.TryParse(priceMatch.Groups[1].Value, out var price))
            result.MaxPrice = price;

        var altMatch = System.Text.RegularExpressions.Regex.Match(query, @"(?:to|of)\s+([A-Za-z0-9 ]+\d*)$");
        if (result.WantsAlternatives && altMatch.Success)
            result.BrandHint = altMatch.Groups[1].Value.Trim();

        return result;
    }
}
