using MedCompare.Application.DTOs;
using MedCompare.Domain.Enums;

namespace MedCompare.Application.Services;

/// <summary>
/// Pure, unit-testable domain logic for the "Smart Savings Score" feature:
/// given a set of brands sharing the same composition + strength, computes
/// price difference / % saved / a Low-Medium-High badge relative to the
/// most expensive equivalent, and flags the cheapest option.
/// </summary>
public static class SmartSavingsCalculator
{
    public static void Apply(List<BrandComparisonDto> brands)
    {
        if (brands.Count == 0) return;

        var maxPrice = brands.Max(b => b.SellingPrice);
        var minPrice = brands.Min(b => b.SellingPrice);

        foreach (var b in brands)
        {
            b.PriceDifference = Math.Round(maxPrice - b.SellingPrice, 2);
            b.SavingsPercent = maxPrice > 0
                ? Math.Round((maxPrice - b.SellingPrice) / maxPrice * 100, 0)
                : 0;
            b.SavingsBadge = BadgeFor(b.SavingsPercent).ToString();
            b.IsCheapestEquivalent = b.SellingPrice == minPrice;
        }
    }

    public static SavingsBadge BadgeFor(decimal savingsPercent) => savingsPercent switch
    {
        >= 40 => SavingsBadge.High,
        >= 15 => SavingsBadge.Medium,
        _     => SavingsBadge.Low
    };

    /// <summary>Human-readable message: "You can save ₹120 (65%) by choosing a lower-priced equivalent..."</summary>
    public static string BuildMessage(BrandComparisonDto cheapest, decimal comparedToPrice)
    {
        var amount = Math.Round(comparedToPrice - cheapest.SellingPrice, 0);
        var pct = comparedToPrice > 0 ? Math.Round((comparedToPrice - cheapest.SellingPrice) / comparedToPrice * 100, 0) : 0;
        return $"You can save ₹{amount} ({pct}%) by choosing a lower-priced equivalent with the same composition.";
    }

    public const string MedicalDisclaimer =
        "Do not change prescribed medicines without consulting your doctor or pharmacist.";
}
