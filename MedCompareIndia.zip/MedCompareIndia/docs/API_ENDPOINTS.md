# API Contract (v1)

Base URL: `https://api.medcompareindia.com/` (configure per environment)
All responses use the `ApiResponse<T>` envelope: `{ success, message, data, errors }`.

## Auth
| Method | Route                     | Auth | Body                              | Notes |
|--------|---------------------------|------|------------------------------------|-------|
| POST   | /api/auth/otp/request     | none | `{ mobileNumber }`                  | sends OTP (dev: logged, not SMS'd) |
| POST   | /api/auth/otp/verify      | none | `{ mobileNumber, otp }`             | returns JWT, creates user if new |
| POST   | /api/auth/google          | none | `{ idToken }`                       | validates Google ID token, returns JWT |
| POST   | /api/auth/guest           | none | -                                    | returns a guest JWT (`isGuest: true`) |

## Medicine
| Method | Route                                        | Auth | Query params |
|--------|-----------------------------------------------|------|----------------|
| GET    | /api/medicine/search                          | none | `query` (required), `searchType` (Name\|Brand\|Composition\|Manufacturer), `pageNumber`, `pageSize` (max 50) |
| GET    | /api/medicine/details/{id}                    | none | - |
| GET    | /api/medicine/compare/{compositionId}         | none | `strength`, `sortBy` (LowestPrice\|HighestPrice\|Manufacturer\|Rating) |

## Pharmacy
| Method | Route                | Auth | Query params |
|--------|-----------------------|------|----------------|
| GET    | /api/pharmacy/nearby  | none | `latitude`, `longitude` (required), `radiusKm` (default 5), `medicineId` (optional) |

## User (JWT required)
| Method | Route                              | Notes |
|--------|--------------------------------------|-------|
| GET    | /api/user/favorites                  | list favorites for the current user |
| POST   | /api/user/favorites/{medicineId}     | idempotent add |
| DELETE | /api/user/favorites/{medicineId}     | remove |
| GET    | /api/user/history?take=20            | recent search history |

## Not yet implemented (interfaces exist, see docs/ARCHITECTURE.md)
- `POST /api/ai/ask` — natural-language medicine assistant (`IAiAssistantService`)
- `POST /api/scan/ocr` — prescription/barcode OCR (`IOcrService`)
- `GET /api/medicine/online-prices/{id}` — live 1mg/Apollo/PharmEasy/Netmeds prices (`IOnlinePriceProvider`)
- Admin endpoints (`/api/admin/*`) for CSV import, price updates, analytics
