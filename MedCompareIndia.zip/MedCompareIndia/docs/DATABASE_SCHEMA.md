# Database Schema Overview

See `database/*.sql` for the full DDL. Summary:

## Schemas
- `med` — medicines, manufacturers, compositions, prices (in-house + online)
- `usr` — users, favorites, search history, reminders, notifications, family members
- `geo` — pharmacies and per-pharmacy stock/price
- `log` — audit logs

## Key relationships
```
Composition (1) ───< (N) Medicine (N) >─── (1) Manufacturer
Medicine (1) ───< (N) OnlinePrice        [Tata1mg | Apollo | PharmEasy | Netmeds]
Medicine (1) ───< (N) MedicinePriceHistory
Medicine (1) ───< (N) PharmacyStock >─── (1) Pharmacy
User (1) ───< (N) Favorite (N) >─── (1) Medicine
User (1) ───< (N) SearchHistory
User (1) ───< (N) MedicineReminder (N) >─── (1) Medicine
User (1) ───< (N) FamilyMember
```

## Why `CompositionId` is the comparison key
Compare Brands and the Smart Savings Score both group on `(CompositionId, Strength)` —
e.g. every brand of "Paracetamol 650mg" — not on brand name or manufacturer. This is what
lets `sp_CompareBrands` / `GetBrandsByCompositionAsync` return "same composition, different
brand" results instead of literal string matches.

## Indexing philosophy (see `03_Indexes.sql`)
- Filtered indexes (`WHERE IsActive = 1`) keep the index small since inactive/delisted
  medicines are excluded from search and comparison.
- `IX_Medicines_Composition_Strength_Price` directly supports the compare-brands sort-by-price
  query pattern without a sort operator in the plan.
- SQL Server Full-Text Search is included as a fast, no-extra-infrastructure option for
  launch; the repository layer is written against an interface so Elasticsearch can replace
  it later (see docs/ARCHITECTURE.md) without changing calling code.
- `geo.Pharmacies` uses a basic spatial index; for real scale, migrate `Latitude`/`Longitude`
  to a single `geography` column and query with `STDistance()` for accurate, index-backed
  distance search (the current Haversine calculation in `PharmacyRepository` is done in
  application memory, which is fine at small scale but won't scale past a few thousand pharmacies).

## Migrations
This skeleton ships raw SQL scripts for clarity and portability. For ongoing schema changes,
generate EF Core migrations from `MedCompareDbContext` (`dotnet ef migrations add ...`) and
apply `dotnet ef database update` — keep the raw SQL scripts as the "day 0" reference/seed.
