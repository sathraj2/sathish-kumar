# Architecture

## Clean Architecture layering (backend)

```
MedCompare.Domain          <- entities, enums. No dependencies on anything.
       ^
MedCompare.Application     <- DTOs, repository/service interfaces, business rules
       ^                      (Smart Savings Score, AI query parsing). Depends only on Domain.
MedCompare.Infrastructure  <- EF Core, SQL Server, Redis, JWT, OTP/Google/OCR/AI stubs.
       ^                      Implements Application's interfaces. Depends on Application.
MedCompare.API             <- Controllers, Program.cs, middleware, Swagger.
                              Wires everything together via DI. Depends on Infrastructure.
```

Dependency direction always points inward (API/Infrastructure -> Application -> Domain), so
business logic (e.g. `SmartSavingsCalculator`) is unit-testable with zero database or HTTP
dependencies — see `MedCompare.Tests/Services/SmartSavingsCalculatorTests.cs`.

## Repository Pattern

Every data access path goes through an interface defined in `Application/Interfaces`
(`IMedicineRepository`, `IPharmacyRepository`, `IUserRepository`, `IFavoriteRepository`,
`ISearchHistoryRepository`). Controllers depend only on these interfaces, never on
`MedCompareDbContext` directly. This is what makes it possible to:
- Swap SQL Server full-text search for Elasticsearch later without touching controllers
  (just add an `ElasticMedicineRepository : IMedicineRepository`).
- Add the Redis cache-aside decorator (`CachedMedicineRepository`) transparently.
- Mock repositories in unit tests instead of standing up a real database.

## Caching strategy (scale)

`CachedMedicineRepository` wraps `MedicineRepository` with Redis cache-aside for the two
hottest read paths — `search` and `compare` — with a 10-minute TTL. Cache keys are
deterministic (`search:{type}:{query}:{page}:{size}`, `compare:{compositionId}:{strength}:{sortBy}`)
so repeated identical queries across millions of users hit Redis, not SQL Server.
Cache invalidation: when the admin portal updates a price, publish an event (or simply
delete the relevant keys) — not implemented in this skeleton, flagged as a TODO in
`CachedMedicineRepository`.

## Authentication

Three login modes map to `AuthProvider` (`Google`, `Otp`, `Guest`):
- **OTP**: `POST /api/auth/otp/request` → `DevOtpService` (swap for MSG91/Twilio/SNS in prod,
  and back the OTP store with Redis instead of an in-memory dictionary) → `POST /api/auth/otp/verify`
  issues a JWT.
- **Google**: `POST /api/auth/google` takes an ID token from the native Google Sign-In SDK on
  the MAUI side; `GoogleAuthService.ValidateIdTokenAsync` is a stub — wire
  `Google.Apis.Auth.GoogleJsonWebSignature.ValidateAsync`.
- **Guest**: `POST /api/auth/guest` issues a JWT with `isGuest: true` and no persisted user
  row, so guests can browse/search/compare but should be blocked (403, not implemented yet)
  from favorites/reminders which require a real identity.

JWTs are signed with `Jwt:Key` (HMAC-SHA256). **Rotate this to a long random secret stored
in a secrets manager (Azure Key Vault / AWS Secrets Manager) before shipping** — the value in
`appsettings.json` is a placeholder.

## Smart Savings Score

Computed in `MedCompare.Application.Services.SmartSavingsCalculator`, not in SQL or in the
mobile app, so:
1. It's covered by fast, deterministic unit tests (no DB needed).
2. It's identical whether the underlying brand list came from SQL Server or (later)
   Elasticsearch — the calculator only needs a `List<BrandComparisonDto>`.
3. Badge thresholds (Low <15%, Medium 15–39%, High ≥40%) live in one place and can be tuned
   without touching controllers, repositories, or the mobile client.

## Scaling to "millions of users" — what's here vs. what's next

| Concern                     | In this skeleton                                   | Next step for real scale                              |
|------------------------------|----------------------------------------------------|--------------------------------------------------------|
| Search                       | SQL Server indexes + full-text catalog             | Elasticsearch behind `IMedicineRepository`              |
| Hot-path caching              | Redis cache-aside for search/compare                | Add cache invalidation on price update, CDN for images  |
| Read scaling                  | Single SQL Server + `EnableRetryOnFailure`          | Read replicas, route GETs to replica connection string  |
| Background sync (prices)      | `IOnlinePriceProvider` stub                         | Hosted service / Azure Function polling 1mg/Apollo APIs |
| Notifications                 | `INotificationService` logs only                    | FCM/APNs + a queue (Azure Service Bus/SQS)               |
| Rate limiting                 | `AspNetCoreRateLimit`, 120 req/min/IP default       | Tune per-endpoint, add auth-aware limits                |
| Deployment                    | Not included (no Dockerfile in this pass)           | Containerize API, deploy to AKS/App Service, add HPA     |

## Localization

`.resx`-style resource structure is expected under `mobile/.../Resources/Strings/` (not
scaffolded in this pass to keep scope focused) — one file per language (`en`, `hi`, `ta`,
`te`, `ml`, `kn`). `ProfileViewModel.SelectedLanguage` already persists the user's choice;
wire it to `CultureInfo.CurrentUICulture` and a `LocalizationResourceManager` on app start.
