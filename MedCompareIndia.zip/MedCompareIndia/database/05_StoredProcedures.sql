USE MedCompareIndiaDb;
GO

/* =========================================================
   med.sp_SearchMedicines
   Fast paginated search across brand / generic / composition / manufacturer
   ========================================================= */
CREATE OR ALTER PROCEDURE med.sp_SearchMedicines
    @SearchTerm   NVARCHAR(300),
    @PageNumber   INT = 1,
    @PageSize     INT = 20
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @Offset INT = (@PageNumber - 1) * @PageSize;
    DECLARE @Like NVARCHAR(302) = '%' + @SearchTerm + '%';

    SELECT
        m.MedicineId, m.BrandName, m.GenericName, m.Strength, m.DosageForm,
        m.PackSize, m.MRP, m.SellingPrice, m.PrescriptionRequired,
        m.Category, m.ImageUrl,
        c.CompositionId, c.Name AS CompositionName,
        mf.ManufacturerId, mf.Name AS ManufacturerName, mf.Rating AS ManufacturerRating,
        COUNT(*) OVER() AS TotalCount
    FROM med.Medicines m
    INNER JOIN med.Compositions c  ON c.CompositionId = m.CompositionId
    INNER JOIN med.Manufacturers mf ON mf.ManufacturerId = m.ManufacturerId
    WHERE m.IsActive = 1
      AND (
            m.BrandName LIKE @Like
         OR m.GenericName LIKE @Like
         OR c.Name LIKE @Like
         OR mf.Name LIKE @Like
      )
    ORDER BY
        CASE WHEN m.BrandName = @SearchTerm THEN 0 ELSE 1 END, -- exact matches first
        m.BrandName ASC
    OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY;
END
GO

/* =========================================================
   med.sp_CompareBrands
   Returns all brands for the composition + strength of a given medicine,
   with price difference and % savings vs the most expensive brand.
   ========================================================= */
CREATE OR ALTER PROCEDURE med.sp_CompareBrands
    @CompositionId INT,
    @Strength      NVARCHAR(50) = NULL,
    @SortBy        VARCHAR(20) = 'LowestPrice'  -- LowestPrice|HighestPrice|Manufacturer|Rating
AS
BEGIN
    SET NOCOUNT ON;

    ;WITH Brands AS (
        SELECT
            m.MedicineId, m.BrandName, m.Strength, m.PackSize,
            m.MRP, m.SellingPrice, m.PrescriptionRequired, m.ImageUrl,
            mf.ManufacturerId, mf.Name AS ManufacturerName, mf.Rating AS ManufacturerRating
        FROM med.Medicines m
        INNER JOIN med.Manufacturers mf ON mf.ManufacturerId = m.ManufacturerId
        WHERE m.CompositionId = @CompositionId
          AND m.IsActive = 1
          AND (@Strength IS NULL OR m.Strength = @Strength)
    ),
    Bounds AS (
        SELECT MAX(SellingPrice) AS MaxPrice, MIN(SellingPrice) AS MinPrice FROM Brands
    )
    SELECT
        b.*,
        (bd.MaxPrice - b.SellingPrice)                                  AS PriceDifference,
        CASE WHEN bd.MaxPrice > 0
             THEN ROUND((bd.MaxPrice - b.SellingPrice) / bd.MaxPrice * 100, 0)
             ELSE 0 END                                                  AS SavingsPercent,
        CASE WHEN b.SellingPrice = bd.MinPrice THEN 1 ELSE 0 END         AS IsCheapestEquivalent
    FROM Brands b
    CROSS JOIN Bounds bd
    ORDER BY
        CASE WHEN @SortBy = 'LowestPrice'  THEN b.SellingPrice END ASC,
        CASE WHEN @SortBy = 'HighestPrice' THEN b.SellingPrice END DESC,
        CASE WHEN @SortBy = 'Manufacturer' THEN b.ManufacturerName END ASC,
        CASE WHEN @SortBy = 'Rating'       THEN b.ManufacturerRating END DESC;
END
GO

/* =========================================================
   geo.sp_NearbyPharmacies
   Haversine distance in km from user's lat/lng, includes stock/price for a medicine if given
   ========================================================= */
CREATE OR ALTER PROCEDURE geo.sp_NearbyPharmacies
    @Latitude    DECIMAL(9,6),
    @Longitude   DECIMAL(9,6),
    @RadiusKm    DECIMAL(6,2) = 5,
    @MedicineId  BIGINT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    ;WITH Distances AS (
        SELECT
            p.PharmacyId, p.Name, p.Address, p.PhoneNumber, p.Latitude, p.Longitude,
            p.IsVerifiedPartner,
            6371 * ACOS(
                COS(RADIANS(@Latitude)) * COS(RADIANS(p.Latitude)) *
                COS(RADIANS(p.Longitude) - RADIANS(@Longitude)) +
                SIN(RADIANS(@Latitude)) * SIN(RADIANS(p.Latitude))
            ) AS DistanceKm
        FROM geo.Pharmacies p
        WHERE p.IsActive = 1
    )
    SELECT d.*, s.Price AS MedicinePrice, s.InStock
    FROM Distances d
    LEFT JOIN geo.PharmacyStock s
        ON s.PharmacyId = d.PharmacyId AND @MedicineId IS NOT NULL AND s.MedicineId = @MedicineId
    WHERE d.DistanceKm <= @RadiusKm
    ORDER BY d.DistanceKm ASC;
END
GO
