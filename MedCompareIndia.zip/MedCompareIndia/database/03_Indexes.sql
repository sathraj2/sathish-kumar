USE MedCompareIndiaDb;
GO

/* ---- Fast lookups for search-by-name/brand/composition/manufacturer ---- */
CREATE NONCLUSTERED INDEX IX_Medicines_BrandName
    ON med.Medicines(BrandName) INCLUDE (SellingPrice, MRP, ImageUrl, ManufacturerId, CompositionId)
    WHERE IsActive = 1;
GO

CREATE NONCLUSTERED INDEX IX_Medicines_GenericName
    ON med.Medicines(GenericName) INCLUDE (SellingPrice, MRP)
    WHERE IsActive = 1;
GO

CREATE NONCLUSTERED INDEX IX_Medicines_CompositionId
    ON med.Medicines(CompositionId) INCLUDE (SellingPrice, MRP, ManufacturerId, Strength)
    WHERE IsActive = 1;
GO

CREATE NONCLUSTERED INDEX IX_Medicines_ManufacturerId
    ON med.Medicines(ManufacturerId)
    WHERE IsActive = 1;
GO

CREATE NONCLUSTERED INDEX IX_Medicines_Category
    ON med.Medicines(Category)
    WHERE IsActive = 1;
GO

-- Compare-brands query pattern: same composition + strength, cheapest first
CREATE NONCLUSTERED INDEX IX_Medicines_Composition_Strength_Price
    ON med.Medicines(CompositionId, Strength, SellingPrice)
    WHERE IsActive = 1;
GO

/* ---- SQL Server Full-Text Search (fallback / complement to Elasticsearch) ---- */
IF NOT EXISTS (SELECT 1 FROM sys.fulltext_catalogs WHERE name = 'MedicineFtCatalog')
    CREATE FULLTEXT CATALOG MedicineFtCatalog AS DEFAULT;
GO

-- Requires a unique single-column index for full-text key
CREATE UNIQUE INDEX UX_Medicines_MedicineId ON med.Medicines(MedicineId);
GO

CREATE FULLTEXT INDEX ON med.Medicines(BrandName LANGUAGE 1033, GenericName LANGUAGE 1033)
    KEY INDEX UX_Medicines_MedicineId
    ON MedicineFtCatalog
    WITH CHANGE_TRACKING AUTO;
GO

CREATE UNIQUE INDEX UX_Compositions_CompositionId ON med.Compositions(CompositionId);
GO

CREATE FULLTEXT INDEX ON med.Compositions(Name LANGUAGE 1033)
    KEY INDEX UX_Compositions_CompositionId
    ON MedicineFtCatalog
    WITH CHANGE_TRACKING AUTO;
GO

/* ---- Geo lookups for nearby pharmacy ---- */
CREATE SPATIAL INDEX SIX_Pharmacies_Location
    ON geo.Pharmacies(Latitude) -- NOTE: for production, add a geography column (see docs/DATABASE_SCHEMA.md)
    USING GEOMETRY_AUTO_GRID;
GO

CREATE NONCLUSTERED INDEX IX_PharmacyStock_MedicineId
    ON geo.PharmacyStock(MedicineId) INCLUDE (PharmacyId, Price, InStock);
GO

/* ---- User activity ---- */
CREATE NONCLUSTERED INDEX IX_SearchHistory_UserId_SearchedAt
    ON usr.SearchHistory(UserId, SearchedAtUtc DESC);
GO

CREATE NONCLUSTERED INDEX IX_Favorites_UserId
    ON usr.Favorites(UserId);
GO

CREATE NONCLUSTERED INDEX IX_Notifications_UserId_IsRead
    ON usr.Notifications(UserId, IsRead) INCLUDE (CreatedAtUtc);
GO

CREATE NONCLUSTERED INDEX IX_OnlinePrices_MedicineId
    ON med.OnlinePrices(MedicineId) INCLUDE (Platform, Price, InStock);
GO
