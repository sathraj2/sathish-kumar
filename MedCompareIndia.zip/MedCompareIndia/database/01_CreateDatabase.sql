/* =========================================================
   MedCompare India - Database Creation
   Target: SQL Server 2019+ / Azure SQL
   ========================================================= */
IF DB_ID('MedCompareIndiaDb') IS NULL
BEGIN
    CREATE DATABASE MedCompareIndiaDb
    COLLATE SQL_Latin1_General_CP1_CI_AS;
END
GO

ALTER DATABASE MedCompareIndiaDb SET READ_COMMITTED_SNAPSHOT ON;
GO

USE MedCompareIndiaDb;
GO

IF SCHEMA_ID('med') IS NULL EXEC('CREATE SCHEMA med');
IF SCHEMA_ID('usr') IS NULL EXEC('CREATE SCHEMA usr');
IF SCHEMA_ID('geo') IS NULL EXEC('CREATE SCHEMA geo');
IF SCHEMA_ID('log') IS NULL EXEC('CREATE SCHEMA log');
GO
