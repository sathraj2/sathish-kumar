USE MedCompareIndiaDb;
GO

INSERT INTO med.Manufacturers (Name, Rating) VALUES
 ('Micro Labs Ltd', 4.2),
 ('Cipla Ltd', 4.5),
 ('Sun Pharmaceutical', 4.4),
 ('GlaxoSmithKline Pharmaceuticals', 4.3),
 ('Mankind Pharma', 4.1);
GO

INSERT INTO med.Compositions (Name, NormalizedName, Category, Uses, SideEffects, Warnings) VALUES
 ('Paracetamol 650mg', 'paracetamol 650mg', 'Analgesic/Antipyretic',
  N'Used for fever and mild to moderate pain relief.',
  N'Nausea, rash (rare), liver stress at high doses.',
  N'Do not exceed prescribed dose. Avoid with alcohol or existing liver conditions.'),
 ('Amlodipine 5mg', 'amlodipine 5mg', 'Antihypertensive (BP)',
  N'Used to treat high blood pressure and chest pain (angina).',
  N'Swelling in ankles, dizziness, flushing.',
  N'Consult doctor before stopping abruptly.'),
 ('Metformin 500mg', 'metformin 500mg', 'Antidiabetic',
  N'Used to control blood sugar in type 2 diabetes.',
  N'GI upset, metallic taste.',
  N'Not for type 1 diabetes. Monitor kidney function.');
GO

-- Brands sharing the Paracetamol 650mg composition (drives Compare Brands + Smart Savings Score)
INSERT INTO med.Medicines (BrandName, GenericName, CompositionId, Strength, DosageForm, ManufacturerId, PackSize, MRP, SellingPrice, PrescriptionRequired, Category, ImageUrl)
VALUES
 ('Dolo 650', 'Paracetamol', 1, '650mg', 'Tablet', 3, '15 tablets', 33.10, 30.50, 0, 'Fever/Pain', '/images/dolo650.png'),
 ('Crocin Advance', 'Paracetamol', 1, '650mg', 'Tablet', 4, '15 tablets', 39.00, 36.00, 0, 'Fever/Pain', '/images/crocin.png'),
 ('Calpol 650', 'Paracetamol', 1, '650mg', 'Tablet', 4, '15 tablets', 30.00, 27.00, 0, 'Fever/Pain', '/images/calpol.png'),
 ('P-650', 'Paracetamol', 1, '650mg', 'Tablet', 1, '15 tablets', 18.50, 16.00, 0, 'Fever/Pain', '/images/p650.png');

-- Brands sharing the Amlodipine 5mg composition
INSERT INTO med.Medicines (BrandName, GenericName, CompositionId, Strength, DosageForm, ManufacturerId, PackSize, MRP, SellingPrice, PrescriptionRequired, Category, ImageUrl)
VALUES
 ('Amlong 5', 'Amlodipine', 2, '5mg', 'Tablet', 3, '10 tablets', 45.00, 41.00, 1, 'Blood Pressure', '/images/amlong5.png'),
 ('Amlopres 5', 'Amlodipine', 2, '5mg', 'Tablet', 4, '10 tablets', 28.00, 25.00, 1, 'Blood Pressure', '/images/amlopres5.png'),
 ('Stamlo 5', 'Amlodipine', 2, '5mg', 'Tablet', 4, '10 tablets', 24.50, 21.00, 1, 'Blood Pressure', '/images/stamlo5.png');
GO

INSERT INTO geo.Pharmacies (Name, Address, Latitude, Longitude, PhoneNumber, IsVerifiedPartner) VALUES
 ('Apollo Pharmacy - Anna Nagar', 'Anna Nagar, Chennai', 13.0850, 80.2101, '+914412345678', 1),
 ('MedPlus - T Nagar', 'T Nagar, Chennai', 13.0418, 80.2341, '+914487654321', 1),
 ('Netmeds Store - Velachery', 'Velachery, Chennai', 12.9791, 80.2212, '+914455566677', 0);
GO

INSERT INTO med.OnlinePrices (MedicineId, Platform, Price, InStock, DeepLinkUrl) VALUES
 (1, 'Tata1mg', 29.50, 1, 'https://www.1mg.com/drugs/dolo-650-tablet'),
 (1, 'Apollo', 30.50, 1, 'https://www.apollopharmacy.in/search-medicine/Dolo%20650'),
 (1, 'PharmEasy', 29.90, 1, 'https://pharmeasy.in/search/all?name=Dolo%20650'),
 (1, 'Netmeds', 31.00, 0, 'https://www.netmeds.com/catalogsearch/result?q=Dolo+650');
GO
