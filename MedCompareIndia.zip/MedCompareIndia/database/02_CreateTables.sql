USE MedCompareIndiaDb;
GO

/* =========================================================
   usr.Users
   ========================================================= */
CREATE TABLE usr.Users (
    UserId              UNIQUEIDENTIFIER NOT NULL CONSTRAINT DF_Users_Id DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
    FullName            NVARCHAR(150)    NULL,
    Email               NVARCHAR(256)    NULL,
    MobileNumber        VARCHAR(15)      NULL,
    AuthProvider        VARCHAR(20)      NOT NULL,      -- 'Google' | 'OTP' | 'Guest'
    ExternalAuthId      NVARCHAR(200)    NULL,           -- Google sub id
    Role                VARCHAR(20)      NOT NULL CONSTRAINT DF_Users_Role DEFAULT 'User', -- User | Admin | PharmacyPartner
    PreferredLanguage   VARCHAR(5)       NOT NULL CONSTRAINT DF_Users_Lang DEFAULT 'en',
    IsDarkModeEnabled   BIT              NOT NULL CONSTRAINT DF_Users_Dark DEFAULT 0,
    IsActive            BIT              NOT NULL CONSTRAINT DF_Users_Active DEFAULT 1,
    CreatedAtUtc        DATETIME2        NOT NULL CONSTRAINT DF_Users_Created DEFAULT SYSUTCDATETIME(),
    LastLoginAtUtc      DATETIME2        NULL,
    CONSTRAINT UQ_Users_Email UNIQUE (Email),
    CONSTRAINT UQ_Users_Mobile UNIQUE (MobileNumber)
);
GO

/* =========================================================
   usr.FamilyMembers  (family medicine profiles)
   ========================================================= */
CREATE TABLE usr.FamilyMembers (
    FamilyMemberId  UNIQUEIDENTIFIER NOT NULL CONSTRAINT DF_Fam_Id DEFAULT NEWSEQUENTIALID() PRIMARY KEY,
    UserId          UNIQUEIDENTIFIER NOT NULL REFERENCES usr.Users(UserId),
    Name            NVARCHAR(150) NOT NULL,
    Relationship    NVARCHAR(50)  NULL,
    DateOfBirth     DATE          NULL,
    CreatedAtUtc    DATETIME2     NOT NULL CONSTRAINT DF_Fam_Created DEFAULT SYSUTCDATETIME()
);
GO

/* =========================================================
   med.Manufacturers
   ========================================================= */
CREATE TABLE med.Manufacturers (
    ManufacturerId  INT IDENTITY(1,1) PRIMARY KEY,
    Name            NVARCHAR(200) NOT NULL,
    Rating          DECIMAL(2,1)  NULL,           -- 0.0 - 5.0
    Website         NVARCHAR(300) NULL,
    LogoUrl         NVARCHAR(500) NULL,
    IsActive        BIT NOT NULL CONSTRAINT DF_Mfr_Active DEFAULT 1
);
GO

/* =========================================================
   med.Compositions   (the "same salt" grouping key)
   ========================================================= */
CREATE TABLE med.Compositions (
    CompositionId   INT IDENTITY(1,1) PRIMARY KEY,
    Name            NVARCHAR(300) NOT NULL,       -- e.g. "Paracetamol"
    NormalizedName  NVARCHAR(300) NOT NULL,       -- lower, trimmed, for matching
    Category        NVARCHAR(100) NULL,           -- e.g. "Analgesic"
    Uses            NVARCHAR(MAX) NULL,
    SideEffects     NVARCHAR(MAX) NULL,
    Warnings        NVARCHAR(MAX) NULL,
    PregnancyLactationWarning NVARCHAR(MAX) NULL,
    CONSTRAINT UQ_Compositions_Normalized UNIQUE (NormalizedName)
);
GO

/* =========================================================
   med.Medicines
   ========================================================= */
CREATE TABLE med.Medicines (
    MedicineId              BIGINT IDENTITY(1,1) PRIMARY KEY,
    BrandName               NVARCHAR(250) NOT NULL,
    GenericName              NVARCHAR(250) NULL,
    CompositionId            INT NOT NULL REFERENCES med.Compositions(CompositionId),
    Strength                 NVARCHAR(50)  NULL,      -- e.g. "500mg"
    DosageForm               NVARCHAR(50)  NULL,      -- Tablet, Syrup, Injection...
    ManufacturerId            INT NOT NULL REFERENCES med.Manufacturers(ManufacturerId),
    PackSize                 NVARCHAR(50)  NULL,      -- e.g. "10 tablets"
    MRP                      DECIMAL(10,2) NOT NULL,
    SellingPrice              DECIMAL(10,2) NOT NULL,
    PrescriptionRequired      BIT NOT NULL CONSTRAINT DF_Med_Rx DEFAULT 0,
    Category                  NVARCHAR(100) NULL,
    ImageUrl                  NVARCHAR(500) NULL,
    StorageInstructions       NVARCHAR(500) NULL,
    IsActive                  BIT NOT NULL CONSTRAINT DF_Med_Active DEFAULT 1,
    CreatedAtUtc               DATETIME2 NOT NULL CONSTRAINT DF_Med_Created DEFAULT SYSUTCDATETIME(),
    UpdatedAtUtc                DATETIME2 NOT NULL CONSTRAINT DF_Med_Updated DEFAULT SYSUTCDATETIME(),
    CONSTRAINT CK_Med_Prices CHECK (SellingPrice <= MRP AND MRP >= 0)
);
GO

/* =========================================================
   med.MedicinePrices  (price history — enables price-drop alerts)
   ========================================================= */
CREATE TABLE med.MedicinePrices (
    MedicinePriceId  BIGINT IDENTITY(1,1) PRIMARY KEY,
    MedicineId       BIGINT NOT NULL REFERENCES med.Medicines(MedicineId),
    MRP              DECIMAL(10,2) NOT NULL,
    SellingPrice     DECIMAL(10,2) NOT NULL,
    EffectiveFromUtc DATETIME2 NOT NULL CONSTRAINT DF_MedPrice_From DEFAULT SYSUTCDATETIME(),
    Source           VARCHAR(30) NOT NULL CONSTRAINT DF_MedPrice_Source DEFAULT 'Admin' -- Admin | Sync
);
GO

/* =========================================================
   med.OnlinePrices  (Tata 1mg / Apollo / PharmEasy / Netmeds)
   ========================================================= */
CREATE TABLE med.OnlinePrices (
    OnlinePriceId    BIGINT IDENTITY(1,1) PRIMARY KEY,
    MedicineId       BIGINT NOT NULL REFERENCES med.Medicines(MedicineId),
    Platform         VARCHAR(30) NOT NULL,       -- Tata1mg | Apollo | PharmEasy | Netmeds
    Price            DECIMAL(10,2) NOT NULL,
    DeepLinkUrl      NVARCHAR(500) NULL,
    InStock          BIT NOT NULL CONSTRAINT DF_Online_Stock DEFAULT 1,
    LastSyncedUtc    DATETIME2 NOT NULL CONSTRAINT DF_Online_Synced DEFAULT SYSUTCDATETIME()
);
GO

/* =========================================================
   geo.Pharmacies  and geo.PharmacyStock
   ========================================================= */
CREATE TABLE geo.Pharmacies (
    PharmacyId       INT IDENTITY(1,1) PRIMARY KEY,
    Name             NVARCHAR(250) NOT NULL,
    Address          NVARCHAR(500) NULL,
    Latitude         DECIMAL(9,6)  NOT NULL,
    Longitude        DECIMAL(9,6)  NOT NULL,
    PhoneNumber      VARCHAR(20)   NULL,
    IsVerifiedPartner BIT NOT NULL CONSTRAINT DF_Pharm_Verified DEFAULT 0,
    IsActive         BIT NOT NULL CONSTRAINT DF_Pharm_Active DEFAULT 1
);
GO

CREATE TABLE geo.PharmacyStock (
    PharmacyStockId  BIGINT IDENTITY(1,1) PRIMARY KEY,
    PharmacyId       INT NOT NULL REFERENCES geo.Pharmacies(PharmacyId),
    MedicineId       BIGINT NOT NULL REFERENCES med.Medicines(MedicineId),
    Price            DECIMAL(10,2) NULL,
    InStock          BIT NOT NULL CONSTRAINT DF_PharmStock_InStock DEFAULT 1,
    UpdatedAtUtc     DATETIME2 NOT NULL CONSTRAINT DF_PharmStock_Updated DEFAULT SYSUTCDATETIME(),
    CONSTRAINT UQ_PharmacyStock UNIQUE (PharmacyId, MedicineId)
);
GO

/* =========================================================
   usr.SearchHistory
   ========================================================= */
CREATE TABLE usr.SearchHistory (
    SearchHistoryId  BIGINT IDENTITY(1,1) PRIMARY KEY,
    UserId           UNIQUEIDENTIFIER NULL REFERENCES usr.Users(UserId), -- null for guest
    SearchTerm       NVARCHAR(300) NOT NULL,
    SearchType       VARCHAR(20)   NOT NULL CONSTRAINT DF_Search_Type DEFAULT 'Name', -- Name|Brand|Composition|Manufacturer|AI
    SearchedAtUtc    DATETIME2     NOT NULL CONSTRAINT DF_Search_At DEFAULT SYSUTCDATETIME()
);
GO

/* =========================================================
   usr.Favorites
   ========================================================= */
CREATE TABLE usr.Favorites (
    FavoriteId    BIGINT IDENTITY(1,1) PRIMARY KEY,
    UserId        UNIQUEIDENTIFIER NOT NULL REFERENCES usr.Users(UserId),
    MedicineId    BIGINT NOT NULL REFERENCES med.Medicines(MedicineId),
    CreatedAtUtc  DATETIME2 NOT NULL CONSTRAINT DF_Fav_Created DEFAULT SYSUTCDATETIME(),
    CONSTRAINT UQ_Favorites UNIQUE (UserId, MedicineId)
);
GO

/* =========================================================
   usr.MedicineReminders
   ========================================================= */
CREATE TABLE usr.MedicineReminders (
    ReminderId       BIGINT IDENTITY(1,1) PRIMARY KEY,
    UserId           UNIQUEIDENTIFIER NOT NULL REFERENCES usr.Users(UserId),
    FamilyMemberId   UNIQUEIDENTIFIER NULL REFERENCES usr.FamilyMembers(FamilyMemberId),
    MedicineId       BIGINT NOT NULL REFERENCES med.Medicines(MedicineId),
    TimesOfDayCsv    VARCHAR(100) NOT NULL,   -- "08:00,14:00,21:00"
    StartDate        DATE NOT NULL,
    EndDate          DATE NULL,
    IsActive         BIT NOT NULL CONSTRAINT DF_Rem_Active DEFAULT 1,
    CreatedAtUtc     DATETIME2 NOT NULL CONSTRAINT DF_Rem_Created DEFAULT SYSUTCDATETIME()
);
GO

/* =========================================================
   usr.Notifications
   ========================================================= */
CREATE TABLE usr.Notifications (
    NotificationId  BIGINT IDENTITY(1,1) PRIMARY KEY,
    UserId          UNIQUEIDENTIFIER NOT NULL REFERENCES usr.Users(UserId),
    Type            VARCHAR(30) NOT NULL,  -- PriceDrop|BackInStock|Reminder|NewAlternative
    Title           NVARCHAR(200) NOT NULL,
    Body            NVARCHAR(500) NOT NULL,
    RelatedMedicineId BIGINT NULL REFERENCES med.Medicines(MedicineId),
    IsRead          BIT NOT NULL CONSTRAINT DF_Notif_Read DEFAULT 0,
    CreatedAtUtc    DATETIME2 NOT NULL CONSTRAINT DF_Notif_Created DEFAULT SYSUTCDATETIME()
);
GO

/* =========================================================
   log.AuditLogs  (security requirement)
   ========================================================= */
CREATE TABLE log.AuditLogs (
    AuditLogId    BIGINT IDENTITY(1,1) PRIMARY KEY,
    UserId        UNIQUEIDENTIFIER NULL,
    Action        VARCHAR(100) NOT NULL,
    EntityName    VARCHAR(100) NULL,
    EntityId      NVARCHAR(100) NULL,
    IpAddress     VARCHAR(45) NULL,
    CreatedAtUtc  DATETIME2 NOT NULL CONSTRAINT DF_Audit_Created DEFAULT SYSUTCDATETIME()
);
GO
