using CommunityToolkit.Maui;
using MedCompareIndia.Maui.Services;
using MedCompareIndia.Maui.ViewModels;
using MedCompareIndia.Maui.Views;
using Microsoft.Extensions.Logging;

namespace MedCompareIndia.Maui;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder
            .UseMauiApp<App>()
            .UseMauiCommunityToolkit()
            .ConfigureFonts(fonts =>
            {
                fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
            });

#if DEBUG
        builder.Logging.AddDebug();
#endif

        // ---------- HttpClient / API ----------
        builder.Services.AddHttpClient<ApiService>(client =>
        {
            client.BaseAddress = new Uri(AppConfig.ApiBaseUrl);
            client.Timeout = TimeSpan.FromSeconds(20);
        });

        // ---------- Offline cache ----------
        builder.Services.AddSingleton<LocalCacheService>();

        // ---------- ViewModels (transient: fresh state per navigation) ----------
        builder.Services.AddTransient<LoginViewModel>();
        builder.Services.AddTransient<HomeViewModel>();
        builder.Services.AddTransient<SearchViewModel>();
        builder.Services.AddTransient<MedicineDetailsViewModel>();
        builder.Services.AddTransient<CompareBrandsViewModel>();
        builder.Services.AddTransient<FavoritesViewModel>();
        builder.Services.AddTransient<ProfileViewModel>();

        // ---------- Views ----------
        builder.Services.AddTransient<SplashPage>();
        builder.Services.AddTransient<LoginPage>();
        builder.Services.AddTransient<HomePage>();
        builder.Services.AddTransient<SearchPage>();
        builder.Services.AddTransient<MedicineDetailsPage>();
        builder.Services.AddTransient<CompareBrandsPage>();
        builder.Services.AddTransient<FavoritesPage>();
        builder.Services.AddTransient<ProfilePage>();

        return builder.Build();
    }
}
