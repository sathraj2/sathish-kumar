namespace MedCompareIndia.Maui;

public partial class AppShell : Shell
{
    public AppShell()
    {
        InitializeComponent();

        // Detail/modal routes not present in the tab bar, reached via GoToAsync("MedicineDetails?id=...") etc.
        Routing.RegisterRoute("MedicineDetails", typeof(Views.MedicineDetailsPage));
        Routing.RegisterRoute("CompareBrands", typeof(Views.CompareBrandsPage));
        Routing.RegisterRoute("Search", typeof(Views.SearchPage));
        Routing.RegisterRoute("Login", typeof(Views.LoginPage));
        Routing.RegisterRoute("Home", typeof(Views.HomePage));
    }
}
