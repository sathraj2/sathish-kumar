Add OpenSans-Regular.ttf and OpenSans-Semibold.ttf here (referenced in MauiProgram.cs
ConfigureFonts). Any open-license font works; Google Fonts' Open Sans is a good default
that matches the Material look requested for this app.
