Placeholder folder. Add real PNG icons here for the Shell TabBar:
home.png, search.png, heart.png, profile.png (24x24 @1x/2x/3x recommended),
plus medicine placeholder art (dolo650.png, crocin.png, etc. matching the
ImageUrl values seeded in database/04_SeedData.sql).
