namespace MedCompareIndia.Maui.Services;

public static class AppConfig
{
    // TODO: move to per-environment build configuration (Debug/Staging/Release) before shipping.
    public static string ApiBaseUrl { get; set; } = "https://api.medcompareindia.com/";
}
