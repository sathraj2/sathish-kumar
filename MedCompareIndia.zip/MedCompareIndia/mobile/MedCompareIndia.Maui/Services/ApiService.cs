using System.Net.Http.Json;
using MedCompareIndia.Maui.Models;
using Microsoft.Extensions.Logging;

namespace MedCompareIndia.Maui.Services;

/// <summary>Thin, typed wrapper over HttpClient for all REST calls to the MedCompare API.
/// Centralizes error handling and auth-header attachment so pages/viewmodels stay simple.</summary>
public class ApiService
{
    private readonly HttpClient _http;
    private readonly ILogger<ApiService> _logger;

    public ApiService(HttpClient http, ILogger<ApiService> logger)
    {
        _http = http;
        _http.BaseAddress ??= new Uri(AppConfig.ApiBaseUrl);
        _logger = logger;
    }

    public void SetAuthToken(string? token)
    {
        _http.DefaultRequestHeaders.Authorization = string.IsNullOrEmpty(token)
            ? null
            : new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
    }

    public async Task<PagedResult<MedicineSummary>?> SearchMedicinesAsync(string query, string? searchType = null, int page = 1, CancellationToken ct = default)
    {
        try
        {
            var url = $"api/medicine/search?query={Uri.EscapeDataString(query)}&pageNumber={page}&pageSize=20" +
                       (searchType is null ? "" : $"&searchType={searchType}");
            var res = await _http.GetFromJsonAsync<ApiResponse<PagedResult<MedicineSummary>>>(url, ct);
            return res?.Data;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Search failed for {Query}", query);
            return null; // caller falls back to SQLite cache of recent searches
        }
    }

    public async Task<MedicineDetails?> GetMedicineDetailsAsync(long id, CancellationToken ct = default)
    {
        try
        {
            var res = await _http.GetFromJsonAsync<ApiResponse<MedicineDetails>>($"api/medicine/details/{id}", ct);
            return res?.Data;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "GetDetails failed for {Id}", id);
            return null;
        }
    }

    public async Task<List<BrandComparison>> CompareBrandsAsync(int compositionId, string? strength, string sortBy = "LowestPrice", CancellationToken ct = default)
    {
        try
        {
            var url = $"api/medicine/compare/{compositionId}?sortBy={sortBy}" + (strength is null ? "" : $"&strength={Uri.EscapeDataString(strength)}");
            var res = await _http.GetFromJsonAsync<ApiResponse<CompareBrandsResult>>(url, ct);
            return res?.Data?.Brands ?? new();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Compare failed for composition {Id}", compositionId);
            return new();
        }
    }

    public async Task AddFavoriteAsync(long medicineId, CancellationToken ct = default)
    {
        try { await _http.PostAsync($"api/user/favorites/{medicineId}", null, ct); }
        catch (Exception ex) { _logger.LogError(ex, "AddFavorite failed"); }
    }
}

public class CompareBrandsResult
{
    public string CompositionName { get; set; } = default!;
    public List<BrandComparison> Brands { get; set; } = new();
    public string Disclaimer { get; set; } = default!;
}
