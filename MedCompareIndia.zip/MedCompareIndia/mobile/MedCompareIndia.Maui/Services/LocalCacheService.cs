using MedCompareIndia.Maui.Models;
using SQLite;

namespace MedCompareIndia.Maui.Services;

/// <summary>SQLite-backed offline cache: recent searches + last-viewed medicine details,
/// so the Home/Search screens still show something useful without connectivity.</summary>
public class LocalCacheService
{
    private SQLiteAsyncConnection? _db;

    private async Task<SQLiteAsyncConnection> GetDbAsync()
    {
        if (_db is not null) return _db;

        var path = Path.Combine(FileSystem.AppDataDirectory, "medcompare_cache.db3");
        _db = new SQLiteAsyncConnection(path);
        await _db.CreateTableAsync<CachedSearchTerm>();
        await _db.CreateTableAsync<CachedMedicine>();
        return _db;
    }

    public async Task SaveRecentSearchAsync(string term)
    {
        var db = await GetDbAsync();
        await db.InsertOrReplaceAsync(new CachedSearchTerm { Term = term, SearchedAtUtc = DateTime.UtcNow });
    }

    public async Task<List<string>> GetRecentSearchesAsync(int take = 10)
    {
        var db = await GetDbAsync();
        var rows = await db.Table<CachedSearchTerm>().OrderByDescending(x => x.SearchedAtUtc).Take(take).ToListAsync();
        return rows.Select(r => r.Term).ToList();
    }

    public async Task CacheMedicineAsync(MedicineSummary medicine)
    {
        var db = await GetDbAsync();
        await db.InsertOrReplaceAsync(new CachedMedicine
        {
            MedicineId = medicine.MedicineId,
            BrandName = medicine.BrandName,
            SellingPrice = medicine.SellingPrice,
            ImageUrl = medicine.ImageUrl,
            CachedAtUtc = DateTime.UtcNow
        });
    }

    public async Task<List<CachedMedicine>> GetCachedMedicinesAsync()
    {
        var db = await GetDbAsync();
        return await db.Table<CachedMedicine>().OrderByDescending(x => x.CachedAtUtc).ToListAsync();
    }
}

[Table("RecentSearches")]
public class CachedSearchTerm
{
    [PrimaryKey] public string Term { get; set; } = default!;
    public DateTime SearchedAtUtc { get; set; }
}

[Table("CachedMedicines")]
public class CachedMedicine
{
    [PrimaryKey] public long MedicineId { get; set; }
    public string BrandName { get; set; } = default!;
    public decimal SellingPrice { get; set; }
    public string? ImageUrl { get; set; }
    public DateTime CachedAtUtc { get; set; }
}
