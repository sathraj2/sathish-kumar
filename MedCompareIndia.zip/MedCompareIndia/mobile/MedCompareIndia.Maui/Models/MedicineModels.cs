namespace MedCompareIndia.Maui.Models;

public class MedicineSummary
{
    public long MedicineId { get; set; }
    public string BrandName { get; set; } = default!;
    public string? GenericName { get; set; }
    public string? Strength { get; set; }
    public string? PackSize { get; set; }
    public decimal MRP { get; set; }
    public decimal SellingPrice { get; set; }
    public bool PrescriptionRequired { get; set; }
    public string? ImageUrl { get; set; }
    public string ManufacturerName { get; set; } = default!;
    public string CompositionName { get; set; } = default!;
    public int CompositionId { get; set; }
}

public class MedicineDetails : MedicineSummary
{
    public string? Category { get; set; }
    public string? DosageForm { get; set; }
    public string? StorageInstructions { get; set; }
    public string? Uses { get; set; }
    public string? SideEffects { get; set; }
    public string? Warnings { get; set; }
    public decimal? ManufacturerRating { get; set; }
    public List<OnlinePrice> OnlinePrices { get; set; } = new();
}

public class OnlinePrice
{
    public string Platform { get; set; } = default!;
    public decimal Price { get; set; }
    public bool InStock { get; set; }
    public string? DeepLinkUrl { get; set; }
}

public class BrandComparison
{
    public long MedicineId { get; set; }
    public string BrandName { get; set; } = default!;
    public string ManufacturerName { get; set; } = default!;
    public decimal? ManufacturerRating { get; set; }
    public string? Strength { get; set; }
    public decimal MRP { get; set; }
    public decimal SellingPrice { get; set; }
    public string? ImageUrl { get; set; }
    public decimal PriceDifference { get; set; }
    public decimal SavingsPercent { get; set; }
    public string SavingsBadge { get; set; } = "Low";
    public bool IsCheapestEquivalent { get; set; }
}

public class ApiResponse<T>
{
    public bool Success { get; set; }
    public string? Message { get; set; }
    public T? Data { get; set; }
}

public class PagedResult<T>
{
    public List<T> Items { get; set; } = new();
    public int TotalCount { get; set; }
    public bool HasNextPage { get; set; }
}
