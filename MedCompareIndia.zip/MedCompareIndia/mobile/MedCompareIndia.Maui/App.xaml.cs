namespace MedCompareIndia.Maui;

public partial class App : Application
{
    public App()
    {
        InitializeComponent();

        // Respect saved dark-mode preference (Profile > Settings).
        UserAppTheme = Preferences.Get("IsDarkMode", false) ? AppTheme.Dark : AppTheme.Light;

        MainPage = new AppShell();
    }
}
