using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.Input;
using MedCompareIndia.Maui.Models;
using MedCompareIndia.Maui.Services;

namespace MedCompareIndia.Maui.ViewModels;

public partial class FavoritesViewModel : BaseViewModel
{
    private readonly ApiService _api;

    public ObservableCollection<MedicineSummary> Favorites { get; } = new();

    public FavoritesViewModel(ApiService api) => _api = api;

    [RelayCommand]
    private async Task AppearingAsync()
    {
        IsBusy = true;
        try
        {
            // TODO: back with GET /api/user/favorites (requires auth token attached via ApiService.SetAuthToken)
            Favorites.Clear();
        }
        finally { IsBusy = false; }
    }

    [RelayCommand]
    private async Task OpenDetailsAsync(MedicineSummary medicine)
        => await Shell.Current.GoToAsync($"MedicineDetails?id={medicine.MedicineId}");
}
