using CommunityToolkit.Mvvm.Input;
using MedCompareIndia.Maui.Services;

namespace MedCompareIndia.Maui.ViewModels;

public partial class LoginViewModel : BaseViewModel
{
    private readonly ApiService _api;

    public LoginViewModel(ApiService api) => _api = api;

    [RelayCommand]
    private async Task ContinueAsGuestAsync()
    {
        // TODO: call api/auth/guest, persist token via SecureStorage, then set ApiService auth header.
        await Shell.Current.GoToAsync("//Home");
    }

    [RelayCommand]
    private async Task LoginWithGoogleAsync()
    {
        // TODO: trigger native Google Sign-In, exchange id_token via api/auth/google.
        await Shell.Current.DisplayAlert("Google Login", "Wire native Google Sign-In SDK here.", "OK");
    }

    [RelayCommand]
    private async Task RequestOtpAsync(string mobileNumber)
    {
        // TODO: call api/auth/otp/request, navigate to OTP entry.
        await Task.CompletedTask;
    }
}
