using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using MedCompareIndia.Maui.Models;
using MedCompareIndia.Maui.Services;

namespace MedCompareIndia.Maui.ViewModels;

[QueryProperty(nameof(Query), "query")]
[QueryProperty(nameof(SearchType), "searchType")]
public partial class SearchViewModel : BaseViewModel
{
    private readonly ApiService _api;
    private readonly LocalCacheService _cache;

    [ObservableProperty] private string query = string.Empty;
    [ObservableProperty] private string? searchType; // Name|Brand|Composition|Manufacturer

    public ObservableCollection<MedicineSummary> Results { get; } = new();
    public List<string> SearchTypeOptions { get; } = new() { "Name", "Brand", "Composition", "Manufacturer" };

    public SearchViewModel(ApiService api, LocalCacheService cache)
    {
        _api = api;
        _cache = cache;
    }

    async partial void OnQueryChanged(string value)
    {
        if (!string.IsNullOrWhiteSpace(value))
            await RunSearchAsync();
    }

    [RelayCommand]
    private async Task RunSearchAsync()
    {
        if (string.IsNullOrWhiteSpace(Query)) return;

        IsBusy = true;
        ErrorMessage = null;
        try
        {
            var page = await _api.SearchMedicinesAsync(Query, SearchType);
            Results.Clear();
            if (page is null)
            {
                ErrorMessage = "Couldn't reach the server. Showing offline results may be limited.";
                return;
            }
            foreach (var item in page.Items) Results.Add(item);
            await _cache.SaveRecentSearchAsync(Query);
        }
        finally { IsBusy = false; }
    }

    [RelayCommand]
    private async Task OpenDetailsAsync(MedicineSummary medicine)
        => await Shell.Current.GoToAsync($"MedicineDetails?id={medicine.MedicineId}");
}
