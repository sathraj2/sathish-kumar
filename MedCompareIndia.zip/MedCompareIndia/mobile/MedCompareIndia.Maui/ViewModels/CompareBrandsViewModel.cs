using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using MedCompareIndia.Maui.Models;
using MedCompareIndia.Maui.Services;

namespace MedCompareIndia.Maui.ViewModels;

[QueryProperty(nameof(CompositionId), "compositionId")]
[QueryProperty(nameof(Strength), "strength")]
public partial class CompareBrandsViewModel : BaseViewModel
{
    private readonly ApiService _api;

    [ObservableProperty] private int compositionId;
    [ObservableProperty] private string? strength;
    [ObservableProperty] private string sortBy = "LowestPrice";

    public ObservableCollection<BrandComparison> Brands { get; } = new();

    public const string MedicalDisclaimer =
        "Do not change prescribed medicines without consulting your doctor or pharmacist.";

    public CompareBrandsViewModel(ApiService api) => _api = api;

    async partial void OnCompositionIdChanged(int value) => await LoadAsync();

    [RelayCommand]
    private async Task LoadAsync()
    {
        if (CompositionId == 0) return;
        IsBusy = true;
        try
        {
            var brands = await _api.CompareBrandsAsync(CompositionId, Strength, SortBy);
            Brands.Clear();
            foreach (var b in brands) Brands.Add(b);
        }
        finally { IsBusy = false; }
    }

    [RelayCommand]
    private async Task SortByLowestPriceAsync() { SortBy = "LowestPrice"; await LoadAsync(); }

    [RelayCommand]
    private async Task SortByHighestPriceAsync() { SortBy = "HighestPrice"; await LoadAsync(); }

    [RelayCommand]
    private async Task SortByManufacturerAsync() { SortBy = "Manufacturer"; await LoadAsync(); }

    [RelayCommand]
    private async Task SortByRatingAsync() { SortBy = "Rating"; await LoadAsync(); }
}
