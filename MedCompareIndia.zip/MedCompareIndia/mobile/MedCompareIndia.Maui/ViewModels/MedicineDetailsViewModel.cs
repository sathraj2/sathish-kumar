using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using MedCompareIndia.Maui.Models;
using MedCompareIndia.Maui.Services;

namespace MedCompareIndia.Maui.ViewModels;

[QueryProperty(nameof(MedicineId), "id")]
public partial class MedicineDetailsViewModel : BaseViewModel
{
    private readonly ApiService _api;
    private readonly LocalCacheService _cache;

    [ObservableProperty] private long medicineId;
    [ObservableProperty] private MedicineDetails? medicine;

    public MedicineDetailsViewModel(ApiService api, LocalCacheService cache)
    {
        _api = api;
        _cache = cache;
    }

    async partial void OnMedicineIdChanged(long value) => await LoadAsync();

    private async Task LoadAsync()
    {
        IsBusy = true;
        try
        {
            Medicine = await _api.GetMedicineDetailsAsync(MedicineId);
        }
        finally { IsBusy = false; }
    }

    [RelayCommand]
    private async Task CompareBrandsAsync()
    {
        if (Medicine is null) return;
        await Shell.Current.GoToAsync(
            $"CompareBrands?compositionId={Medicine.CompositionId}&strength={Uri.EscapeDataString(Medicine.Strength ?? "")}");
    }

    [RelayCommand]
    private async Task AddToFavoritesAsync()
    {
        if (Medicine is null) return;
        await _api.AddFavoriteAsync(Medicine.MedicineId);
        await Shell.Current.DisplayAlert("Saved", $"{Medicine.BrandName} added to favorites.", "OK");
    }
}
