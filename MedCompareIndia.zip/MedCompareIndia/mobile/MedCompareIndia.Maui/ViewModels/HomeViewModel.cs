using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.Input;
using MedCompareIndia.Maui.Models;
using MedCompareIndia.Maui.Services;

namespace MedCompareIndia.Maui.ViewModels;

public partial class HomeViewModel : BaseViewModel
{
    private readonly ApiService _api;
    private readonly LocalCacheService _cache;

    public ObservableCollection<string> RecentSearches { get; } = new();
    public ObservableCollection<MedicineSummary> PopularMedicines { get; } = new();
    public ObservableCollection<string> Categories { get; } = new()
    {
        "Fever/Pain", "Blood Pressure", "Diabetes", "Cholesterol", "Antibiotics", "Vitamins"
    };

    public HomeViewModel(ApiService api, LocalCacheService cache)
    {
        _api = api;
        _cache = cache;
    }

    [RelayCommand]
    private async Task AppearingAsync()
    {
        IsBusy = true;
        try
        {
            var recents = await _cache.GetRecentSearchesAsync();
            RecentSearches.Clear();
            foreach (var r in recents) RecentSearches.Add(r);

            // "Popular medicines" — in production, back this with a dedicated /api/medicine/popular
            // endpoint driven by the analytics dashboard's "most searched" data.
            var popular = await _api.SearchMedicinesAsync("Paracetamol");
            PopularMedicines.Clear();
            foreach (var m in popular?.Items ?? new()) PopularMedicines.Add(m);
        }
        finally { IsBusy = false; }
    }

    [RelayCommand]
    private async Task GoToSearchAsync(string? prefillQuery)
        => await Shell.Current.GoToAsync($"Search?query={Uri.EscapeDataString(prefillQuery ?? string.Empty)}");

    [RelayCommand]
    private async Task GoToCategoryAsync(string category)
        => await Shell.Current.GoToAsync($"Search?query={Uri.EscapeDataString(category)}&searchType=Category");
}
