using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

namespace MedCompareIndia.Maui.ViewModels;

public partial class ProfileViewModel : BaseViewModel
{
    [ObservableProperty] private bool isDarkModeEnabled = Preferences.Get("IsDarkMode", false);
    [ObservableProperty] private string selectedLanguage = Preferences.Get("Language", "English");

    public List<string> Languages { get; } = new() { "English", "Tamil", "Hindi", "Telugu", "Malayalam", "Kannada" };

    partial void OnIsDarkModeEnabledChanged(bool value)
    {
        Preferences.Set("IsDarkMode", value);
        Application.Current!.UserAppTheme = value ? AppTheme.Dark : AppTheme.Light;
    }

    partial void OnSelectedLanguageChanged(string value)
    {
        Preferences.Set("Language", value);
        // TODO: swap .resx resource culture / restart localization context (see docs/ARCHITECTURE.md > Localization)
    }

    [RelayCommand]
    private async Task LogoutAsync()
    {
        Preferences.Remove("AuthToken");
        await Shell.Current.GoToAsync("//Login");
    }
}
