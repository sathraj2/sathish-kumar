using MedCompareIndia.Maui.ViewModels;

namespace MedCompareIndia.Maui.Views;

public partial class FavoritesPage : ContentPage
{
    private readonly FavoritesViewModel _vm;

    public FavoritesPage(FavoritesViewModel vm)
    {
        InitializeComponent();
        BindingContext = _vm = vm;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        if (_vm.AppearingCommand.CanExecute(null))
            await _vm.AppearingCommand.ExecuteAsync(null);
    }
}
