using MedCompareIndia.Maui.ViewModels;

namespace MedCompareIndia.Maui.Views;

public partial class MedicineDetailsPage : ContentPage
{
    public MedicineDetailsPage(MedicineDetailsViewModel vm)
    {
        InitializeComponent();
        BindingContext = vm;
    }
}
