using MedCompareIndia.Maui.ViewModels;

namespace MedCompareIndia.Maui.Views;

public partial class CompareBrandsPage : ContentPage
{
    public CompareBrandsPage(CompareBrandsViewModel vm)
    {
        InitializeComponent();
        BindingContext = vm;
    }
}
