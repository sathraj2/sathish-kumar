using MedCompareIndia.Maui.ViewModels;

namespace MedCompareIndia.Maui.Views;

public partial class HomePage : ContentPage
{
    private readonly HomeViewModel _vm;

    public HomePage(HomeViewModel vm)
    {
        InitializeComponent();
        BindingContext = _vm = vm;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        if (_vm.AppearingCommand.CanExecute(null))
            await _vm.AppearingCommand.ExecuteAsync(null);
    }
}
