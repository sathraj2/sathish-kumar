using MedCompareIndia.Maui.ViewModels;

namespace MedCompareIndia.Maui.Views;

public partial class LoginPage : ContentPage
{
    public LoginPage(LoginViewModel vm)
    {
        InitializeComponent();
        BindingContext = vm;
    }
}
