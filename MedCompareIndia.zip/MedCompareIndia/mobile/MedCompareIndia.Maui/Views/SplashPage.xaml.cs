namespace MedCompareIndia.Maui.Views;

public partial class SplashPage : ContentPage
{
    public SplashPage()
    {
        InitializeComponent();
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await Task.Delay(1200); // brand moment; replace with real init (token refresh, cache warm-up)
        var isLoggedIn = Preferences.Get("AuthToken", null) is not null;
        await Shell.Current.GoToAsync(isLoggedIn ? "//Home" : "//Login");
    }
}
