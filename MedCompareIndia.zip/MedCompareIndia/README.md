# MedCompare India

A cross-platform (.NET MAUI) medicine price comparison app for India, with an
ASP.NET Core backend, SQL Server database, and a Clean Architecture backend.

> **Scope note:** This is a genuinely large product (mobile app + API + admin
> portal + AI + analytics + Elasticsearch/Redis + OCR/barcode). A single
> generated deliverable can't responsibly contain a compiled, fully-tested
> version of all 18 feature groups — that's several person-months of work.
> What's included here is a **working, production-grade skeleton** that is
> architecturally complete (Clean Architecture, repository pattern, DI, real
> DB schema, real EF Core entities, real controllers/services, real MAUI
> MVVM pages for the core user journey) so a team can build every remaining
> feature on solid rails instead of starting from zero. Each stubbed area is
> clearly marked `TODO` with a description of what to implement next.

## What's fully implemented (compiles conceptually, real code, not pseudocode)

- SQL Server schema: `database/*.sql` — all core tables, indexes, seed data, stored procs
- Domain entities: `backend/src/MedCompare.Domain`
- DTOs + interfaces: `backend/src/MedCompare.Application`
- EF Core DbContext + Repository pattern + Redis cache decorator: `backend/src/MedCompare.Infrastructure`
- Web API with Swagger, JWT auth, rate limiting, global exception middleware:
  `backend/src/MedCompare.API`
  - `POST /api/auth/otp/request`, `POST /api/auth/otp/verify`, `POST /api/auth/google`
  - `GET  /api/medicine/search`
  - `GET  /api/medicine/details/{id}`
  - `GET  /api/medicine/compare/{compositionId}`
  - `GET  /api/pharmacy/nearby`
  - `GET/POST/DELETE /api/user/favorites`
  - `GET  /api/user/history`
- Unit tests (xUnit + Moq + FluentAssertions): `backend/src/MedCompare.Tests`
- MAUI app: `mobile/MedCompareIndia.Maui`
  - Splash → Login (Google / OTP / Guest) → Shell tabs (Home, Search, Favorites, Profile)
  - Home, Search, MedicineDetails, CompareBrands pages + ViewModels (CommunityToolkit.Mvvm)
  - SQLite offline cache service, REST `ApiService`, DI in `MauiProgram.cs`
  - Green Material theme (`Resources/Styles/Colors.xaml`, `Styles.xaml`), Dark Mode support

## What's stubbed with clear extension points (`TODO` + interface already defined)

- Nearby pharmacy live stock feed, click-to-call (interface + UI ready, needs partner API)
- Online marketplace price scraping/partner APIs (1mg, Apollo, PharmEasy, Netmeds) — `IOnlinePriceProvider`
- AI Medicine Assistant / AI Search (NL→SQL) — `IAiAssistantService` stub, designed to call Claude via Anthropic API
- OCR prescription/barcode scanner — `IOcrService` stub (ML Kit / Azure Vision ready hook)
- Admin portal (Blazor/React) — API is admin-ready (role claims), UI not scaffolded
- Elasticsearch search — repository is written against `IMedicineSearchIndex` so Elasticsearch
  can be swapped in for the current SQL full-text/index-based search without touching callers
- Push notifications (reminders, price drops) — `INotificationService` stub + local MAUI notification wiring
- Localization (ta/hi/te/ml/kn) — `.resx` structure created for `en` + `hi`, others follow same pattern

## Solution layout

```
MedCompareIndia/
├── database/                     SQL Server DDL, indexes, seed data, stored procs
├── docs/                         Architecture, API contract, DB schema docs
├── backend/src/
│   ├── MedCompare.Domain/        Entities, enums — no dependencies
│   ├── MedCompare.Application/   DTOs, service interfaces, business logic
│   ├── MedCompare.Infrastructure/EF Core, repositories, Redis, external services
│   ├── MedCompare.API/           Controllers, Program.cs, middleware, Swagger
│   └── MedCompare.Tests/         xUnit tests
└── mobile/MedCompareIndia.Maui/  .NET MAUI 9 app (MVVM)
```

## Running locally

**Backend**
```bash
cd backend/src/MedCompare.API
dotnet ef database update            # applies migrations to SQL Server
dotnet run                            # Swagger at /swagger
```
Configure `appsettings.Development.json` with your SQL Server connection string,
Redis connection string, and JWT signing key (see `docs/ARCHITECTURE.md`).

**Mobile**
```bash
cd mobile/MedCompareIndia.Maui
dotnet build -t:Run -f net9.0-android    # or net9.0-ios, net9.0-maccatalyst
```
Set `ApiBaseUrl` in `Services/AppConfig.cs`.

## Suggested build order for a team

1. Ship database + API for search/details/compare/favorites/history (this repo covers it)
2. Ship MAUI MVP: splash → login → home → search → compare → details → favorites
3. Add nearby pharmacy (Google Maps) + reminders + notifications
4. Add AI Assistant + AI Search (natural language → structured query)
5. Add OCR/barcode scanning
6. Add admin portal + analytics dashboard
7. Swap SQL search for Elasticsearch, add Redis caching at scale, add read replicas
8. Localization rollout, accessibility pass, security/audit hardening
