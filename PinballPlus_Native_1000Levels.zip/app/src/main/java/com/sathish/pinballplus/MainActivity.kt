package com.sathish.pinballplus
import android.app.Activity
import android.os.Bundle
class MainActivity: Activity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);window.setFlags(1024,1024);setContentView(GameView(this))}
 override fun onBackPressed(){if((window.decorView as? GameView)?.goBack()!=true)super.onBackPressed()}
}
