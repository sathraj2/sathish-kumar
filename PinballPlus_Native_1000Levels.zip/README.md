# Pinball Plus Native Android
Fresh Kotlin Android project. Package: `com.sathish.pinballplus`.

Includes animated drawn splash, colorful landing page, level select with locked/unlocked levels, 1000 levels, procedural visual variation, per-level high scores, music/sound/vibration switches, touch flippers and smooth custom Canvas physics.

Build with Android Studio or:
`./gradlew :app:assembleDebug`
