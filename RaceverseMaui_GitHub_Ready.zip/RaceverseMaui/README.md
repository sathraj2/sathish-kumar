# RACEVERSE — .NET MAUI Android Racing Prototype

A GitHub-ready .NET MAUI prototype for a cinematic mobile racing screen. It uses `GraphicsView` to draw the track, city, cars, road effects and HUD-friendly race state without external packages.

## What works
- 9-car race presentation
- animated road perspective
- player car movement with touch steering
- acceleration/brake
- nitro acceleration and effects
- speed, lap and position state
- AI coach messages
- dynamic opponent cars
- phone-friendly controls

## Run locally
Install .NET 9 SDK and the MAUI Android workload:

```bash
dotnet workload install maui-android
git clone <your-repo-url>
cd RaceverseMaui
dotnet restore
dotnet build -f net9.0-android
```

Install/run on a connected Android device:

```bash
dotnet build -f net9.0-android -t:Run
```

Build an APK:

```bash
dotnet publish -f net9.0-android -c Release -p:AndroidPackageFormat=apk
```

The APK is normally under `RaceverseMaui/bin/Release/net9.0-android/publish/`.

## GitHub Actions
A workflow is included under `.github/workflows/android.yml`. Push this repository to GitHub and the workflow will build the Android project and upload the APK as a workflow artifact.

## Next production step
Replace the procedural `GraphicsView` racing scene with a Unity/3D renderer when you want full 3D car meshes, physics, camera systems, detailed tracks, shadows and multiplayer race synchronization. Keep this MAUI project for account/profile/garage/shop/missions screens and connect the two layers through your backend.
