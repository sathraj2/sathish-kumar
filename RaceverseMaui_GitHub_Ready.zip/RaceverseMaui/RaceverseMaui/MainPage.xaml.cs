using RaceverseMaui.Graphics;

namespace RaceverseMaui;

public partial class MainPage : ContentPage
{
    private readonly RaceEngine _engine = new();
    private readonly RaceDrawable _drawable;
    private bool _running;
    private bool _left, _right, _accel, _brake, _nitro;

    public MainPage()
    {
        InitializeComponent();
        _drawable = new RaceDrawable(_engine);
        RaceView.Drawable = _drawable;
        RaceView.StartInteraction += (_, _) => { };
        Device.StartTimer(TimeSpan.FromMilliseconds(16), Tick);
    }

    private bool Tick()
    {
        if (_running)
        {
            _engine.Update(_left, _right, _accel, _brake, _nitro);
            SpeedLabel.Text = ((int)_engine.Speed).ToString();
            PositionLabel.Text = $"{_engine.Position} / 9";
            LapLabel.Text = $"{_engine.Lap} / 3";
            CoachLabel.Text = _engine.CoachMessage;
            RaceView.Invalidate();
        }
        return true;
    }

    private void OnStartClicked(object sender, EventArgs e)
    {
        _running = true;
        StartButton.IsVisible = false;
        _engine.Start();
        CoachLabel.Text = "3… 2… 1… GO! Use nitro on the straight.";
    }

    private void OnLeftPressed(object sender, EventArgs e) => _left = true;
    private void OnRightPressed(object sender, EventArgs e) => _right = true;
    private void OnAccelPressed(object sender, EventArgs e) => _accel = true;
    private void OnBrakePressed(object sender, EventArgs e) => _brake = true;
    private void OnNitroPressed(object sender, EventArgs e) => _nitro = true;

    private void OnControlReleased(object sender, EventArgs e)
    {
        _left = _right = _accel = _brake = _nitro = false;
    }
}
