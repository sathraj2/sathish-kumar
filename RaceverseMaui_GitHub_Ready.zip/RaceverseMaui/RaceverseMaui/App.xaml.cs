namespace RaceverseMaui;

public partial class App : Application
{
    public App()
    {
        InitializeComponent();
        MainPage = new NavigationPage(new MainPage())
        {
            BarBackgroundColor = Color.FromArgb("#080A0F"),
            BarTextColor = Colors.White
        };
    }
}
