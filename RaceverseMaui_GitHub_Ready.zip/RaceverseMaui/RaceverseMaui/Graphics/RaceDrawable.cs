using Microsoft.Maui.Graphics;

namespace RaceverseMaui.Graphics;

public sealed class RaceDrawable : IDrawable
{
    private readonly RaceEngine _e;
    public RaceDrawable(RaceEngine engine) => _e = engine;

    public void Draw(ICanvas c, RectF r)
    {
        var w = r.Width; var h = r.Height;
        c.FillColor = Color.FromArgb("#07101A"); c.FillRectangle(r);
        DrawSky(c, w, h);
        DrawCity(c, w, h);
        DrawRoad(c, w, h);
        DrawOpponents(c, w, h);
        DrawPlayer(c, w, h);
        if (_e.NitroActive) DrawNitro(c, w, h);
        DrawRoadFx(c, w, h);
    }

    private void DrawSky(ICanvas c, float w, float h)
    {
        c.FillColor = Color.FromArgb("#0B1630"); c.FillRectangle(0, 0, w, h * .55f);
        c.FillColor = Color.FromArgb("#233B5A"); c.FillCircle(w * .82f, h * .18f, 42);
        c.FillColor = Color.FromArgb("#FFFFFF"); c.Alpha = .65f;
        for (int i = 0; i < 40; i++) c.FillCircle((i * 97) % w, (i * 53) % (h * .45f), i % 3 == 0 ? 1.4f : .8f);
        c.Alpha = 1;
    }

    private void DrawCity(ICanvas c, float w, float h)
    {
        var baseY = h * .49f;
        for (int i = 0; i < 18; i++)
        {
            float bw = 22 + (i % 4) * 11, bh = 45 + (i * 29) % 105, x = (i * 67) % (int)w;
            c.FillColor = Color.FromArgb(i % 2 == 0 ? "#152238" : "#101A2C"); c.FillRectangle(x, baseY - bh, bw, bh);
            c.FillColor = Color.FromArgb("#5EE7FF"); c.Alpha = .45f;
            for (int y = (int)(baseY - bh + 8); y < baseY - 5; y += 14) c.FillRectangle(x + 5, y, 3, 5);
            c.Alpha = 1;
        }
        c.FillColor = Color.FromArgb("#0C1D2A"); c.FillRectangle(0, baseY, w, h - baseY);
    }

    private void DrawRoad(ICanvas c, float w, float h)
    {
        var horizon = h * .49f;
        var bottom = h;
        PathF road = new();
        road.MoveTo(w * .48f, horizon); road.LineTo(w * .52f, horizon); road.LineTo(w * .94f, bottom); road.LineTo(w * .06f, bottom); road.Close();
        c.FillColor = Color.FromArgb("#1B2028"); c.FillPath(road);
        c.StrokeColor = Color.FromArgb("#F7C95C"); c.StrokeSize = 4; c.DrawLine(w*.48f,horizon,w*.06f,bottom); c.DrawLine(w*.52f,horizon,w*.94f,bottom);
        c.StrokeColor = Color.FromArgb("#EDEFF4"); c.StrokeSize = 5;
        for (int i = 0; i < 10; i++)
        {
            var t = ((i / 10f + _e.RoadScroll * 2f) % 1f);
            var y = horizon + MathF.Pow(t, 1.65f) * (bottom - horizon);
            var half = 3 + t * w * .08f;
            var dash = 8 + t * 26;
            c.DrawLine(w/2 - half, y, w/2 + half, y + dash);
        }
        c.FillColor = Color.FromArgb("#4D9DFF"); c.Alpha = .12f; c.FillRectangle(0,h*.63f,w,h*.37f); c.Alpha=1;
    }

    private void DrawOpponents(ICanvas c, float w, float h)
    {
        for (int i = 0; i < 8; i++)
        {
            var d = _e.OpponentDepth(i); var y = h*.49f + d*d*(h*.38f); var scale = .25f + d*.72f;
            var x = w/2 + _e.OpponentOffset(i) * w*.24f * d;
            DrawCar(c, x, y, scale, i % 3 == 0 ? "#35D08A" : i % 3 == 1 ? "#F0B43C" : "#6AA8FF", false);
        }
    }

    private void DrawPlayer(ICanvas c, float w, float h)
    {
        var x = w/2 + _e.PlayerX*w*.18f; var y = h*.82f;
        DrawCar(c,x,y,1.35f,"#E62F38",true);
    }

    private void DrawCar(ICanvas c,float x,float y,float s,string color,bool player)
    {
        var cw=95*s,ch=45*s;
        c.FillColor=Color.FromArgb("#000000"); c.Alpha=.35f; c.FillEllipse(x-cw*.62f,y-ch*.08f,cw*1.24f,ch*.45f); c.Alpha=1;
        PathF body=new(); body.MoveTo(x-cw*.55f,y); body.LineTo(x-cw*.36f,y-ch*.55f); body.LineTo(x+cw*.32f,y-ch*.55f); body.LineTo(x+cw*.55f,y); body.LineTo(x+cw*.45f,y+ch*.3f); body.LineTo(x-cw*.45f,y+ch*.3f); body.Close();
        c.FillColor=Color.FromArgb(color); c.FillPath(body);
        c.FillColor=Color.FromArgb("#10141C"); c.FillRoundedRectangle(x-cw*.22f,y-ch*.46f,cw*.44f,ch*.27f,6);
        c.FillColor=Color.FromArgb("#EAF7FF"); c.Alpha=.9f; c.FillRoundedRectangle(x-cw*.42f,y+ch*.03f,cw*.13f,ch*.08f,3); c.FillRoundedRectangle(x+cw*.29f,y+ch*.03f,cw*.13f,ch*.08f,3); c.Alpha=1;
        if(player){ c.StrokeColor=Color.FromArgb("#FF6B70"); c.StrokeSize=2; c.DrawRoundedRectangle(x-cw*.58f,y-ch*.03f,cw*1.16f,ch*.34f,8); }
    }

    private void DrawNitro(ICanvas c,float w,float h)
    {
        c.FillColor=Color.FromArgb("#2FA8FF"); c.Alpha=.35f;
        c.FillEllipse(w*.42f,h*.87f,w*.08f,h*.18f); c.FillEllipse(w*.51f,h*.87f,w*.08f,h*.18f); c.Alpha=1;
    }

    private void DrawRoadFx(ICanvas c,float w,float h)
    {
        c.StrokeColor=Color.FromArgb("#FFFFFF"); c.Alpha=.16f; c.StrokeSize=2;
        for(int i=0;i<16;i++){ var x=(i*83+_e.RoadScroll*900)%w; var y=h*.55f+((i*37)%100)/100f*h*.4f; c.DrawLine(x,y,x-10,y+35); }
        c.Alpha=1;
    }
}
