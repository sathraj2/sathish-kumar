namespace RaceverseMaui.Graphics;

public sealed class RaceEngine
{
    public float Speed { get; private set; }
    public int Position { get; private set; } = 6;
    public int Lap { get; private set; } = 1;
    public float PlayerX { get; private set; }
    public float RoadScroll { get; private set; }
    public bool NitroActive { get; private set; }
    public string CoachMessage { get; private set; } = "Nice start! Keep to the right — sharp turn ahead.";
    private float _progress;
    private float _opponentPhase;
    private readonly Random _random = new(7);

    public void Start() { Speed = 0; Position = 6; Lap = 1; _progress = 0; PlayerX = 0; }

    public void Update(bool left, bool right, bool accel, bool brake, bool nitro)
    {
        NitroActive = nitro && Speed > 100;
        var target = accel ? 235f : 95f;
        if (brake) target = 45f;
        if (NitroActive) target = 315f;
        Speed += (target - Speed) * 0.035f;
        if (!accel && !brake) Speed *= 0.998f;
        var steer = (right ? 1 : 0) - (left ? 1 : 0);
        PlayerX = Math.Clamp(PlayerX + steer * 0.022f, -0.72f, 0.72f);
        RoadScroll += Speed / 3600f;
        _progress += Speed / 360000f;
        _opponentPhase += 0.014f;
        if (_progress >= 1f) { _progress = 0; Lap++; if (Lap > 3) Lap = 1; }
        var pressure = MathF.Sin(_opponentPhase) + MathF.Sin(_opponentPhase * .43f);
        Position = Math.Clamp(6 - (int)MathF.Round(pressure * 1.4f) - (NitroActive ? 1 : 0), 1, 9);
        CoachMessage = Speed > 280 ? "NITRO! Great speed — brake before the next corner." :
                       Math.Abs(PlayerX) > .58f ? "Easy! Bring the car back toward the racing line." :
                       Speed < 80 ? "Accelerate smoothly. Build speed before the straight." :
                       "Good pace! Slipstream the car ahead, then overtake.";
    }

    public float OpponentOffset(int index) => MathF.Sin(_opponentPhase * (0.7f + index * .09f) + index) * .55f;
    public float OpponentDepth(int index) => 0.2f + ((index * 0.13f + _progress * (0.8f + index * .05f)) % 1f) * .65f;
}
