# Smart AI Meeting

Kotlin + Jetpack Compose Android starter project.

## Included
- Speech capture through Android's speech-recognition UI.
- Editable meeting transcript and paste support.
- AI-suggested concise professional spoken replies using the OpenAI Responses API.
- Copy reply action and settings for an API key.
- Meeting prompt context for software engineering, .NET MAUI/Xamarin, C#, APIs, Warehouse, SAPA/RAPA and Scrum.
- GitHub Actions workflow that builds a debug APK and uploads it as an artifact.

## Build
Requires JDK 17, Android SDK 35 and Gradle 8.9:

```bash
gradle assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`.

## GitHub Actions
Push to `main`, or run **Build Android APK** manually from the Actions tab. Download the `Smart-AI-Meeting-debug-apk` artifact after a successful run.

## Important
- This is a starter MVP; it has not been compiled or device-tested in this environment.
- Enter an OpenAI API key in app Settings. ChatGPT subscription login is not reused; API usage is billed separately.
- The key is stored in app-private preferences. For production/shared use, proxy API calls through a secured backend instead of embedding a shared key in an APK.
- Android speech recognition depends on the device's speech service and language support. This app does not silently capture Teams/Zoom internal audio. Get meeting participants' consent before transcribing.
