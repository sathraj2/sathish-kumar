package com.sathraj.smartmeeting

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { MeetingScreen() } }
}

private val http = OkHttpClient.Builder().callTimeout(45, TimeUnit.SECONDS).build()

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MeetingScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("meeting_settings", 0) }
    var apiKey by remember { mutableStateOf(prefs.getString("api_key", "") ?: "") }
    var transcript by remember { mutableStateOf("") }
    var reply by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Ready") }
    var loading by remember { mutableStateOf(false) }
    var settings by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let {
            transcript = listOf(transcript, it).filter(String::isNotBlank).joinToString("\n")
            status = "Speech captured"
        }
    }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) launchSpeech(speech) else status = "Microphone permission denied"
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF9B8CFF), background = Color(0xFF101116), surface = Color(0xFF1B1D25))) {
        Scaffold(topBar = { TopAppBar(title = { Column { Text("Smart AI Meeting", fontWeight = FontWeight.Bold); Text("Live meeting assistant", style = MaterialTheme.typography.labelSmall) } }, actions = { IconButton(onClick = { settings = true }) { Icon(Icons.Default.Settings, "Settings") } }) }, containerColor = MaterialTheme.colorScheme.background) { pad ->
            Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("MEETING TRANSCRIPT", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
                    OutlinedTextField(transcript, { transcript = it }, Modifier.fillMaxWidth().heightIn(min = 150.dp), placeholder = { Text("Capture speech or paste meeting notes…") })
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) launchSpeech(speech) else permission.launch(Manifest.permission.RECORD_AUDIO) }) { Icon(Icons.Default.Mic, null); Spacer(Modifier.width(6.dp)); Text("Capture speech") }
                        OutlinedButton(onClick = { transcript = ""; reply = ""; status = "Cleared" }) { Text("Clear") }
                    }
                    Text("Uses your device speech service. Obtain participants’ consent before transcribing meetings.", style = MaterialTheme.typography.bodySmall)
                } }
                Card { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("SUGGESTED RESPONSE", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
                    Text(reply.ifBlank { "Your suggested spoken reply will appear here." })
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(enabled = !loading && transcript.isNotBlank() && apiKey.isNotBlank(), onClick = { scope.launch { loading = true; status = "Generating…"; try { reply = createReply(apiKey, transcript); status = "Reply ready" } catch (e: Exception) { status = "Error: ${e.message ?: "Request failed"}" } finally { loading = false } } }) { Text(if (loading) "Working…" else "Generate reply") }
                        OutlinedButton(enabled = reply.isNotBlank(), onClick = { clipboard.setText(androidx.compose.ui.text.AnnotatedString(reply)); status = "Copied" }) { Icon(Icons.Default.ContentCopy, null); Spacer(Modifier.width(5.dp)); Text("Copy") }
                    }
                } }
                Card { Column(Modifier.padding(16.dp)) { Text("WORK CONTEXT", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium); Text("Software engineering • .NET MAUI / Xamarin • C# • APIs • Warehouse inbound/outbound • SAPA/RAPA • Scrum") } }
                Text(status, style = MaterialTheme.typography.labelMedium)
            }
        }
        if (settings) AlertDialog(onDismissRequest = { settings = false }, title = { Text("OpenAI API settings") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { Text("An OpenAI API key is required. API billing is separate from your ChatGPT subscription."); OutlinedTextField(apiKey, { apiKey = it }, label = { Text("API key") }, singleLine = true) } }, confirmButton = { TextButton(onClick = { prefs.edit().putString("api_key", apiKey.trim()).apply(); settings = false; status = "API key saved on this device" }) { Text("Save") } }, dismissButton = { TextButton(onClick = { settings = false }) { Text("Cancel") } })
    }
}

private fun launchSpeech(launcher: androidx.activity.result.ActivityResultLauncher<Intent>) {
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply { putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault()); putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak clearly") }
    launcher.launch(intent)
}

private suspend fun createReply(key: String, transcript: String): String = withContext(Dispatchers.IO) {
    val body = JSONObject().apply {
        put("model", "gpt-4.1-mini")
        put("instructions", "You are a concise professional meeting assistant. Suggest a natural spoken reply in clear simple English. Use relevant software engineering context: .NET MAUI, Xamarin, C#, APIs, warehouse workflows, SAPA/RAPA and Scrum. Never invent progress, approvals or commitments. If details are missing, ask one short question. Return only the suggested reply.")
        put("input", transcript)
        put("max_output_tokens", 220)
    }
    val request = Request.Builder().url("https://api.openai.com/v1/responses").addHeader("Authorization", "Bearer $key").addHeader("Content-Type", "application/json").post(body.toString().toRequestBody("application/json".toMediaType())).build()
    http.newCall(request).execute().use { response ->
        val raw = response.body?.string().orEmpty()
        if (!response.isSuccessful) { val msg = try { JSONObject(raw).optJSONObject("error")?.optString("message") } catch (_: Exception) { null }; throw IllegalStateException(msg?.takeIf { it.isNotBlank() } ?: "HTTP ${response.code}") }
        val output = JSONObject(raw).optJSONArray("output") ?: JSONArray()
        buildList { for (i in 0 until output.length()) { val content = output.optJSONObject(i)?.optJSONArray("content") ?: continue; for (j in 0 until content.length()) { val item = content.optJSONObject(j) ?: continue; if (item.optString("type") == "output_text") add(item.optString("text")) } } }.joinToString("\n").ifBlank { "No reply returned. Please try again." }
    }
}
