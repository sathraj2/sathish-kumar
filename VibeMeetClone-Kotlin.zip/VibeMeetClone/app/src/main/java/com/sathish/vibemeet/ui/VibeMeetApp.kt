package com.sathish.vibemeet.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

private val Accent = Color(0xFF6C4DFF)
private val Pink = Color(0xFFFF4F91)
private val Bg = Color(0xFFF8F7FC)

private data class Item(val title: String, val icon: String, val route: String)
private val games = listOf(
    Item("Lucky Wheel", "🎡", "game/wheel"), Item("Lucky Number", "🔢", "game/number"),
    Item("Bucket Lucky", "🪣", "game/bucket"), Item("Race", "🏎️", "game/race"),
    Item("Top Battle", "⚔️", "game/battle"), Item("Apple Master", "🍎", "game/apple")
)

@Composable fun VibeMeetApp() {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = "home") {
        composable("home") { Shell(nav, "Home") { Home(nav) } }
        composable("live") { Shell(nav, "Live") { Live(nav) } }
        composable("party") { Shell(nav, "Party") { Party(nav) } }
        composable("discover") { Shell(nav, "Discover") { Discover(nav) } }
        composable("messages") { Shell(nav, "Messages") { Messages(nav) } }
        composable("profile") { Shell(nav, "Profile") { Profile(nav) } }
        composable("liveRoom") { FullPage(nav, "Live Room") { LiveRoom(nav) } }
        composable("call") { FullPage(nav, "Video Call") { Call(nav) } }
        composable("partyRoom") { FullPage(nav, "Party Room") { PartyRoom(nav) } }
        composable("match") { FullPage(nav, "Quick Match") { Match(nav) } }
        composable("groups") { FullPage(nav, "Groups & Families") { Groups(nav) } }
        composable("moments") { FullPage(nav, "Moments") { Moments(nav) } }
        composable("gifts") { FullPage(nav, "Gifts") { Gifts(nav) } }
        composable("wallet") { FullPage(nav, "Wallet") { Wallet(nav) } }
        composable("backpack") { FullPage(nav, "Backpack") { Backpack(nav) } }
        composable("tasks") { FullPage(nav, "Tasks") { Tasks(nav) } }
        composable("ranks") { FullPage(nav, "Rankings") { Ranks(nav) } }
        composable("settings") { FullPage(nav, "Settings") { Settings(nav) } }
        composable("games") { FullPage(nav, "Game Center") { GameCenter(nav) } }
        games.forEach { g -> composable(g.route) { FullPage(nav, g.title) { Game(nav, g) } } }
    }
}

@Composable private fun Shell(nav: NavHostController, title: String, body: @Composable () -> Unit) {
    Scaffold(containerColor = Bg, bottomBar = { BottomBar(nav) }) { p -> Box(Modifier.padding(p)) { body() } }
}
@Composable private fun FullPage(nav: NavHostController, title: String, body: @Composable () -> Unit) {
    Scaffold(containerColor = Bg, topBar = { TopAppBar(title = { Text(title, fontWeight = FontWeight.Bold) }, navigationIcon = { IconButton({nav.popBackStack()}) { Icon(Icons.Default.ArrowBack, null) } }) }) { p -> Box(Modifier.padding(p)) { body() } }
}

@Composable private fun BottomBar(nav: NavHostController) {
    NavigationBar(containerColor = Color.White) {
        listOf("home" to Icons.Default.Home, "live" to Icons.Default.Videocam, "party" to Icons.Default.Groups, "discover" to Icons.Default.Explore, "messages" to Icons.Default.Chat, "profile" to Icons.Default.Person).forEach { (r,i) ->
            NavigationBarItem(selected = false, onClick = { nav.navigate(r) }, icon = { Icon(i, null) }, label = { Text(r.replaceFirstChar { it.uppercase() }) })
        }
    }
}

@Composable private fun Header(title: String, subtitle: String? = null) { Column(Modifier.padding(16.dp)) { Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); subtitle?.let { Text(it, color = Color.Gray) } } }
@Composable private fun Section(title: String, action: String? = null, onAction: (() -> Unit)? = null) { Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) { Text(title, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); if (action != null) Text(action, color = Accent, modifier = Modifier.clickable { onAction?.invoke() }) } }
@Composable private fun Avatar(text: String, size: Int = 56) { Box(Modifier.size(size.dp).clip(CircleShape).background(Color(0xFFE7E0FF)), Alignment.Center) { Text(text, style = MaterialTheme.typography.titleLarge) } }
@Composable private fun UserCard(name: String, online: Boolean = true, onClick: (() -> Unit)? = null) { Card(Modifier.padding(6.dp).width(120.dp).clickable { onClick?.invoke() }, shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) { Avatar(name.take(1)); Spacer(Modifier.height(6.dp)); Text(name, fontWeight = FontWeight.SemiBold); Text(if(online) "● Online" else "Away", color = if(online) Color(0xFF2BA86B) else Color.Gray, style = MaterialTheme.typography.labelSmall) } } }
@Composable private fun PrimaryButton(text: String, onClick: () -> Unit) { Button(onClick, colors = ButtonDefaults.buttonColors(containerColor = Accent), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) { Text(text) } }

@Composable private fun Home(nav: NavHostController) { LazyColumn { item { Header("Good evening 👋", "Find people, rooms and games") }; item { LazyRow(Modifier.padding(horizontal = 10.dp)) { listOf("Asha","Maya","Riya","Anu","Sara").forEach { UserCard(it) { nav.navigate("call") } } } }; item { Section("Live now", "See all") { nav.navigate("live") } }; item { LiveTile("🌸", "Chill Room", "1.2K watching") { nav.navigate("liveRoom") } }; item { Section("Quick actions") }; item { QuickGrid(nav) }; item { Section("Party rooms", "More") { nav.navigate("party") } }; item { PartyTile("🎤", "Music Lounge", "8 seats • 326 viewers") { nav.navigate("partyRoom") } }; item { Section("Games", "Open Game Center") { nav.navigate("games") } }; item { GameStrip(nav) }; SpacerItem() } }

@Composable private fun Live(nav: NavHostController) { LazyColumn { item { Header("Live", "Explore live hosts and special rooms") }; item { Chips(listOf("For You","Nearby","Popular","New")) }; items(listOf("Luna","Mira","Kavi","Nila","Tara","Diya")) { UserCard(it) { nav.navigate("liveRoom") } }; item { Section("Start streaming") }; item { PrimaryButton("Start a live room") {} } } }
@Composable private fun Party(nav: NavHostController) { LazyColumn { item { Header("Party rooms", "Voice, video, games and group chat") }; item { Chips(listOf("Recommended","Music","Games","Friends")) }; items(listOf("Music Lounge","Game Night","Talk & Chill","Global Hangout")) { PartyTile("🎙️", it, "8 seats • Live now") { nav.navigate("partyRoom") } } } }
@Composable private fun Discover(nav: NavHostController) { LazyColumn { item { Header("Discover") }; item { Chips(listOf("People","Moments","Groups","Rankings")) }; item { Section("People you may like") }; item { LazyRow(Modifier.padding(horizontal = 10.dp)) { listOf("Mina","Ravi","Kia","Jin").forEach { UserCard(it) { nav.navigate("call") } } } }; item { Section("Moments", "View all") { nav.navigate("moments") } }; items(3) { MomentCard("Creator ${it+1}", "Having a great day ✨ #vibes") } } }
@Composable private fun Messages(nav: NavHostController) { LazyColumn { item { Header("Messages") }; item { SearchBox("Search chats") }; items(listOf("Maya","Luna","Music Lounge","System")) { ChatRow(it) { nav.navigate("call") } }; item { Section("Groups & families") }; item { ChatRow("Vibe Family") { nav.navigate("groups") } } } }
@Composable private fun Profile(nav: NavHostController) { LazyColumn { item { ProfileHeader() }; item { Section("My space") }; item { ActionRow("💎", "Wallet & recharge") { nav.navigate("wallet") } }; item { ActionRow("🎒", "Backpack") { nav.navigate("backpack") } }; item { ActionRow("🎁", "Gifts") { nav.navigate("gifts") } }; item { ActionRow("🏆", "Rankings") { nav.navigate("ranks") } }; item { ActionRow("✅", "Tasks & rewards") { nav.navigate("tasks") } }; item { ActionRow("⚙️", "Settings") { nav.navigate("settings") } } } }

@Composable private fun QuickGrid(nav: NavHostController) { Row(Modifier.fillMaxWidth().padding(12.dp)) { listOf("⚡ Match" to "match", "👨‍👩‍👧 Groups" to "groups", "✨ Moments" to "moments", "🎮 Games" to "games").forEach { (a,r) -> OutlinedCard(Modifier.weight(1f).padding(4.dp).clickable { nav.navigate(r) }) { Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text(a); Spacer(Modifier.height(4.dp)); Text("Open", color = Accent, style = MaterialTheme.typography.labelSmall) } } } } }
@Composable private fun GameStrip(nav: NavHostController) { LazyRow(Modifier.padding(horizontal = 10.dp)) { games.take(4).forEach { g -> Card(Modifier.padding(6.dp).width(130.dp).clickable { nav.navigate(g.route) }, shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(14.dp)) { Text(g.icon, style = MaterialTheme.typography.headlineMedium); Text(g.title, fontWeight = FontWeight.Bold); Text("Play", color = Accent) } } } } }
@Composable private fun LiveTile(icon: String, title: String, sub: String, onClick: () -> Unit) { Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp).clickable { onClick() }, shape = RoundedCornerShape(22.dp)) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Text(icon, style = MaterialTheme.typography.displaySmall); Spacer(Modifier.width(14.dp)); Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Bold); Text(sub, color = Color.Gray) }; Icon(Icons.Default.PlayArrow, null, tint = Accent) } } }
@Composable private fun PartyTile(icon: String, title: String, sub: String, onClick: () -> Unit) { LiveTile(icon,title,sub,onClick) }
@Composable private fun Chips(labels: List<String>) { LazyRow(Modifier.padding(horizontal = 12.dp)) { items(labels) { AssistChip(onClick = {}, label = { Text(it) }, modifier = Modifier.padding(4.dp)) } } }
@Composable private fun SearchBox(hint: String) { OutlinedTextField(value="", onValueChange={}, placeholder={Text(hint)}, leadingIcon={Icon(Icons.Default.Search,null)}, modifier=Modifier.fillMaxWidth().padding(16.dp), shape=RoundedCornerShape(16.dp)) }
@Composable private fun ChatRow(name: String, onClick: () -> Unit) { ListItem(headlineContent={Text(name,fontWeight=FontWeight.SemiBold)}, supportingContent={Text("Tap to continue the conversation")}, leadingContent={Avatar(name.take(1),48)}, trailingContent={Icon(Icons.Default.ChevronRight,null)}, modifier=Modifier.clickable {onClick()}) }
@Composable private fun MomentCard(name:String,text:String) { Card(Modifier.fillMaxWidth().padding(8.dp),shape=RoundedCornerShape(18.dp)) { Column(Modifier.padding(16.dp)){ Row(verticalAlignment=Alignment.CenterVertically){Avatar(name.take(1),42);Spacer(Modifier.width(10.dp));Text(name,fontWeight=FontWeight.Bold)};Spacer(Modifier.height(12.dp));Box(Modifier.fillMaxWidth().height(120.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFFEFEAFB)),Alignment.Center){Text("Moment preview",color=Color.Gray)};Spacer(Modifier.height(8.dp));Text(text);Text("♡  24     💬 6",color=Color.Gray) } } }
@Composable private fun ProfileHeader(){ Column(Modifier.fillMaxWidth().padding(22.dp),horizontalAlignment=Alignment.CenterHorizontally){Avatar("S",84);Spacer(Modifier.height(10.dp));Text("Sathish",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Text("Level 12 • Creator",color=Color.Gray);Spacer(Modifier.height(14.dp));Row(horizontalArrangement=Arrangement.spacedBy(28.dp)){Text("128\nFollowing");Text("2.4K\nFollowers");Text("86\nGifts")}} }
@Composable private fun ActionRow(icon:String,title:String,onClick:()->Unit){ListItem(headlineContent={Text(title,fontWeight=FontWeight.SemiBold)},leadingContent={Text(icon,style=MaterialTheme.typography.titleLarge)},trailingContent={Icon(Icons.Default.ChevronRight,null)},modifier=Modifier.clickable{onClick()})}
@Composable private fun SpacerItem(){item{} }

@Composable private fun LiveRoom(nav:NavHostController){Column(Modifier.fillMaxSize().background(Color(0xFF17131F))){Box(Modifier.fillMaxWidth().weight(1f),Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally){Text("LIVE",color=Pink,fontWeight=FontWeight.Bold);Avatar("L",110);Text("Luna • Chill Room",color=Color.White,fontWeight=FontWeight.Bold);Text("1,248 viewers",color=Color.LightGray)}}; Row(Modifier.padding(12.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){Button({nav.navigate("gifts")}){Text("🎁 Gift")};Button({nav.navigate("games")}){Text("🎮 Game")};Button({}){Text("💬 Chat")}}}}
@Composable private fun Call(nav:NavHostController){Column(Modifier.fillMaxSize().background(Color(0xFF121016)),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Avatar("M",130);Text("Maya",color=Color.White,style=MaterialTheme.typography.headlineSmall);Text("Connecting...",color=Color.LightGray);Spacer(Modifier.height(40.dp));Row(horizontalArrangement=Arrangement.spacedBy(20.dp)){FilledIconButton({}){Icon(Icons.Default.Mic,null)};FilledIconButton({nav.popBackStack()}){Icon(Icons.Default.CallEnd,null)}}}}
@Composable private fun PartyRoom(nav:NavHostController){Column(Modifier.fillMaxSize().padding(16.dp)){Text("Music Lounge",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Text("8 seats • Voice/video room",color=Color.Gray);Spacer(Modifier.height(20.dp));LazyRow{(1..8).forEach{Avatar("$it",60)}};Spacer(Modifier.height(20.dp));PrimaryButton("Open Game Center"){nav.navigate("games")};Spacer(Modifier.height(12.dp));PrimaryButton("Send Gift"){nav.navigate("gifts")}}}
@Composable private fun Match(nav:NavHostController){Column(Modifier.fillMaxSize().padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Avatar("⚡",130);Text("Quick Match",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);Text("Find a new person for a live conversation",color=Color.Gray);Spacer(Modifier.height(24.dp));PrimaryButton("Start Matching"){};TextButton({nav.popBackStack()}){Text("Cancel")}}}
@Composable private fun Groups(nav:NavHostController){LazyColumn{item{Header("Groups & Families")};items(listOf("Vibe Family","Night Owls","Music Fans","Game Crew")){ActionRow("👥",it){}};item{Spacer(Modifier.height(12.dp));PrimaryButton("Create a group") {}}}}
@Composable private fun Moments(nav:NavHostController){LazyColumn{item{Header("Moments")};items(5){MomentCard("Creator ${it+1}","Sharing a new moment with the community ✨")}}}
@Composable private fun Gifts(nav:NavHostController){LazyColumn{item{Header("Gift Center","Choose a gift to send")};item{LazyRow(Modifier.padding(10.dp)){listOf("🌹 Rose","💎 Gem","🎂 Cake","🚀 Rocket","👑 Crown").forEach{ActionChip(it)}}};item{Section("Gift inventory")};items(10){ListItem(headlineContent={Text("Gift ${it+1}")},leadingContent={Text("🎁",style=MaterialTheme.typography.titleLarge)},trailingContent={Text("${(it+1)*10} 💎")})}}}
@Composable private fun ActionChip(t:String){AssistChip(onClick={},label={Text(t)},modifier=Modifier.padding(4.dp))}
@Composable private fun Wallet(nav:NavHostController){Column(Modifier.fillMaxSize().padding(20.dp)){Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(22.dp)){Column(Modifier.padding(22.dp)){Text("Diamond Balance",color=Color.Gray);Text("12,580 💎",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);Text("Coin Balance  4,250 🪙")}};Spacer(Modifier.height(20.dp));Section("Recharge packs");listOf("100 💎" to "₹99","550 💎" to "₹499","1200 💎" to "₹999","3500 💎" to "₹2,799").forEach{(a,b)->ListItem(headlineContent={Text(a,fontWeight=FontWeight.Bold)},supportingContent={Text(b)},trailingContent={Button({}){Text("Buy")}})}}}
@Composable private fun Backpack(nav:NavHostController){LazyColumn{item{Header("Backpack")};items(listOf("Rose Pack","VIP Frame","Lucky Badge","Creator Effect","Call Card")){ListItem(headlineContent={Text(it)},supportingContent={Text("Available item")},leadingContent={Text("🎒")},trailingContent={Text("Use",color=Accent)})}}}
@Composable private fun Tasks(nav:NavHostController){LazyColumn{item{Header("Tasks & Rewards")};items(listOf("Daily check-in","Watch 10 minutes","Send your first gift","Join a party room","Invite a friend")){ListItem(headlineContent={Text(it,fontWeight=FontWeight.SemiBold)},supportingContent={Text("Progress 0/1")},trailingContent={Button({}){Text("Claim")}})}}}
@Composable private fun Ranks(nav:NavHostController){LazyColumn{item{Header("Rankings")};item{Chips(listOf("Wealth","Charm","Fans","Hosts"))};items(10){ListItem(headlineContent={Text("#${it+1} Creator ${it+1}",fontWeight=FontWeight.Bold)},supportingContent={Text("Level ${20-it} • ${10000-it*321} points")},leadingContent={Avatar("${it+1}",44)})}}}
@Composable private fun Settings(nav:NavHostController){LazyColumn{item{Header("Settings")};items(listOf("Account & Security","Notifications","Privacy","Language","Blocked users","Help & Support","About")){ActionRow("⚙️",it){}};item{Spacer(Modifier.height(20.dp));Button({},colors=ButtonDefaults.buttonColors(containerColor=Color(0xFFEEEEF2)),modifier=Modifier.fillMaxWidth()){Text("Log out",color=Color.DarkGray)}}}}

@Composable private fun GameCenter(nav:NavHostController){LazyColumn{item{Header("Game Center","Games designed for party/live rooms")};items(games){g->Card(Modifier.fillMaxWidth().padding(8.dp).clickable{nav.navigate(g.route)},shape=RoundedCornerShape(20.dp)){Row(Modifier.padding(18.dp),verticalAlignment=Alignment.CenterVertically){Text(g.icon,style=MaterialTheme.typography.displaySmall);Spacer(Modifier.width(16.dp));Column(Modifier.weight(1f)){Text(g.title,fontWeight=FontWeight.Bold);Text("Multiplayer room game • rewards & history",color=Color.Gray)};Icon(Icons.Default.PlayArrow,null,tint=Accent)}}}}}
@Composable private fun Game(nav:NavHostController,g:Item){Column(Modifier.fillMaxSize().padding(16.dp)){Card(Modifier.fillMaxWidth().height(190.dp),shape=RoundedCornerShape(26.dp)){Box(Modifier.fillMaxSize().background(Color(0xFFECE8FF)),Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally){Text(g.icon,style=MaterialTheme.typography.displayLarge);Text(g.title,style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)}}};Spacer(Modifier.height(16.dp));Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){Stat("Balance","2,500 💎");Stat("Round","#128");Stat("Players","8")};Spacer(Modifier.height(18.dp));Text("Choose your play",fontWeight=FontWeight.Bold);Spacer(Modifier.height(8.dp));PrimaryButton("Join Round"){};Spacer(Modifier.height(8.dp));OutlinedButton({},modifier=Modifier.fillMaxWidth()){Text("History & Rules")};Spacer(Modifier.height(18.dp));Text("Recent results",fontWeight=FontWeight.Bold);repeat(5){ListItem(headlineContent={Text("Round ${128-it}")},supportingContent={Text("Result • ${it+2}x")},leadingContent={Text("${it+1}")})}}}
@Composable private fun Stat(a:String,b:String){Card(Modifier.width(108.dp),shape=RoundedCornerShape(16.dp)){Column(Modifier.padding(12.dp)){Text(a,color=Color.Gray);Text(b,fontWeight=FontWeight.Bold)}}}
