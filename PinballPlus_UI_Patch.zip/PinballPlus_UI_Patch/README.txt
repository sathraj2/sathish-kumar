PINBALL PLUS - EXACT REFERENCE UI PATCH

Replace Platforms/Android/MainActivity.cs with the included file.
Copy the three PNG files into Resources/drawable-nodpi/.
This uses the supplied reference artwork as the actual Android UI, rather than trying to redraw it with standard Buttons.
