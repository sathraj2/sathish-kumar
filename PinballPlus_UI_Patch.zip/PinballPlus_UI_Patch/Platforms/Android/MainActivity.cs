using Android.App;
using Android.OS;
using Android.Views;
using Android.Widget;
using Android.Graphics;
using Android.Graphics.Drawables;

namespace PinballPlus;

[Activity(
    Label = "Pinball Plus",
    MainLauncher = true,
    Exported = true,
    Theme = "@android:style/Theme.Material.NoActionBar",
    ScreenOrientation = Android.Content.PM.ScreenOrientation.Portrait)]
public class MainActivity : Activity
{
    FrameLayout? root;
    ImageView? image;

    protected override void OnCreate(Bundle? savedInstanceState)
    {
        base.OnCreate(savedInstanceState);
        Window?.SetStatusBarColor(Color.Black);
        Window?.SetNavigationBarColor(Color.Black);
        HideSystemBars();
        ShowSplash();
    }

    void HideSystemBars()
    {
        Window?.DecorView?.SystemUiVisibility =
            (StatusBarVisibility)(SystemUiFlags.Fullscreen |
            SystemUiFlags.HideNavigation |
            SystemUiFlags.ImmersiveSticky |
            SystemUiFlags.LayoutStable |
            SystemUiFlags.LayoutHideNavigation |
            SystemUiFlags.LayoutFullscreen);
    }

    void ShowSplash()
    {
        var splash = new ImageView(this)
        {
            LayoutParameters = new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MatchParent,
                ViewGroup.LayoutParams.MatchParent)
        };
        splash.SetImageResource(Resource.Drawable.pinball_splash);
        splash.SetScaleType(ImageView.ScaleType.CenterCrop);
        SetContentView(splash);

        new Handler(Looper.MainLooper!).PostDelayed(ShowMainMenu, 2200);
    }

    void ShowMainMenu()
    {
        root = new FrameLayout(this);
        image = new ImageView(this);
        image.SetImageResource(Resource.Drawable.pinball_main_menu);
        image.SetScaleType(ImageView.ScaleType.CenterCrop);
        root.AddView(image, new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MatchParent,
            ViewGroup.LayoutParams.MatchParent));

        // Transparent touch areas over the buttons in the reference artwork.
        AddTouch(0.37f, 0.455f, 0.27f, 0.08f, () => Toast.MakeText(this, "PLAY GAME", ToastLength.Short)?.Show());
        AddTouch(0.37f, 0.555f, 0.27f, 0.08f, () => Toast.MakeText(this, "LEVEL SELECT", ToastLength.Short)?.Show());
        AddTouch(0.37f, 0.655f, 0.27f, 0.08f, () => Toast.MakeText(this, "ACHIEVEMENTS", ToastLength.Short)?.Show());
        AddTouch(0.37f, 0.755f, 0.27f, 0.08f, () => Toast.MakeText(this, "LEADERBOARD", ToastLength.Short)?.Show());
        AddTouch(0.37f, 0.855f, 0.27f, 0.08f, () => Toast.MakeText(this, "SETTINGS", ToastLength.Short)?.Show());
        AddTouch(0.37f, 0.935f, 0.27f, 0.055f, () => FinishAffinity());

        SetContentView(root);
        HideSystemBars();
    }

    void AddTouch(float x, float y, float w, float h, Action action)
    {
        var v = new View(this);
        v.SetBackgroundColor(Color.Transparent);
        v.Click += (_, _) => action();

        var lp = new FrameLayout.LayoutParams(1, 1);
        root!.AddView(v, lp);

        root.Post(() =>
        {
            v.LayoutParameters = new FrameLayout.LayoutParams(
                (int)(root.Width * w),
                (int)(root.Height * h))
            {
                LeftMargin = (int)(root.Width * x),
                TopMargin = (int)(root.Height * y)
            };
            v.RequestLayout();
        });
    }
}
