# Pinball Plus MAUI

A Unity-free recreation of the Pinball Plus concept using .NET MAUI and C#.

## Requirements
- .NET 8 SDK
- .NET MAUI workload
- Android SDK/API 21+

## Build Android APK
```bash
dotnet workload install maui-android
dotnet restore
dotnet publish -f net8.0-android -c Release -p:AndroidPackageFormat=apk
```

The APK will be under:
`bin/Release/net8.0-android/publish/`

## Notes
This is a clean-room gameplay recreation. The physics, rendering and UI are implemented with MAUI Graphics and C#. Existing Unity-specific scripts are not required.
