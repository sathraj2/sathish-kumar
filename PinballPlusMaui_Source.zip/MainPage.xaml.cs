using Microsoft.Maui.Graphics;

namespace PinballPlusMaui;

public partial class MainPage : ContentPage
{
    readonly PinballGame _game;
    IDispatcherTimer? _timer;

    public MainPage()
    {
        InitializeComponent();
        _game = new PinballGame();
        GameView.Drawable = new PinballDrawable(_game);
        _game.StateChanged += (_, _) =>
        {
            ScoreLabel.Text = _game.Score.ToString("D6");
            LivesLabel.Text = _game.Lives.ToString();
            GameView.Invalidate();
        };

        _timer = Dispatcher.CreateTimer();
        _timer.Interval = TimeSpan.FromMilliseconds(16);
        _timer.Tick += (_, _) =>
        {
            _game.Update(0.016f, GameView.Width, GameView.Height);
            GameView.Invalidate();
        };
        _timer.Start();
    }

    void LeftClicked(object sender, EventArgs e) => _game.LeftFlipper = true;
    void RightClicked(object sender, EventArgs e) => _game.RightFlipper = true;
    void LaunchClicked(object sender, EventArgs e) => _game.Launch();

    void OnTouchStart(object? sender, TouchEventArgs e)
    {
        foreach (var p in e.Touches)
        {
            if (p.X < GameView.Width / 2) _game.LeftFlipper = true;
            else _game.RightFlipper = true;
        }
    }

    void OnTouchDrag(object? sender, TouchEventArgs e) { }

    void OnTouchEnd(object? sender, TouchEventArgs e)
    {
        _game.LeftFlipper = false;
        _game.RightFlipper = false;
    }

    protected override void OnDisappearing()
    {
        _timer?.Stop();
        base.OnDisappearing();
    }
}
