using Microsoft.Maui.Graphics;

namespace PinballPlusMaui;

public sealed class PinballDrawable : IDrawable
{
    readonly PinballGame _game;
    public PinballDrawable(PinballGame game) => _game = game;

    public void Draw(ICanvas c, RectF r)
    {
        c.FillColor = Color.FromArgb("#0C111B");
        c.FillRectangle(r);

        float w = r.Width, h = r.Height;
        float sx = MathF.Min(w, h * 0.58f);
        float ox = (w - sx) / 2f;

        // Playfield
        c.FillColor = Color.FromArgb("#121A28");
        c.FillRoundedRectangle(ox, 4, sx, h - 8, 18);

        // Rails
        c.StrokeColor = Color.FromArgb("#6E7C94");
        c.StrokeSize = 5;
        c.DrawRoundedRectangle(ox + 6, 10, sx - 12, h - 20, 14);

        // Decorative center lane
        c.StrokeColor = Color.FromArgb("#26344B");
        c.StrokeSize = 2;
        c.DrawLine(ox + sx/2, 22, ox + sx/2, h * .68f);

        DrawBumper(c, ox + sx*.30f, h*.29f, sx*.085f, "#E74C3C");
        DrawBumper(c, ox + sx*.70f, h*.29f, sx*.085f, "#3498DB");
        DrawBumper(c, ox + sx*.50f, h*.43f, sx*.075f, "#F1C40F");

        // Targets
        c.FillColor = Color.FromArgb("#7C4DFF");
        c.FillRoundedRectangle(ox + sx*.18f, h*.52f, sx*.16f, 9, 4);
        c.FillColor = Color.FromArgb("#00C2A8");
        c.FillRoundedRectangle(ox + sx*.66f, h*.52f, sx*.16f, 9, 4);

        // Flippers
        DrawFlipper(c, ox + sx*.27f, h*.86f, sx*.25f, _game.LeftFlipper, false);
        DrawFlipper(c, ox + sx*.73f, h*.86f, sx*.25f, _game.RightFlipper, true);

        // Ball
        float bx = ox + sx * _game.BallX;
        float by = h * _game.BallY;
        float br = MathF.Max(7, sx * .028f);
        c.FillColor = Colors.White;
        c.FillCircle(bx, by, br);
        c.StrokeColor = Color.FromArgb("#B9C3D0");
        c.StrokeSize = 2;
        c.DrawCircle(bx, by, br);
    }

    static void DrawBumper(ICanvas c, float x, float y, float radius, string color)
    {
        c.FillColor = Color.FromArgb("#0A0E16");
        c.FillCircle(x, y, radius*1.25f);
        c.FillColor = Color.FromArgb(color);
        c.FillCircle(x, y, radius);
        c.FillColor = Colors.White;
        c.FillCircle(x - radius*.25f, y - radius*.25f, radius*.18f);
    }

    static void DrawFlipper(ICanvas c, float x, float y, float len, bool active, bool right)
    {
        c.StrokeColor = active ? Color.FromArgb("#F6C453") : Color.FromArgb("#E0E5EC");
        c.StrokeSize = 16;
        float x2 = right ? x - len : x + len;
        c.DrawLine(x, y, x2, y);
        c.FillColor = active ? Color.FromArgb("#F6C453") : Color.FromArgb("#E0E5EC");
        c.FillCircle(x, y, 10);
        c.FillCircle(x2, y, 10);
    }
}
