namespace PinballPlusMaui;

public sealed class PinballGame
{
    public float BallX { get; private set; } = 0.5f;
    public float BallY { get; private set; } = 0.76f;
    float _vx, _vy;
    bool _launched;
    public int Score { get; private set; }
    public int Lives { get; private set; } = 3;
    public bool LeftFlipper { get; set; }
    public bool RightFlipper { get; set; }
    public event EventHandler? StateChanged;

    public void Launch()
    {
        if (!_launched)
        {
            _launched = true;
            _vx = 0.10f;
            _vy = -1.35f;
        }
    }

    public void Update(float dt, double width, double height)
    {
        if (width <= 0 || height <= 0) return;
        if (!_launched) return;

        _vy += 1.55f * dt;
        BallX += _vx * dt;
        BallY += _vy * dt;

        const float r = 0.028f;
        if (BallX < r) { BallX = r; _vx = MathF.Abs(_vx); }
        if (BallX > 1-r) { BallX = 1-r; _vx = -MathF.Abs(_vx); }
        if (BallY < 0.05f) { BallY = 0.05f; _vy = MathF.Abs(_vy); }

        // Bumpers
        HitBumper(0.30f, 0.29f, 0.085f);
        HitBumper(0.70f, 0.29f, 0.085f);
        HitBumper(0.50f, 0.43f, 0.075f);

        // Flippers near bottom
        float fy = 0.88f;
        if (BallY > fy - 0.04f && BallY < fy + 0.08f)
        {
            if (LeftFlipper && BallX < 0.50f)
            {
                _vy = -1.15f;
                _vx += 0.75f;
                Score += 10;
            }
            if (RightFlipper && BallX >= 0.50f)
            {
                _vy = -1.15f;
                _vx -= 0.75f;
                Score += 10;
            }
        }

        if (BallY > 1.04f)
        {
            Lives--;
            if (Lives <= 0)
            {
                Lives = 3;
                Score = 0;
            }
            ResetBall();
        }
        StateChanged?.Invoke(this, EventArgs.Empty);
    }

    void HitBumper(float cx, float cy, float radius)
    {
        float dx = BallX - cx, dy = BallY - cy;
        float d2 = dx * dx + dy * dy;
        if (d2 < radius * radius)
        {
            float d = MathF.Max(0.001f, MathF.Sqrt(d2));
            BallX = cx + dx / d * radius;
            BallY = cy + dy / d * radius;
            _vy = -MathF.Abs(_vy) - 0.45f;
            _vx += dx / d * 0.35f;
            Score += 100;
        }
    }

    void ResetBall()
    {
        BallX = 0.5f;
        BallY = 0.76f;
        _vx = _vy = 0;
        _launched = false;
        LeftFlipper = RightFlipper = false;
    }
}
