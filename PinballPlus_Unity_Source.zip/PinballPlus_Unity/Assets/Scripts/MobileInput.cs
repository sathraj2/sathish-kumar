using UnityEngine;

namespace PinballPlus
{
    public static class MobileInput
    {
        public static bool IsPressed(FlipperController.Side side)
        {
            if (Input.touchCount == 0) return false;

            for (int i = 0; i < Input.touchCount; i++)
            {
                Touch t = Input.GetTouch(i);
                if (t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled)
                    continue;

                float x = t.position.x / Mathf.Max(1f, Screen.width);
                if (side == FlipperController.Side.Left && x < 0.48f) return true;
                if (side == FlipperController.Side.Right && x > 0.52f) return true;
            }

            return false;
        }
    }
}
