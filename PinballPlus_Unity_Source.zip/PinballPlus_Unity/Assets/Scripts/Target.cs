using UnityEngine;

namespace PinballPlus
{
    public class Target : MonoBehaviour
    {
        public int points = 250;

        private bool hit;

        private void OnCollisionEnter2D(Collision2D collision)
        {
            if (hit) return;
            hit = true;

            PinballGameManager.Instance?.AddScore(points);
            SoundManager.Play("Target");
            HapticManager.Medium();

            var sr = GetComponent<SpriteRenderer>();
            if (sr != null)
                sr.enabled = false;

            Invoke(nameof(ResetTarget), 1.25f);
        }

        private void ResetTarget()
        {
            hit = false;
            var sr = GetComponent<SpriteRenderer>();
            if (sr != null)
                sr.enabled = true;
        }
    }
}
