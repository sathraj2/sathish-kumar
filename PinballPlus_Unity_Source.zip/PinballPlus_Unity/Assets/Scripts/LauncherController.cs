using UnityEngine;

namespace PinballPlus
{
    public class LauncherController : MonoBehaviour
    {
        public BallController ball;

        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.Space))
                Launch();

            if (Input.touchCount > 0)
            {
                for (int i = 0; i < Input.touchCount; i++)
                {
                    Touch t = Input.GetTouch(i);
                    if (t.phase == TouchPhase.Began && t.position.x > Screen.width * 0.75f && t.position.y < Screen.height * 0.25f)
                    {
                        Launch();
                        break;
                    }
                }
            }
        }

        public void Launch()
        {
            if (ball != null)
                ball.Launch();
        }
    }
}
