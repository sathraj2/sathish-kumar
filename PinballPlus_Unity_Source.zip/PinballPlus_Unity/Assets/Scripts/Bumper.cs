using UnityEngine;

namespace PinballPlus
{
    public class Bumper : MonoBehaviour
    {
        public int points = 100;
        public float impulse = 7f;

        private void OnCollisionEnter2D(Collision2D collision)
        {
            Rigidbody2D rb = collision.rigidbody;
            if (rb != null)
            {
                Vector2 direction = (collision.transform.position - transform.position).normalized;
                rb.AddForce(direction * impulse, ForceMode2D.Impulse);
            }

            PinballGameManager.Instance?.AddScore(points);
            SoundManager.Play("Bumper");
            HapticManager.Medium();
        }
    }
}
