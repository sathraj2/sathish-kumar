using UnityEngine;
using System.Collections.Generic;

namespace PinballPlus
{
    public class SoundManager : MonoBehaviour
    {
        public static SoundManager Instance { get; private set; }
        public AudioSource source;

        private readonly Dictionary<string, AudioClip> clips = new Dictionary<string, AudioClip>();

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }

            Instance = this;
            source = source != null ? source : gameObject.AddComponent<AudioSource>();
        }

        public static void Play(string key)
        {
            // Hook point for licensed/original audio clips.
            // If you add clips to this manager, map them here.
        }
    }
}
