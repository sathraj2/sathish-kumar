using UnityEngine;

namespace PinballPlus
{
    [RequireComponent(typeof(Rigidbody2D), typeof(CircleCollider2D))]
    public class BallController : MonoBehaviour
    {
        public float maxSpeed = 18f;
        public float minLaunchSpeed = 7f;
        public Transform launcherPoint;

        private Rigidbody2D rb;
        private bool countedAsLost;

        private void Awake()
        {
            rb = GetComponent<Rigidbody2D>();
            rb.gravityScale = 1.0f;
            rb.linearDamping = 0.08f;
            rb.angularDamping = 0.05f;
            rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
        }

        private void FixedUpdate()
        {
            if (rb.linearVelocity.magnitude > maxSpeed)
                rb.linearVelocity = rb.linearVelocity.normalized * maxSpeed;

            if (transform.position.y < -8.5f && !countedAsLost)
            {
                countedAsLost = true;
                PinballGameManager.Instance?.BallLost();
            }
        }

        public void Launch()
        {
            countedAsLost = false;
            rb.simulated = true;
            rb.linearVelocity = Vector2.up * minLaunchSpeed;
            SoundManager.Play("Launch");
            HapticManager.Light();
        }

        public void ResetToLauncher()
        {
            countedAsLost = false;
            rb.linearVelocity = Vector2.zero;
            rb.angularVelocity = 0;
            rb.simulated = false;

            if (launcherPoint != null)
                transform.position = launcherPoint.position;

            rb.simulated = true;
        }

        private void OnCollisionEnter2D(Collision2D collision)
        {
            if (collision.relativeVelocity.magnitude > 2f)
            {
                SoundManager.Play("Hit");
                HapticManager.Light();
            }
        }
    }
}
