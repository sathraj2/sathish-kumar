using UnityEngine;

namespace PinballPlus
{
    public class PinballCamera : MonoBehaviour
    {
        private void Awake()
        {
            Camera cam = GetComponent<Camera>();
            cam.orthographic = true;
            cam.orthographicSize = 10.2f;
            cam.transform.position = new Vector3(0, 0, -10);
        }
    }
}
