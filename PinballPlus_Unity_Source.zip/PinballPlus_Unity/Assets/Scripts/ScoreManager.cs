using UnityEngine;
using UnityEngine.UI;

namespace PinballPlus
{
    public class ScoreManager : MonoBehaviour
    {
        public Text scoreText;
        public Text levelText;
        public Text ballsText;
        public Text highScoreText;
        public Text gameOverText;

        private int highScore;

        private void Awake()
        {
            highScore = PlayerPrefs.GetInt("PinballPlus.HighScore", 0);
            if (highScoreText != null) highScoreText.text = highScore.ToString("N0");
            if (gameOverText != null) gameOverText.gameObject.SetActive(false);
        }

        public void SetScore(int score)
        {
            if (scoreText != null) scoreText.text = score.ToString("N0");

            if (score > highScore)
            {
                highScore = score;
                PlayerPrefs.SetInt("PinballPlus.HighScore", highScore);
                PlayerPrefs.Save();
                if (highScoreText != null) highScoreText.text = highScore.ToString("N0");
            }
        }

        public void SetLevel(int level)
        {
            if (levelText != null) levelText.text = level.ToString();
        }

        public void SetBalls(int balls)
        {
            if (ballsText != null) ballsText.text = balls.ToString();
        }

        public void ShowGameOver()
        {
            if (gameOverText != null)
            {
                gameOverText.text = "GAME OVER\nTap Restart";
                gameOverText.gameObject.SetActive(true);
            }
        }
    }
}
