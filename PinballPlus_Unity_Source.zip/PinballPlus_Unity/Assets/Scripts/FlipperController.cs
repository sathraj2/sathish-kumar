using UnityEngine;

namespace PinballPlus
{
    public class FlipperController : MonoBehaviour
    {
        public enum Side { Left, Right }

        public Side side = Side.Left;
        public float pressedAngle = 35f;
        public float releasedAngle = -25f;
        public float motorSpeed = 1600f;

        private HingeJoint2D hinge;
        private float targetAngle;

        private void Awake()
        {
            hinge = GetComponent<HingeJoint2D>();
            targetAngle = releasedAngle;
            ConfigureMotor();
        }

        private void Update()
        {
            bool keyboardPressed = side == Side.Left
                ? Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A)
                : Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D);

            bool mobilePressed = MobileInput.IsPressed(side);
            bool pressed = keyboardPressed || mobilePressed;

            targetAngle = pressed ? pressedAngle : releasedAngle;
            SetMotor(targetAngle);

            if (pressed)
                HapticManager.Medium();
        }

        private void ConfigureMotor()
        {
            hinge.useMotor = true;
            hinge.motor = new JointMotor2D
            {
                motorSpeed = motorSpeed,
                maxMotorTorque = 10000f,
                freeSpin = false
            };
        }

        private void SetMotor(float target)
        {
            float current = transform.localEulerAngles.z;
            if (current > 180f) current -= 360f;

            float delta = Mathf.DeltaAngle(current, target);
            var motor = hinge.motor;
            motor.motorSpeed = delta > 0 ? Mathf.Abs(motorSpeed) : -Mathf.Abs(motorSpeed);
            hinge.motor = motor;
        }
    }
}
