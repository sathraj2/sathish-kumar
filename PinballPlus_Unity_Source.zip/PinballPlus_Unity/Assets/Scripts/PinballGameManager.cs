using UnityEngine;
using UnityEngine.SceneManagement;

namespace PinballPlus
{
    public class PinballGameManager : MonoBehaviour
    {
        public static PinballGameManager Instance { get; private set; }

        [Header("Game")]
        public int startingBalls = 3;
        public int score;
        public int level = 1;
        public int ballsRemaining;

        [Header("References")]
        public ScoreManager scoreManager;

        private bool gameOver;

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }

            Instance = this;
            Application.targetFrameRate = 60;
            ballsRemaining = startingBalls;
        }

        private void Start()
        {
            if (scoreManager == null)
                scoreManager = FindObjectOfType<ScoreManager>();

            scoreManager?.SetScore(score);
            scoreManager?.SetLevel(level);
            scoreManager?.SetBalls(ballsRemaining);
        }

        public void AddScore(int amount)
        {
            if (gameOver) return;

            int multiplier = Mathf.Max(1, level);
            score += amount * multiplier;
            scoreManager?.SetScore(score);
        }

        public void BallLost()
        {
            if (gameOver) return;

            ballsRemaining--;
            scoreManager?.SetBalls(ballsRemaining);

            if (ballsRemaining <= 0)
            {
                gameOver = true;
                scoreManager?.ShowGameOver();
                return;
            }

            level = Mathf.Min(10, level + 1);
            scoreManager?.SetLevel(level);

            Invoke(nameof(ResetBall), 0.7f);
        }

        private void ResetBall()
        {
            BallController ball = FindObjectOfType<BallController>();
            if (ball != null)
                ball.ResetToLauncher();
        }

        public void RestartGame()
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }
    }
}
