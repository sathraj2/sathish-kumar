#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UI;
using PinballPlus;

public static class PinballPlusSceneBuilder
{
    [MenuItem("Tools/Pinball Plus/Build Demo Scene")]
    public static void Build()
    {
        EnsureFolder("Assets/Scenes");

        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        scene.name = "PinballPlus";

        // Camera
        var camGo = new GameObject("Main Camera");
        var cam = camGo.AddComponent<Camera>();
        cam.orthographic = true;
        cam.orthographicSize = 10.2f;
        cam.backgroundColor = new Color(0.035f, 0.005f, 0.10f);
        camGo.transform.position = new Vector3(0, 0, -10);
        camGo.AddComponent<PinballCamera>();

        // Managers
        var manager = new GameObject("GameManager");
        manager.AddComponent<PinballGameManager>();

        var sound = new GameObject("SoundManager");
        sound.AddComponent<SoundManager>();

        // Table
        CreateRect("Table", new Vector2(0, 0), new Vector2(11.5f, 19.2f), new Color(0.055f, 0.02f, 0.16f), false);
        CreateBorder("LeftRail", new Vector2(-5.65f, 0), 19f);
        CreateBorder("RightRail", new Vector2(5.65f, 0), 19f);
        CreateBorder("TopRail", new Vector2(0, 9.4f), 11f, true);

        // Central galaxy-style target.
        var center = CreateCircle("Galaxy", new Vector2(0, 0.6f), 1.35f, new Color(0.05f, 0.55f, 1f));
        center.AddComponent<CircleCollider2D>().isTrigger = false;

        // Bumpers
        Vector2[] bumpers =
        {
            new Vector2(-2.0f, 6.6f), new Vector2(0.0f, 5.8f), new Vector2(2.0f, 6.6f),
            new Vector2(-1.2f, 4.1f), new Vector2(1.3f, 4.1f)
        };

        foreach (var p in bumpers)
            CreateBumper(p);

        // Targets
        Vector2[] targets =
        {
            new Vector2(-3.3f, 7.4f), new Vector2(3.3f, 7.4f),
            new Vector2(-3.6f, 2.2f), new Vector2(3.6f, 2.2f)
        };

        foreach (var p in targets)
            CreateTarget(p);

        // Slingshots
        CreateRect("LeftSlingshot", new Vector2(-2.3f, -3.0f), new Vector2(2.1f, 0.45f), Color.red, true, 28);
        CreateRect("RightSlingshot", new Vector2(2.3f, -3.0f), new Vector2(2.1f, 0.45f), Color.red, true, -28);

        // Flippers
        CreateFlipper("LeftFlipper", new Vector2(-1.8f, -5.8f), 25);
        CreateFlipper("RightFlipper", new Vector2(1.8f, -5.8f), -25);

        // Launcher and ball
        var launcherPoint = new GameObject("LauncherPoint");
        launcherPoint.transform.position = new Vector3(4.4f, -6.7f, 0);

        var ballGo = CreateCircle("Ball", launcherPoint.transform.position, 0.28f, Color.white);
        var rb = ballGo.AddComponent<Rigidbody2D>();
        rb.gravityScale = 1f;
        var ball = ballGo.AddComponent<BallController>();
        ball.launcherPoint = launcherPoint.transform;

        var launcher = new GameObject("Launcher");
        var lc = launcher.AddComponent<LauncherController>();
        lc.ball = ball;

        // UI
        BuildUI(manager);

        EditorSceneManager.SaveScene(scene, "Assets/Scenes/PinballPlus.unity");
        Selection.activeGameObject = manager;

        Debug.Log("Pinball Plus demo scene created at Assets/Scenes/PinballPlus.unity");
    }

    private static void BuildUI(GameObject manager)
    {
        var canvasGo = new GameObject("Canvas");
        var canvas = canvasGo.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvasGo.AddComponent<CanvasScaler>();
        canvasGo.AddComponent<GraphicRaycaster>();

        var panel = CreatePanel(canvas.transform, new Vector2(0.76f, 0.5f), new Vector2(0.40f, 0.92f), new Color(0.05f, 0.01f, 0.12f, 0.94f));

        CreateText(panel.transform, "PINBALL\nPLUS", new Vector2(0, 0.36f), 54);
        var score = CreateText(panel.transform, "0", new Vector2(0, 0.16f), 42);
        var level = CreateText(panel.transform, "1", new Vector2(0, 0.02f), 36);
        var balls = CreateText(panel.transform, "3", new Vector2(0, -0.10f), 36);
        var high = CreateText(panel.transform, "0", new Vector2(0, -0.22f), 30);
        var gameOver = CreateText(panel.transform, "", new Vector2(0, -0.37f), 32);

        var sm = manager.AddComponent<ScoreManager>();
        sm.scoreText = score;
        sm.levelText = level;
        sm.ballsText = balls;
        sm.highScoreText = high;
        sm.gameOverText = gameOver;

        var gm = manager.GetComponent<PinballGameManager>();
        gm.scoreManager = sm;
    }

    private static GameObject CreatePanel(Transform parent, Vector2 anchor, Vector2 size, Color color)
    {
        var go = new GameObject("HUD");
        go.transform.SetParent(parent);
        var rt = go.AddComponent<RectTransform>();
        rt.anchorMin = anchor - size / 2;
        rt.anchorMax = anchor + size / 2;
        rt.offsetMin = Vector2.zero;
        rt.offsetMax = Vector2.zero;
        var image = go.AddComponent<Image>();
        image.color = color;
        return go;
    }

    private static Text CreateText(Transform parent, string value, Vector2 normalizedPos, int fontSize)
    {
        var go = new GameObject("Text");
        go.transform.SetParent(parent);
        var rt = go.AddComponent<RectTransform>();
        rt.anchorMin = normalizedPos;
        rt.anchorMax = normalizedPos;
        rt.sizeDelta = new Vector2(500, 110);
        var text = go.AddComponent<Text>();
        text.text = value;
        text.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
        text.fontSize = fontSize;
        text.alignment = TextAnchor.MiddleCenter;
        text.color = Color.white;
        return text;
    }

    private static GameObject CreateCircle(string name, Vector2 pos, float radius, Color color)
    {
        var go = new GameObject(name);
        go.transform.position = pos;
        go.transform.localScale = Vector3.one * radius * 2f;
        var sr = go.AddComponent<SpriteRenderer>();
        sr.sprite = AssetDatabase.GetBuiltinExtraResource<Sprite>("UI/Skin/Background.psd");
        sr.color = color;
        var collider = go.AddComponent<CircleCollider2D>();
        collider.radius = 0.5f;
        return go;
    }

    private static GameObject CreateRect(string name, Vector2 pos, Vector2 size, Color color, bool collider, float rotation = 0)
    {
        var go = new GameObject(name);
        go.transform.position = pos;
        go.transform.rotation = Quaternion.Euler(0, 0, rotation);
        go.transform.localScale = new Vector3(size.x, size.y, 1);
        var sr = go.AddComponent<SpriteRenderer>();
        sr.sprite = AssetDatabase.GetBuiltinExtraResource<Sprite>("UI/Skin/Background.psd");
        sr.color = color;
        if (collider) go.AddComponent<BoxCollider2D>();
        return go;
    }

    private static void CreateBorder(string name, Vector2 pos, float length, bool horizontal = false)
    {
        CreateRect(name, pos, horizontal ? new Vector2(length, 0.25f) : new Vector2(0.25f, length), new Color(1f, 0.15f, 0.2f), true);
    }

    private static void CreateBumper(Vector2 pos)
    {
        var go = CreateCircle("Bumper", pos, 0.55f, new Color(1f, 0.72f, 0.05f));
        go.AddComponent<Bumper>();
    }

    private static void CreateTarget(Vector2 pos)
    {
        var go = CreateRect("Target", pos, new Vector2(0.9f, 0.25f), new Color(0.2f, 0.85f, 1f), true);
        go.AddComponent<Target>();
    }

    private static void CreateFlipper(string name, Vector2 pos, float angle)
    {
        var go = CreateRect(name, pos, new Vector2(2.0f, 0.34f), Color.white, true, angle);
        var rb = go.AddComponent<Rigidbody2D>();
        rb.bodyType = RigidbodyType2D.Kinematic;

        var hinge = go.AddComponent<HingeJoint2D>();
        hinge.useLimits = false;

        var flipper = go.AddComponent<FlipperController>();
        flipper.side = name.StartsWith("Left") ? FlipperController.Side.Left : FlipperController.Side.Right;
        flipper.releasedAngle = angle;
        flipper.pressedAngle = name.StartsWith("Left") ? 50f : -50f;
    }

    private static void EnsureFolder(string path)
    {
        string[] parts = path.Split('/');
        string current = parts[0];
        for (int i = 1; i < parts.Length; i++)
        {
            string next = current + "/" + parts[i];
            if (!AssetDatabase.IsValidFolder(next))
                AssetDatabase.CreateFolder(current, parts[i]);
            current = next;
        }
    }
}
#endif
