# Pinball Plus — Unity + C#

A portrait 2D pinball prototype designed around the Pinball Plus neon/cosmic reference layout.

## Requirements
- Unity 2022.3 LTS or newer
- Android Build Support + SDK/NDK/OpenJDK modules if building Android

## What is included
- Portrait gameplay
- Neon purple/cosmic presentation
- Ball physics
- Left/right flippers
- Plunger/launcher
- Bumpers and targets
- Score + high score
- 3-ball system
- Level progression
- Sound hooks
- Android vibration/haptic hooks
- Editor scene builder

## Open the project
1. Open this folder with Unity Hub.
2. Open `Assets/Scenes/PinballPlus.unity` if it exists, or run:
   `Tools > Pinball Plus > Build Demo Scene`
3. Press Play.
4. For Android, switch the build target to Android and build an APK/AAB.

## Controls
- Keyboard: A/Left Arrow = left flipper, D/Right Arrow = right flipper, Space = launch.
- Mobile: tap the left/right lower zones for flippers and the launcher zone to fire.
- Haptic feedback is enabled on Android when supported.

## Important
The project uses original procedural game shapes and does not include assets copied from the reference game. Replace the placeholder sound clips in `Assets/Audio` with your own licensed/original sounds.
